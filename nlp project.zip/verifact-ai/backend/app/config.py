from __future__ import annotations
import os
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).resolve().parents[1] / ".env")
except ImportError:
    pass

BASE_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = Path(os.getenv("VERIFACT_DATA_DIR", BASE_DIR / "data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)
EVIDENCE_PATH = Path(os.getenv("VERIFACT_EVIDENCE_PATH", DATA_DIR / "evidence.json"))
HISTORY_PATH = Path(os.getenv("VERIFACT_HISTORY_PATH", DATA_DIR / "history.sqlite3"))
METRICS_PATH = Path(os.getenv("VERIFACT_METRICS_PATH", DATA_DIR / "latest_evaluation.json"))
MAX_INPUT_CHARS = int(os.getenv("VERIFACT_MAX_INPUT_CHARS", "30000"))
MAX_URL_BYTES = int(os.getenv("VERIFACT_MAX_URL_BYTES", "2000000"))
FRONTEND_ORIGINS = [x.strip() for x in os.getenv("VERIFACT_CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(",") if x.strip()]
LLM_BASE_URL = os.getenv("VERIFACT_LLM_BASE_URL", "").rstrip("/")
LLM_API_KEY = os.getenv("VERIFACT_LLM_API_KEY", "")
LLM_MODEL = os.getenv("VERIFACT_LLM_MODEL", "")
NLI_MODEL = os.getenv("VERIFACT_NLI_MODEL", "")
USE_SEMANTIC_RETRIEVAL = os.getenv("VERIFACT_USE_SEMANTIC", "0").lower() in {"1", "true", "yes"}

TAVILY_API_KEY = os.getenv("TAVILY_API_KEY", "")
TAVILY_API_URL = os.getenv("TAVILY_API_URL", "https://api.tavily.com/search").rstrip("/")
TESSERACT_CMD = os.getenv("TESSERACT_CMD", "").strip()
