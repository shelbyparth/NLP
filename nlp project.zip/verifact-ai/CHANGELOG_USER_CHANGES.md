# User-facing changes in this update

- Removed Research from the main navigation.
- Removed the Evaluation Lab entry from the verification workspace sidebar.
- Removed the separate Research & Evaluation page and its academic practicals/classification/topic-modeling dashboard from the frontend.
- Removed the extra workspace call-to-action from the announcement banner and About page.
- Rewrote the About page and README around the Fake News Detection and Verification purpose.
- Kept the underlying backend NLP, retrieval, classification, topic-modeling and verification services intact; they are not presented as separate academic pages.
- Made short article summaries more concise while retaining a longer extractive detailed summary.
- Improved Ask AI evidence filtering to prioritize question-relevant passages and show at most two source passages in the fallback response.

Optional integrations such as Tavily, OCR and LLM translation still require their own configuration.
