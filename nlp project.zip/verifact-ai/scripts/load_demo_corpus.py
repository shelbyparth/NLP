"""Add visibly synthetic fictional records so developers can exercise retrieval locally.
These records are not real-world evidence and must not be used to substantiate factual claims.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
from app.services.corpus import add_document

DEMO_DOCS = [
    {
        "title": "Synthetic demo bulletin: Northbridge bus route",
        "publisher": "VeriFact synthetic test corpus",
        "url": "https://example.invalid/demo/northbridge-bus-route",
        "published_at": "2024-03-15",
        "source_type": "synthetic_demo",
        "content": "SYNTHETIC TRAINING EXAMPLE — NOT A REAL-WORLD SOURCE. In the fictional city of Northbridge, a demonstration bulletin says the electric bus route opened in March 2024. Northbridge is an invented place used to test indexing and passage retrieval. This content has no evidentiary value about any actual city or transport service."
    },
    {
        "title": "Synthetic demo planning note: Northbridge transit",
        "publisher": "VeriFact synthetic test corpus",
        "url": "https://example.invalid/demo/northbridge-planning-note",
        "published_at": "2023-10-02",
        "source_type": "synthetic_demo",
        "content": "SYNTHETIC TRAINING EXAMPLE — NOT A REAL-WORLD SOURCE. A fictional planning note for Northbridge describes an electric bus route as planned for the following year. It does not confirm whether the route was ultimately opened. This invented record is designed to demonstrate date-sensitive evidence and insufficient evidence behavior."
    },
    {
        "title": "Synthetic demo note: Bluevale library",
        "publisher": "VeriFact synthetic test corpus",
        "url": "https://example.invalid/demo/bluevale-library",
        "published_at": "2022-11-21",
        "source_type": "synthetic_demo",
        "content": "SYNTHETIC TRAINING EXAMPLE — NOT A REAL-WORLD SOURCE. In the made-up town of Bluevale, a fictional library was scheduled to open on 1 December 2022. This invented note only exercises text extraction, indexing, ranking, and report rendering. Do not cite it as evidence outside software tests."
    },
]

if __name__ == "__main__":
    for item in DEMO_DOCS:
        doc = add_document(**item)
        print(f"Added {doc['id']}: {doc['title']} [{doc['source_type']}]")
    print("Done. Synthetic demo data is not real-world evidence.")
