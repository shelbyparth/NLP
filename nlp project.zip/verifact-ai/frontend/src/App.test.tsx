import { beforeEach, describe, expect, it, vi } from 'vitest'
import { fireEvent, render, screen } from '@testing-library/react'
import App from './App'

function jsonResponse(data: unknown) {
  return new Response(JSON.stringify(data), { status: 200, headers: { 'Content-Type': 'application/json' } })
}

beforeEach(() => {
  vi.stubGlobal('fetch', vi.fn(async (input: RequestInfo | URL) => {
    const url = String(input)
    if (url.endsWith('/api/health')) return jsonResponse({ status: 'ok', service: 'VeriFact AI API', version: '0.1.0', evidence_documents: 0, nli_configured: false, llm_configured: false })
    if (url.endsWith('/api/evidence')) return jsonResponse({ documents: [], count: 0, corpus_mode: 'local_indexed_corpus' })
    if (url.endsWith('/api/history')) return jsonResponse({ checks: [], count: 0 })
    if (url.endsWith('/api/metrics')) return jsonResponse({ status: 'not_run', message: 'No metrics calculated yet.' })
    if (url.endsWith('/api/evaluations')) return jsonResponse({ evaluations: [], count: 0 })
    return jsonResponse({})
  }))
})

describe('VeriFact AI frontend', () => {
  it('renders the evidence-first landing page', async () => {
    render(<App />)
    expect(screen.getByText("Know What's True.")).toBeInTheDocument()
    expect(screen.getByText('Follow the Evidence.')).toBeInTheDocument()
    expect(await screen.findByText('API connected')).toBeInTheDocument()
  })

  it('opens the verification workspace from the navigation', () => {
    render(<App />)
    fireEvent.click(screen.getAllByRole('button', { name: /open dashboard/i })[0])
    expect(screen.getByRole('heading', { name: 'Verification workspace' })).toBeInTheDocument()
    expect(screen.getByRole('heading', { name: 'Investigate a claim' })).toBeInTheDocument()
  })
})
