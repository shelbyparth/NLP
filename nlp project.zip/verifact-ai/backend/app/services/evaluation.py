from __future__ import annotations
from collections import Counter
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, confusion_matrix, classification_report


def evaluate_classifier(
    examples: list[dict],
    test_size: float = 0.25,
    random_state: int = 42,
    dataset_name: str = "User-provided dataset",
    source_description: str = "",
    source_type: str = "manual_json",
) -> dict:
    """Train and evaluate a text baseline without fitting vectorizer on held-out rows."""
    clean: list[tuple[str, str]] = []
    seen_texts: dict[str, str] = {}
    duplicate_rows = 0
    for index, item in enumerate(examples):
        if not isinstance(item, dict):
            raise ValueError(f"Dataset row {index + 1} must be an object with text and label fields.")
        raw_text = item.get("text", item.get("claim", item.get("content", "")))
        raw_label = item.get("label", item.get("verdict", item.get("class", "")))
        text = " ".join(str(raw_text or "").split())
        label = " ".join(str(raw_label or "").split()).lower()
        if not text or not label:
            continue
        normalized = re.sub(r"\s+", " ", text.casefold()).strip()
        previous_label = seen_texts.get(normalized)
        if previous_label is not None:
            if previous_label != label:
                raise ValueError(f"Conflicting labels found for duplicate text at row {index + 1}. Resolve the labels before evaluation.")
            duplicate_rows += 1
            continue
        seen_texts[normalized] = label
        clean.append((text, label))

    counts = Counter(label for _, label in clean)
    if len(clean) < 8:
        raise ValueError("Provide at least 8 unique labeled examples after removing exact duplicate texts; 20 or more is recommended.")
    if len(counts) < 2:
        raise ValueError("The evaluation dataset must contain at least two label classes.")
    if any(count < 2 for count in counts.values()):
        raise ValueError("Each label class must have at least two unique examples for a stratified split.")
    if not 0.1 < test_size < 0.5:
        raise ValueError("test_size must be greater than 0.1 and less than 0.5.")

    texts, labels = zip(*clean)
    n_classes = len(counts)
    test_count = max(n_classes, int(round(len(clean) * test_size)))
    if len(clean) - test_count < n_classes:
        raise ValueError("Not enough unique examples to include every class in both train and test sets.")
    try:
        x_train, x_test, y_train, y_test = train_test_split(
            list(texts), list(labels), test_size=test_count, random_state=random_state, stratify=list(labels)
        )
    except ValueError as exc:
        raise ValueError(f"Could not create a stratified train/test split: {exc}") from exc

    # Vectorization is inside the pipeline, so vocabulary/IDF statistics are fitted on training rows only.
    model = make_pipeline(
        TfidfVectorizer(ngram_range=(1, 2), min_df=1, strip_accents="unicode"),
        LogisticRegression(max_iter=1000, class_weight="balanced", random_state=random_state),
    )
    model.fit(x_train, y_train)
    pred = model.predict(x_test)
    class_order = sorted(set(labels))
    precision, recall, f1, _ = precision_recall_fscore_support(
        y_test, pred, labels=class_order, average="weighted", zero_division=0
    )
    test_examples = len(x_test)
    warnings: list[str] = []
    if len(clean) < 50:
        warnings.append(
            f"Small dataset ({len(clean)} unique examples). Treat this result as a software baseline check, not a reliable estimate of real-world news verification performance."
        )
    if test_examples < 10:
        per_example = 100.0 / max(1, test_examples)
        warnings.append(
            f"Small holdout ({test_examples} test examples): each test prediction changes accuracy by about {per_example:.1f} percentage points. Add more independently labeled examples before drawing conclusions."
        )
    if min(counts.values()) < 5:
        warnings.append("At least one class has fewer than 5 unique examples, so its precision, recall, and F1-score may be especially unstable.")
    if duplicate_rows:
        warnings.append(f"Removed {duplicate_rows} exact duplicate text row(s) before splitting to reduce train/test leakage.")
    warnings.append("The split is stratified and reproducible. Exact duplicate texts are removed before splitting; broader semantic duplicates and source-level grouping are not automatically detected.")

    return {
        "experiment": "tfidf_logistic_regression_baseline",
        "evaluation_method": "stratified_single_holdout",
        "random_state": random_state,
        "requested_test_size": test_size,
        "dataset_examples": len(clean),
        "duplicate_rows_removed": duplicate_rows,
        "train_examples": len(x_train),
        "test_examples": test_examples,
        "label_distribution": dict(counts),
        "metrics": {
            "accuracy": round(float(accuracy_score(y_test, pred)), 4),
            "weighted_precision": round(float(precision), 4),
            "weighted_recall": round(float(recall), 4),
            "weighted_f1": round(float(f1), 4),
        },
        "labels": class_order,
        "confusion_matrix": confusion_matrix(y_test, pred, labels=class_order).tolist(),
        "classification_report": classification_report(y_test, pred, labels=class_order, output_dict=True, zero_division=0),
        "evaluation_warnings": warnings,
        "dataset": {
            "name": str(dataset_name).strip() or "User-provided dataset",
            "source_description": str(source_description).strip(),
            "source_type": str(source_type).strip() or "user_provided",
            "examples_after_deduplication": len(clean),
            "classes": len(class_order),
        },
        "note": "Measured on a randomized stratified holdout from the submitted dataset. This TF-IDF + Logistic Regression classifier is a baseline, not evidence retrieval or a calibrated fact-checking system. Metrics depend on dataset size, label quality, class balance, and the chosen split. The vectorizer is fitted on the training split only.",
    }
