@echo off
setlocal
cd /d "%~dp0frontend"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed or is not on PATH.
  pause
  exit /b 1
)
if not exist "node_modules" (
  echo Installing frontend dependencies...
  call npm install
  if errorlevel 1 goto :failed
)
call npm run dev
exit /b %errorlevel%
:failed
echo Frontend setup failed. Confirm npm can reach the package registry.
pause
exit /b 1
