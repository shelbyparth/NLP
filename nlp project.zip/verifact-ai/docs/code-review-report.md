# VeriFact AI — Code Review and Validation Report

Date: 10 October 2026

## Changes made

- Made optional NLI model loading observable through `GET /api/nli/status` and health metadata. When dependencies, model downloads, or label mapping are unavailable, the classifier abstains and emits a diagnostic instead of silently implying that stance was assessed.
- Added conservative normalization for support/entailment, contradiction/refutation, and neutral labels. Low-confidence, generic-label, and model-loading cases remain unassessed.
- Changed verification to compare evidence passages to each extracted claim separately. The response includes claim-level assessments. Multi-claim reports do not inherit the first claim's stance; the overall verdict remains insufficient when one or more claims cannot be assessed.
- Added explicit evaluation warnings for tiny data sets and small holdouts, and described the result as a TF-IDF + Logistic Regression baseline rather than proof of factual accuracy.
- Updated frontend result types and views to show per-claim assessments, evidence-to-claim association, neutral stance, and evaluation warnings.
- Added `backend/requirements-nli.txt` and documented optional NLI setup. The NLI model remains optional so the base app can run without large model weights.
- Added backend regression tests for NLI status, label normalization, neutral stance, model-load failure, conservative multi-claim aggregation, and small evaluation-set warnings.

## Validation completed in this environment

- Backend pytest suite: **19 passed**.
- Python compile checks: passed.
- API smoke checks: passed for health, NLI status, evidence add/list/search, verification and claim assessment, claim extraction, sentiment, language detection, safe handling of unconfigured translation, TXT upload, and evidence deletion.
- TypeScript/TSX syntax parsing: passed for 7 frontend source files.

## Validation limitations

- `npm install` could not resolve `registry.npmjs.org` in the review environment (`EAI_AGAIN` DNS failure). Therefore `npm run build` and `npm test` are **not verified here**; run them on a machine with npm registry access.
- Actual NLI model weights were not downloaded or run. Backend tests mock the model to verify stance mapping and safe failure behavior. The optional NLI feature still needs model installation/download and a real end-to-end test on the target machine.
- No real labeled news dataset was run. Synthetic demo examples validate workflow behavior only, not real-world fact-checking accuracy.
- No live web-evidence provider is configured by default; the evidence library starts empty, and users must add trustworthy evidence sources.

## Windows setup after extracting the ZIP

Open one PowerShell terminal for the backend:

```powershell
cd .\verifact-ai\backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env
python -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

Open a second PowerShell terminal for the frontend:

```powershell
cd .\verifact-ai\frontend
npm install
npm run dev
```

Open `http://localhost:5173`. API docs are at `http://127.0.0.1:8000/docs`.

### Optional NLI setup

Stop the backend, then from `verifact-ai\backend` run:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-nli.txt
notepad .env
```

Add or uncomment this setting in `backend/.env`:

```env
VERIFACT_NLI_MODEL=cross-encoder/nli-distilroberta-base
```

Save the file and restart the backend. The first model load downloads weights from Hugging Face and needs an internet connection, disk space, and RAM. Check `http://127.0.0.1:8000/api/nli/status`. If the model cannot load, the app should continue to abstain rather than guess.

## Academic reporting advice

Do not present the 12-row synthetic classification exercise or any small holdout as a reliable estimate of fake-news detection performance. For a credible evaluation, select an appropriate real dataset, document its license and class definition, split it to avoid data leakage, report class-wise metrics and a confusion matrix, and separately evaluate evidence retrieval and stance classification.
