from __future__ import annotations
import csv
import io
import json
from pathlib import Path
from datetime import datetime, timezone
from fastapi import APIRouter, HTTPException, UploadFile, File, Query, Form, Response
from pydantic import BaseModel, Field
from ..schemas.models import VerifyRequest, ExtractTextRequest, ExtractClaimsRequest, SearchEvidenceRequest, EvidenceCreate, EvidenceBatchCreate
from ..services.preprocessing import normalize_text, html_to_text
from ..services.web_extraction import fetch_article
from ..services.claim_extraction import extract_claims
from ..services.entity_extraction import extract_entities
from ..services.corpus import load_documents, add_document, delete_document
from ..services.retrieval import search_evidence
from ..services.verification import verify_request
from ..services.stance_classification import nli_runtime_status
from ..services.auxiliary import analyze_sentiment, detect_language
from ..services.evaluation import evaluate_classifier
from ..services.topic_modeling import run_topic_modeling
from ..services.news_tools import summarize_text, answer_from_evidence
from ..services.news_search import search_latest_news
from ..config import METRICS_PATH, TAVILY_API_KEY
from ..db.history import list_results, count_results, clear_history, save_evaluation, list_evaluations, get_evaluation

router = APIRouter(prefix="/api")

class EvaluationRequest(BaseModel):
    examples: list[dict] = Field(min_length=8, max_length=100000)
    test_size: float = Field(default=0.25, gt=0.1, lt=0.5)
    random_state: int = Field(default=42, ge=0, le=4294967295)
    dataset_name: str = Field(default="Manual JSON dataset", max_length=200)
    source_description: str = Field(default="", max_length=1000)

@router.get("/health")
def health():
    docs = load_documents()
    nli_status = nli_runtime_status()
    return {
        "status": "ok",
        "service": "VeriFact AI API",
        "version": "0.1.0",
        "evidence_documents": len(docs),
        "nli_configured": nli_status["configured"],
        "nli_status": nli_status["status"],
        "nli_model": nli_status["model"],
        "llm_configured": all(__import__("os").getenv(k, "").strip() for k in ("VERIFACT_LLM_BASE_URL", "VERIFACT_LLM_API_KEY", "VERIFACT_LLM_MODEL")),
        "tavily_configured": bool(TAVILY_API_KEY),
    }

@router.get("/nli/status")
def nli_status():
    """Report NLI configuration without loading/downloading the model."""
    return nli_runtime_status()

@router.post("/verify")
def verify(req: VerifyRequest):
    if not req.text and not req.url:
        raise HTTPException(422, "Provide text or a public article URL.")
    if req.text and req.url:
        raise HTTPException(422, "Provide either text or URL, not both.")
    try:
        return verify_request(req.text, req.url, req.top_k, req.include_history)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    except Exception as exc:
        raise HTTPException(500, f"Verification failed safely: {type(exc).__name__}. Check server logs for local debugging.") from exc

@router.post("/extract-text")
def extract_text(req: ExtractTextRequest):
    if not req.text and not req.url:
        raise HTTPException(422, "Provide text or a public article URL.")
    if req.text and req.url:
        raise HTTPException(422, "Provide either text or URL, not both.")
    if req.url:
        try:
            return fetch_article(req.url)
        except Exception as exc:
            raise HTTPException(400, str(exc)) from exc
    return {"url": None, "title": None, "publisher": None, "text": normalize_text(req.text or ""), "method": "user_pasted_text"}

@router.post("/extract-claims")
def claims(req: ExtractClaimsRequest):
    found = extract_claims(req.text)
    for item in found:
        item["entities"] = extract_entities(item["text"])
    return {"claims": found, "count": len(found), "method": "sentence_heuristic", "note": "Review extracted claims before treating them as complete or definitive."}

@router.post("/search-evidence")
def evidence_search(req: SearchEvidenceRequest):
    return {"query": req.query, "results": search_evidence(req.query, req.top_k), "corpus_mode": "local_indexed_corpus"}

@router.get("/evidence")
def get_evidence(limit: int = Query(default=100, ge=1, le=500)):
    docs = load_documents()
    return {"documents": docs[-limit:][::-1], "count": len(docs), "corpus_mode": "local_indexed_corpus"}

@router.post("/evidence")
def create_evidence(req: EvidenceCreate):
    doc = add_document(req.title, req.content, req.url, req.publisher, req.published_at, req.source_type)
    return {"document": doc, "message": "Evidence document added to the local corpus."}

@router.post("/evidence/batch")
def create_evidence_batch(req: EvidenceBatchCreate):
    docs = [add_document(d.title, d.content, d.url, d.publisher, d.published_at, d.source_type) for d in req.documents]
    return {"documents": docs, "count": len(docs)}

@router.post("/evidence/upload")
def upload_evidence(file: UploadFile = File(...)):
    filename = (file.filename or "uploaded.txt").lower()
    if Path(filename).suffix not in {".txt", ".md", ".csv", ".json", ".html", ".htm", ".pdf"}:
        raise HTTPException(415, "Supported formats: TXT, MD, CSV, JSON, HTML, PDF (PDF requires pypdf).")
    raw = file.file.read(5_000_001)
    if len(raw) > 5_000_000:
        raise HTTPException(413, "File is larger than 5 MB.")
    try:
        ext = Path(filename).suffix
        if ext == ".pdf":
            try:
                from pypdf import PdfReader
                reader = PdfReader(io.BytesIO(raw))
                content = "\n".join(page.extract_text() or "" for page in reader.pages)
            except ImportError as exc:
                raise HTTPException(501, "PDF extraction needs pypdf. Install backend requirements and restart.") from exc
        elif ext in {".html", ".htm"}:
            content = html_to_text(raw.decode("utf-8", errors="replace"))
        elif ext == ".csv":
            rows = csv.reader(io.StringIO(raw.decode("utf-8-sig", errors="replace")))
            content = "\n".join(" | ".join(cell for cell in row) for row in rows)
        elif ext == ".json":
            content = json.dumps(json.loads(raw.decode("utf-8-sig")), ensure_ascii=False, indent=2)
        else:
            content = raw.decode("utf-8-sig", errors="replace")
        content = normalize_text(content)
        if len(content) < 20:
            raise HTTPException(400, "The file does not contain enough extractable text.")
        if len(content) > 100000:
            raise HTTPException(413, "Extracted document text exceeds the 100,000-character indexing limit.")
        doc = add_document(Path(filename).stem.replace("_", " "), content, source_type="user_uploaded")
        return {"document": doc, "message": "File text extracted and added to the local evidence corpus."}
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(400, f"Could not parse file: {type(exc).__name__}.") from exc

@router.delete("/evidence/{document_id}")
def remove_evidence(document_id: str):
    if not delete_document(document_id):
        raise HTTPException(404, "Evidence document not found.")
    return {"deleted": document_id}


class NewsTextRequest(BaseModel):
    text: str = Field(min_length=40, max_length=30000)

class AskRequest(BaseModel):
    question: str = Field(min_length=3, max_length=2000)

class NewsSearchRequest(BaseModel):
    query: str = Field(min_length=2, max_length=300)
    max_results: int = Field(default=6, ge=1, le=10)

@router.post("/news/search")
def news_search(req: NewsSearchRequest):
    try:
        return search_latest_news(req.query, req.max_results)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(503, str(exc)) from exc
    except Exception as exc:
        raise HTTPException(502, "The live news provider could not complete the search. Check the API key, network connection and provider status.") from exc

@router.post("/ocr")
def extract_image_text(file: UploadFile = File(...)):
    filename = (file.filename or "upload").lower()
    if Path(filename).suffix not in {".png", ".jpg", ".jpeg", ".webp", ".bmp"}:
        raise HTTPException(415, "Upload a PNG, JPG, JPEG, WEBP or BMP screenshot.")
    raw = file.file.read(5_000_001)
    if len(raw) > 5_000_000:
        raise HTTPException(413, "Image is larger than 5 MB.")
    try:
        from PIL import Image
        import pytesseract
        from ..config import TESSERACT_CMD
        if TESSERACT_CMD:
            pytesseract.pytesseract.tesseract_cmd = TESSERACT_CMD
        image = Image.open(io.BytesIO(raw)).convert("RGB")
        if image.width * image.height > 20_000_000:
            raise HTTPException(413, "Image dimensions are too large for OCR.")
        extracted = normalize_text(pytesseract.image_to_string(image, timeout=15))
        if len(extracted) < 5:
            raise HTTPException(422, "No readable text was detected. Try a clearer screenshot.")
        return {"text": extracted[:30000], "method": "tesseract_ocr", "note": "OCR can misread names, dates and numbers. Review the extracted text before verification."}
    except HTTPException:
        raise
    except ImportError as exc:
        raise HTTPException(501, "Image OCR needs Pillow, pytesseract and the Tesseract OCR application. See README setup instructions.") from exc
    except Exception as exc:
        if type(exc).__name__ in {"TesseractNotFoundError", "TesseractError", "RuntimeError"}:
            raise HTTPException(501, "Tesseract OCR is not installed or failed to run. Install the Tesseract application and restart the backend.") from exc
        raise HTTPException(400, "Could not read this image. Use a standard PNG or JPEG screenshot.") from exc

@router.post("/summarize")
def summarize_news(req: NewsTextRequest):
    try:
        return summarize_text(req.text)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc

@router.post("/ask")
def ask_evidence(req: AskRequest):
    passages = search_evidence(req.question, top_k=4)
    return {"question": req.question, **answer_from_evidence(req.question, passages)}

@router.post("/analyze-sentiment")
def sentiment(req: ExtractClaimsRequest):
    return analyze_sentiment(req.text)

@router.post("/detect-language")
def language(req: ExtractClaimsRequest):
    return detect_language(req.text)

class TranslateRequest(BaseModel):
    text: str = Field(min_length=1, max_length=30000)
    target_language: str = Field(min_length=2, max_length=80)

@router.post("/translate")
def translate(req: TranslateRequest):
    from ..config import LLM_API_KEY, LLM_BASE_URL, LLM_MODEL
    if not (LLM_BASE_URL and LLM_API_KEY and LLM_MODEL):
        raise HTTPException(503, "Translation requires a configured OpenAI-compatible LLM provider. Set VERIFACT_LLM_BASE_URL, VERIFACT_LLM_API_KEY and VERIFACT_LLM_MODEL on the backend.")
    from ..services.translation import translate_text
    try:
        return translate_text(req.text, req.target_language)
    except Exception as exc:
        raise HTTPException(502, "The configured translation provider failed.") from exc

@router.get("/history")
def history(limit: int = Query(default=30, ge=1, le=100)):
    try:
        items = list_results(limit)
        return {"checks": items, "count": len(items), "total_count": count_results()}
    except Exception as exc:
        raise HTTPException(500, "Unable to read local history database.") from exc

@router.delete("/history")
def delete_history():
    try:
        return {"deleted_count": clear_history()}
    except Exception as exc:
        raise HTTPException(500, "Unable to clear local history database.") from exc

def _persist_evaluation(result: dict) -> None:
    """Persist the latest result and append a durable history record."""
    METRICS_PATH.parent.mkdir(parents=True, exist_ok=True)
    temp_path = METRICS_PATH.with_suffix(".tmp")
    temp_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    temp_path.replace(METRICS_PATH)
    save_evaluation(result)


def _run_and_store_evaluation(
    examples: list[dict],
    test_size: float,
    random_state: int,
    dataset_name: str,
    source_description: str,
    source_type: str,
) -> dict:
    from uuid import uuid4
    result = evaluate_classifier(
        examples,
        test_size=test_size,
        random_state=random_state,
        dataset_name=dataset_name,
        source_description=source_description,
        source_type=source_type,
    )
    result["evaluation_id"] = f"eval_{uuid4().hex[:16]}"
    result["evaluated_at"] = datetime.now(timezone.utc).isoformat()
    _persist_evaluation(result)
    return result


@router.post("/evaluate")
def evaluate(req: EvaluationRequest):
    try:
        return _run_and_store_evaluation(
            req.examples, req.test_size, req.random_state,
            req.dataset_name, req.source_description, "manual_json",
        )
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    except OSError as exc:
        raise HTTPException(500, "Evaluation was completed but its result could not be persisted.") from exc


@router.post("/evaluate/upload")
def evaluate_upload(
    file: UploadFile = File(...),
    dataset_name: str | None = Form(default=None, max_length=200),
    source_description: str = Form(default="", max_length=1000),
    text_field: str = Form(default="text", max_length=100),
    label_field: str = Form(default="label", max_length=100),
    test_size: float = Form(default=0.25),
    random_state: int = Form(default=42, ge=0, le=4294967295),
):
    """Evaluate a labeled CSV, JSON array/object, or JSONL dataset."""
    filename = Path(file.filename or "dataset.csv").name
    extension = Path(filename).suffix.lower()
    if extension not in {".csv", ".json", ".jsonl"}:
        raise HTTPException(415, "Supported evaluation datasets: CSV, JSON, and JSONL.")
    raw = file.file.read(10_000_001)
    if len(raw) > 10_000_000:
        raise HTTPException(413, "Dataset file is larger than 10 MB.")
    if not text_field.strip() or not label_field.strip():
        raise HTTPException(400, "Text field and label field names cannot be empty.")
    try:
        decoded = raw.decode("utf-8-sig")
        if extension == ".csv":
            reader = csv.DictReader(io.StringIO(decoded))
            if not reader.fieldnames:
                raise ValueError("The CSV file must include a header row.")
            if text_field not in reader.fieldnames or label_field not in reader.fieldnames:
                raise ValueError(f"CSV must contain the selected columns '{text_field}' and '{label_field}'. Available columns: {', '.join(reader.fieldnames)}.")
            examples = [{"text": row.get(text_field, ""), "label": row.get(label_field, "")} for row in reader]
        elif extension == ".jsonl":
            examples = [json.loads(line) for line in decoded.splitlines() if line.strip()]
        else:
            payload = json.loads(decoded)
            examples = payload if isinstance(payload, list) else payload.get("examples", payload.get("data")) if isinstance(payload, dict) else None
        if not isinstance(examples, list):
            raise ValueError("JSON must be an array of objects or an object containing an 'examples' or 'data' array.")
        if len(examples) > 100000:
            raise ValueError("Dataset contains more than 100,000 rows. Upload a smaller documented subset.")
        normalized_examples = []
        for index, item in enumerate(examples):
            if not isinstance(item, dict):
                raise ValueError(f"Dataset row {index + 1} must be a JSON object.")
            normalized_examples.append({"text": item.get(text_field, item.get("text", item.get("claim", ""))), "label": item.get(label_field, item.get("label", item.get("verdict", "")))})
        return _run_and_store_evaluation(
            normalized_examples,
            test_size,
            random_state,
            (dataset_name or Path(filename).stem)[:200],
            source_description,
            f"uploaded_{extension.lstrip('.')}",
        )
    except (UnicodeDecodeError, json.JSONDecodeError, csv.Error) as exc:
        raise HTTPException(400, f"Could not parse evaluation dataset: {type(exc).__name__}.") from exc
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    except OSError as exc:
        raise HTTPException(500, "Evaluation was completed but its result could not be persisted.") from exc


@router.get("/evaluations")
def evaluation_history(limit: int = Query(default=20, ge=1, le=100)):
    try:
        runs = list_evaluations(limit)
        return {"evaluations": runs, "count": len(runs)}
    except Exception as exc:
        raise HTTPException(500, "Unable to read evaluation history.") from exc


def _find_evaluation_or_404(evaluation_id: str) -> dict:
    result = get_evaluation(evaluation_id)
    if result is None:
        raise HTTPException(404, "Evaluation run not found.")
    return result


@router.get("/evaluations/{evaluation_id}")
def get_evaluation_result(evaluation_id: str):
    return _find_evaluation_or_404(evaluation_id)


@router.get("/evaluations/{evaluation_id}/report.csv")
def download_evaluation_csv(evaluation_id: str):
    result = _find_evaluation_or_404(evaluation_id)
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow(["VeriFact AI evaluation report"])
    writer.writerow(["Evaluation ID", result.get("evaluation_id", "")])
    writer.writerow(["Evaluated at", result.get("evaluated_at", "")])
    writer.writerow(["Dataset", result.get("dataset", {}).get("name", "")])
    writer.writerow(["Source type", result.get("dataset", {}).get("source_type", "")])
    writer.writerow(["Source description", result.get("dataset", {}).get("source_description", "")])
    writer.writerow(["Dataset examples", result.get("dataset_examples", 0)])
    writer.writerow(["Train examples", result.get("train_examples", 0)])
    writer.writerow(["Test examples", result.get("test_examples", 0)])
    writer.writerow([])
    writer.writerow(["Metric", "Value"])
    for key, value in result.get("metrics", {}).items():
        writer.writerow([key, value])
    writer.writerow([])
    writer.writerow(["Class", "Precision", "Recall", "F1-score", "Support"])
    report = result.get("classification_report", {})
    for label in result.get("labels", []):
        row = report.get(label, {})
        writer.writerow([label, row.get("precision", 0), row.get("recall", 0), row.get("f1-score", 0), row.get("support", 0)])
    writer.writerow([])
    labels = result.get("labels", [])
    writer.writerow(["Confusion matrix: actual rows, predicted columns", *labels])
    for label, values in zip(labels, result.get("confusion_matrix", [])):
        writer.writerow([label, *values])
    writer.writerow([])
    writer.writerow(["Warnings"])
    for warning in result.get("evaluation_warnings", []):
        writer.writerow([warning])
    payload = "\ufeff" + output.getvalue()
    filename = f"verifact-evaluation-{evaluation_id}.csv"
    return Response(payload, media_type="text/csv; charset=utf-8", headers={"Content-Disposition": f'attachment; filename="{filename}"'})


@router.get("/evaluations/{evaluation_id}/report.pdf")
def download_evaluation_pdf(evaluation_id: str):
    result = _find_evaluation_or_404(evaluation_id)
    try:
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.lib.units import mm
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
        from xml.sax.saxutils import escape
    except ImportError as exc:
        raise HTTPException(501, "PDF report generation requires reportlab. Install backend requirements and restart.") from exc

    buffer = io.BytesIO()
    document = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=18 * mm, leftMargin=18 * mm, topMargin=16 * mm, bottomMargin=16 * mm)
    styles = getSampleStyleSheet()
    story = [Paragraph("VeriFact AI – Evaluation Report", styles["Title"]), Spacer(1, 5 * mm)]
    dataset = result.get("dataset", {})
    metadata = [
        ["Dataset", str(dataset.get("name", "Not provided"))],
        ["Source type", str(dataset.get("source_type", "Not provided"))],
        ["Source notes", Paragraph(escape(str(dataset.get("source_description", ""))) or "Not provided", styles["BodyText"])],
        ["Evaluated at", str(result.get("evaluated_at", ""))],
        ["Evaluation ID", str(result.get("evaluation_id", ""))],
        ["Examples", f"{result.get('dataset_examples', 0)} total · {result.get('train_examples', 0)} train · {result.get('test_examples', 0)} test"],
        ["Method", str(result.get("evaluation_method", ""))],
    ]
    meta_table = Table(metadata, colWidths=[38 * mm, 135 * mm])
    meta_table.setStyle(TableStyle([("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#edf2f7")), ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#cbd5e1")), ("VALIGN", (0, 0), (-1, -1), "TOP"), ("PADDING", (0, 0), (-1, -1), 6)]))
    story.extend([meta_table, Spacer(1, 6 * mm), Paragraph("Overall metrics", styles["Heading2"])])
    metric_rows = [["Metric", "Score"]] + [[key.replace("_", " ").title(), f"{float(value):.4f}"] for key, value in result.get("metrics", {}).items()]
    metric_table = Table(metric_rows, colWidths=[90 * mm, 40 * mm])
    metric_table.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#172033")), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white), ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#cbd5e1")), ("PADDING", (0, 0), (-1, -1), 6)]))
    story.extend([metric_table, Spacer(1, 6 * mm), Paragraph("Per-class results", styles["Heading2"])])
    report = result.get("classification_report", {})
    class_rows = [["Class", "Precision", "Recall", "F1", "Support"]]
    for label in result.get("labels", []):
        row = report.get(label, {})
        class_rows.append([str(label), f"{float(row.get('precision', 0)):.3f}", f"{float(row.get('recall', 0)):.3f}", f"{float(row.get('f1-score', 0)):.3f}", str(row.get("support", 0))])
    class_table = Table(class_rows, repeatRows=1, colWidths=[50 * mm, 30 * mm, 30 * mm, 25 * mm, 25 * mm])
    class_table.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#172033")), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white), ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#cbd5e1")), ("PADDING", (0, 0), (-1, -1), 5)]))
    story.extend([class_table, Spacer(1, 6 * mm), Paragraph("Confusion matrix (actual rows, predicted columns)", styles["Heading2"])])
    labels = result.get("labels", [])
    cm_rows = [["Actual / Predicted", *labels]] + [[label, *values] for label, values in zip(labels, result.get("confusion_matrix", []))]
    cm_table = Table(cm_rows, repeatRows=1)
    cm_table.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#172033")), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white), ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#cbd5e1")), ("PADDING", (0, 0), (-1, -1), 5)]))
    story.append(cm_table)
    warnings = result.get("evaluation_warnings", [])
    if warnings:
        story.extend([Spacer(1, 6 * mm), Paragraph("Interpretation warnings", styles["Heading2"])])
        story.extend(Paragraph("• " + str(item), styles["BodyText"]) for item in warnings)
    story.extend([Spacer(1, 6 * mm), Paragraph(str(result.get("note", "")), styles["Italic"])])
    document.build(story)
    filename = f"verifact-evaluation-{evaluation_id}.pdf"
    return Response(buffer.getvalue(), media_type="application/pdf", headers={"Content-Disposition": f'attachment; filename="{filename}"'})


@router.post("/topics")
def topic_model(topics: int = Query(default=4, ge=2, le=8)):
    try:
        return run_topic_modeling(topics)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc

@router.get("/metrics")
def metrics():
    if METRICS_PATH.exists():
        try:
            result = json.loads(METRICS_PATH.read_text(encoding="utf-8"))
            return {"status": "completed", "message": "Latest stored TF-IDF + Logistic Regression holdout evaluation.", "available_baseline": "TF-IDF + Logistic Regression", "result": result}
        except (OSError, json.JSONDecodeError):
            pass
    return {"status": "not_run", "message": "No evaluation metrics are shown until POST /api/evaluate is run with a labeled dataset.", "available_baseline": "TF-IDF + Logistic Regression"}
