import type { EvidenceDocument, EvaluationResult, VerificationResult } from '../types'

const API_BASE = (import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000').replace(/\/$/, '')

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const response = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: { ...(options.body instanceof FormData ? {} : { 'Content-Type': 'application/json' }), ...options.headers },
  })
  const payload = await response.json().catch(() => ({}))
  if (!response.ok) throw new Error(payload.detail || `Request failed (${response.status})`)
  return payload as T
}

export const api = {
  health: () => request<{ status: string; evidence_documents: number; nli_configured: boolean; llm_configured: boolean; tavily_configured: boolean }>('/api/health'),
  verify: (text: string, topK = 5) => request<VerificationResult>('/api/verify', { method: 'POST', body: JSON.stringify({ text, top_k: topK }) }),
  verifyUrl: (url: string, topK = 5) => request<VerificationResult>('/api/verify', { method: 'POST', body: JSON.stringify({ url, top_k: topK }) }),
  evidence: () => request<{ documents: EvidenceDocument[]; count: number }>('/api/evidence'),
  addEvidence: (payload: { title: string; content: string; url?: string; publisher?: string; published_at?: string }) => request<{ document: EvidenceDocument }>('/api/evidence', { method: 'POST', body: JSON.stringify(payload) }),
  uploadEvidence: (file: File) => {
    const data = new FormData(); data.append('file', file)
    return request<{ document: EvidenceDocument; message: string }>('/api/evidence/upload', { method: 'POST', body: data })
  },
  deleteEvidence: (id: string) => request<{ deleted: string }>(`/api/evidence/${encodeURIComponent(id)}`, { method: 'DELETE' }),
  extractClaims: (text: string) => request<{ claims: VerificationResult['claims']; count: number; note: string }>('/api/extract-claims', { method: 'POST', body: JSON.stringify({ text }) }),
  history: () => request<{ checks: VerificationResult[]; count: number; total_count: number }>('/api/history?limit=100'),
  clearHistory: () => request<{ deleted_count: number }>('/api/history', { method: 'DELETE' }),
  metrics: () => request<{ status: string; message: string; result?: EvaluationResult }>('/api/metrics'),
  evaluate: (examples: Array<{ text: string; label: string }>, datasetName = 'Manual JSON dataset', sourceDescription = '') => request<EvaluationResult>('/api/evaluate', { method: 'POST', body: JSON.stringify({ examples, dataset_name: datasetName, source_description: sourceDescription }) }),
  uploadEvaluation: (file: File, options: { datasetName?: string; sourceDescription?: string; textField?: string; labelField?: string } = {}) => {
    const data = new FormData(); data.append('file', file)
    if (options.datasetName) data.append('dataset_name', options.datasetName)
    if (options.sourceDescription) data.append('source_description', options.sourceDescription)
    data.append('text_field', options.textField || 'text'); data.append('label_field', options.labelField || 'label')
    return request<EvaluationResult>('/api/evaluate/upload', { method: 'POST', body: data })
  },
  evaluations: () => request<{ evaluations: EvaluationResult[]; count: number }>('/api/evaluations'),
  getEvaluation: (id: string) => request<EvaluationResult>(`/api/evaluations/${encodeURIComponent(id)}`),
  topics: (count = 4) => request<Record<string, unknown>>(`/api/topics?topics=${count}`, { method: 'POST' }),
  sentiment: (text: string) => request<{ label: string; score: number; positive_hits: number; negative_hits: number; method: string; warning: string }>('/api/analyze-sentiment', { method: 'POST', body: JSON.stringify({ text }) }),
  detectLanguage: (text: string) => request<{ language_code: string; method: string; warning?: string | null }>('/api/detect-language', { method: 'POST', body: JSON.stringify({ text }) }),
  summarize: (text: string) => request<{ summary: string; detailed_summary: string; key_points: string[]; method: string; note: string }>('/api/summarize', { method: 'POST', body: JSON.stringify({ text }) }),
  ask: (question: string) => request<{ question: string; answer: string; sources: Array<{ title: string; publisher?: string; url?: string; excerpt: string }>; grounded: boolean; generated?: boolean; note?: string }>('/api/ask', { method: 'POST', body: JSON.stringify({ question }) }),
  newsSearch: (query: string) => request<{ query: string; results: Array<{ title: string; url: string; content: string; published_date?: string | null; score?: number | null }>; count: number; note: string }>('/api/news/search', { method: 'POST', body: JSON.stringify({ query, max_results: 8 }) }),
  ocr: (file: File) => { const data = new FormData(); data.append('file', file); return request<{ text: string; method: string; note: string }>('/api/ocr', { method: 'POST', body: data }) },
  translate: (text: string, target_language: string) => request<{ translated_text: string; source_text: string; target_language: string; note: string }>('/api/translate', { method: 'POST', body: JSON.stringify({ text, target_language }) }),
}
