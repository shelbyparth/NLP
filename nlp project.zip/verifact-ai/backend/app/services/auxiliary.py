from __future__ import annotations
import re
import os
from functools import lru_cache
from .preprocessing import normalize_text

POSITIVE = {"good", "great", "excellent", "beneficial", "success", "successful", "improved", "improvement", "safe", "accurate", "positive", "effective", "strong", "support", "supports", "confirmed", "verified", "win"}
NEGATIVE = {"bad", "fake", "false", "misleading", "dangerous", "harmful", "failure", "failed", "negative", "wrong", "fraud", "lie", "lying", "corrupt", "unsafe", "contradict", "contradicted", "crisis", "deadly"}


@lru_cache(maxsize=2)
def _sentiment_pipeline(model_name: str):
    """Load an optional Transformers sentiment model once per configured model."""
    from transformers import pipeline
    return pipeline("sentiment-analysis", model=model_name, device=-1)


def analyze_sentiment(text: str) -> dict:
    model_name = os.getenv("VERIFACT_SENTIMENT_MODEL", "").strip()
    if model_name:
        try:
            result = _sentiment_pipeline(model_name)(normalize_text(text)[:4000], truncation=True)[0]
            raw_label = str(result.get("label", "")).strip().lower()
            label = next((name for name in ("positive", "negative", "neutral") if name in raw_label), None)
            if label:
                return {
                    "label": label,
                    "score": round(float(result.get("score", 0.0)), 4),
                    "method": "transformers_sentiment_model",
                    "model": model_name,
                    "warning": "Sentiment describes tone, not factual truth. Model confidence is not claim-verification confidence.",
                }
        except Exception as exc:
            model_error = type(exc).__name__
        else:
            model_error = "UnrecognizedSentimentLabel"
    else:
        model_error = None

    tokens = re.findall(r"[a-zA-Z]+", normalize_text(text).lower())
    if not tokens:
        return {"label": "neutral", "score": 0.0, "method": "transparent_lexicon_baseline", "warning": "This simple baseline is not a trained sentiment model and does not assess factual truth."}
    pos = sum(t in POSITIVE for t in tokens)
    neg = sum(t in NEGATIVE for t in tokens)
    denom = max(1, pos + neg)
    score = round((pos - neg) / denom, 3)
    label = "positive" if score > 0.15 else "negative" if score < -0.15 else "neutral"
    response = {"label": label, "score": score, "positive_hits": pos, "negative_hits": neg, "method": "transparent_lexicon_baseline", "warning": "This simple baseline is not a trained sentiment model and does not assess factual truth."}
    if model_name:
        response["model_fallback"] = True
        response["model_error_type"] = model_error
    return response


def detect_language(text: str) -> dict:
    try:
        from langdetect import detect, DetectorFactory
        DetectorFactory.seed = 13
        code = detect(text)
        return {"language_code": code, "method": "langdetect", "warning": None}
    except Exception:
        sample = text or ""
        if re.search(r"[\u0900-\u097F]", sample):
            return {"language_code": "hi-or-mr", "method": "unicode_script_fallback", "warning": "This fallback detects Devanagari script only and cannot reliably distinguish Hindi from Marathi."}
        if re.search(r"[a-zA-Z]", sample):
            return {"language_code": "en-or-other-latin", "method": "unicode_script_fallback", "warning": "Install langdetect for actual language identification; this fallback only detects Latin-script text."}
        return {"language_code": "unknown", "method": "unicode_script_fallback", "warning": "Unable to identify language. Install langdetect for broader support."}
