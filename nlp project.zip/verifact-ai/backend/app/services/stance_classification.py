from __future__ import annotations

import os
import re
from functools import lru_cache


_MODEL_STATUS: dict[str, dict] = {}


@lru_cache(maxsize=4)
def _nli_components(model_name: str):
    """Load an optional Hugging Face NLI model once per model name.

    The second tuple field is a safe diagnostic code rather than the full
    exception text, which could include local paths or remote details.
    """
    if not model_name:
        return None, "not_configured"
    try:
        import torch
        from transformers import AutoModelForSequenceClassification, AutoTokenizer

        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModelForSequenceClassification.from_pretrained(model_name)
        model.eval()
        _MODEL_STATUS[model_name] = {"status": "loaded", "error_type": None}
        return (torch, tokenizer, model), None
    except Exception as exc:  # optional ML dependencies/model downloads must fail safely
        error_type = type(exc).__name__
        _MODEL_STATUS[model_name] = {"status": "load_error", "error_type": error_type}
        return None, error_type


def _map_label(raw_label: str) -> str:
    label = raw_label.strip().lower().replace("_", " ").replace("-", " ")
    if any(term in label for term in ("entailment", "entailed", "supports", "support")):
        return "supports"
    if any(term in label for term in ("contradiction", "contradict", "refutes", "refutation")):
        return "contradicts"
    if "neutral" in label:
        return "neutral"
    return "unknown"


def classify_stance(claim: str, evidence: str) -> dict:
    """Compare evidence (premise) with a claim (hypothesis) using optional NLI.

    Unknown is returned whenever the model is not configured, cannot load,
    exposes unrecognized labels, or is not confident enough. This avoids
    treating retrieval similarity as evidence that a claim is true.
    """
    model_name = os.getenv("VERIFACT_NLI_MODEL", "").strip()
    components, load_error = _nli_components(model_name)
    if not model_name:
        return {"stance": "unknown", "score": None, "method": "not_configured"}
    if components is None:
        return {
            "stance": "unknown",
            "score": None,
            "method": "nli_load_error",
            "error_type": load_error or "UnknownError",
        }

    torch, tokenizer, model = components
    try:
        # NLI models conventionally consume premise first and hypothesis second.
        inputs = tokenizer(evidence, claim, return_tensors="pt", truncation=True, max_length=512)
        with torch.no_grad():
            logits = model(**inputs).logits[0]
            probs = torch.softmax(logits, dim=-1).tolist()

        labels = getattr(model.config, "id2label", {}) or {}
        mapped = []
        for idx, prob in enumerate(probs):
            raw = str(labels.get(idx, labels.get(str(idx), "")))
            stance = _map_label(raw)
            mapped.append((stance, float(prob), raw))

        recognized = [
            item for item in mapped
            if item[2] and not re.fullmatch(r"label[ _-]*\d+", item[2].strip().lower())
        ]
        if not recognized:
            return {"stance": "unknown", "score": None, "method": "nli_label_mapping_unknown"}

        # If labels are partially recognized but an unrecognized label wins,
        # abstain rather than silently converting an unknown class to a verdict.
        best = max(mapped, key=lambda item: item[1])
        if not best[2] or _map_label(best[2]) == "unknown" and "neutral" not in best[2].lower():
            return {"stance": "unknown", "score": round(best[1], 4), "method": "nli_label_mapping_unknown", "raw_label": best[2]}
        if best[1] < 0.55:
            return {"stance": "unknown", "score": round(best[1], 4), "method": "nli", "raw_label": best[2]}
        return {"stance": best[0], "score": round(best[1], 4), "method": "nli", "raw_label": best[2]}
    except Exception as exc:
        return {"stance": "unknown", "score": None, "method": "nli_inference_error", "error_type": type(exc).__name__}


def nli_runtime_status() -> dict:
    """Return configuration/cache status without forcing a multi-GB model load."""
    model_name = os.getenv("VERIFACT_NLI_MODEL", "").strip()
    if not model_name:
        return {"configured": False, "status": "not_configured", "model": None}
    cache_info = _nli_components.cache_info()
    model_state = _MODEL_STATUS.get(model_name, {})
    return {
        "configured": True,
        "status": model_state.get("status", "configured_lazy_load"),
        "model": model_name,
        "error_type": model_state.get("error_type"),
        "cached_model_entries": cache_info.currsize,
    }
