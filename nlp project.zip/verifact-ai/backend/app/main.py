from __future__ import annotations
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .config import FRONTEND_ORIGINS
from .api.routes import router

app = FastAPI(
    title="VeriFact AI API",
    description="Evidence-based claim verification using local corpus retrieval, optional NLI, and optional grounded LLM explanations.",
    version="0.1.0",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=FRONTEND_ORIGINS,
    allow_credentials=False,
    allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization"],
)
app.include_router(router)

@app.get("/")
def root():
    return {"service": "VeriFact AI API", "docs": "/docs", "health": "/api/health"}
