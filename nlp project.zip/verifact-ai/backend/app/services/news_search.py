from __future__ import annotations

import requests
from ..config import TAVILY_API_KEY, TAVILY_API_URL


def search_latest_news(query: str, max_results: int = 6) -> dict:
    """Search live news through Tavily. No demo or fabricated results are returned."""
    if not TAVILY_API_KEY:
        raise RuntimeError("Live news search is not configured. Add TAVILY_API_KEY to backend/.env and restart the backend.")
    clean_query = " ".join(query.split())[:300]
    if len(clean_query) < 2:
        raise ValueError("Enter a category or topic to search.")
    response = requests.post(
        TAVILY_API_URL,
        headers={"Authorization": f"Bearer {TAVILY_API_KEY}", "Content-Type": "application/json"},
        json={"query": clean_query, "topic": "news", "search_depth": "basic", "max_results": max(1, min(max_results, 10)), "include_answer": False, "include_raw_content": False},
        timeout=(5, 25),
    )
    response.raise_for_status()
    payload = response.json()
    results = []
    for item in payload.get("results", []):
        url = item.get("url")
        title = item.get("title")
        if not isinstance(url, str) or not url.startswith(("https://", "http://")) or not isinstance(title, str):
            continue
        results.append({"title": title[:300], "url": url, "content": str(item.get("content") or "")[:1400], "published_date": item.get("published_date"), "score": item.get("score")})
    return {"query": clean_query, "results": results, "count": len(results), "provider": "Tavily", "note": "Live search results are candidate articles, not verified facts. Open sources and check publication dates before sharing."}
