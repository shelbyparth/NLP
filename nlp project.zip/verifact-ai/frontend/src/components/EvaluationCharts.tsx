type EvaluationResult = {
  evaluation_id?: string
  evaluated_at?: string
  dataset_examples: number
  train_examples: number
  test_examples: number
  duplicate_rows_removed?: number
  metrics: Record<string, number>
  labels: string[]
  label_distribution: Record<string, number>
  confusion_matrix: number[][]
  classification_report: Record<string, Record<string, number>>
  evaluation_warnings: string[]
  dataset?: { name?: string; source_type?: string; source_description?: string }
}

type EvaluationHistoryItem = EvaluationResult & { evaluation_id: string; evaluated_at: string }

const metricNames: Record<string, string> = {
  accuracy: 'Accuracy',
  weighted_precision: 'Weighted precision',
  weighted_recall: 'Weighted recall',
  weighted_f1: 'Weighted F1',
}
const chartColors = ['#2563eb', '#0f9d8a', '#d97706', '#7c3aed', '#dc5b65', '#64748b', '#0891b2']
const percent = (value: number) => `${(Math.max(0, Math.min(1, Number(value) || 0)) * 100).toFixed(1)}%`

function MetricBars({ metrics }: { metrics: Record<string, number> }) {
  return <div className="eval-chart-card">
    <div className="eval-chart-heading"><h4>Overall performance</h4><span>0–100% scale</span></div>
    <div className="metric-bars">{Object.entries(metricNames).map(([key, label]) => {
      const value = Number(metrics[key] ?? 0)
      return <div className="metric-bar-row" key={key}>
        <div className="metric-bar-label"><span>{label}</span><b>{percent(value)}</b></div>
        <div className="metric-bar-track"><span style={{ width: `${Math.max(0, Math.min(1, value)) * 100}%` }} /></div>
      </div>
    })}</div>
  </div>
}

function ConfusionHeatmap({ labels, matrix }: { labels: string[]; matrix: number[][] }) {
  const maximum = Math.max(1, ...matrix.flat().map(Number))
  return <div className="eval-chart-card">
    <div className="eval-chart-heading"><h4>Confusion matrix</h4><span>Rows: actual · Columns: predicted</span></div>
    <div className="confusion-scroll"><table className="confusion-table"><thead><tr><th>Actual \ Predicted</th>{labels.map(label => <th key={label}>{label.replaceAll('_', ' ')}</th>)}</tr></thead>
      <tbody>{labels.map((label, i) => <tr key={label}><th>{label.replaceAll('_', ' ')}</th>{labels.map((column, j) => {
        const value = Number(matrix[i]?.[j] ?? 0)
        const intensity = value / maximum
        return <td key={column} style={{ backgroundColor: `rgba(15, 120, 105, ${0.08 + intensity * 0.72})`, color: intensity > 0.52 ? '#ffffff' : '#172033' }}><b>{value}</b></td>
      })}</tr>)}</tbody></table></div>
    <p className="eval-chart-note">Correct predictions appear on the diagonal. Off-diagonal cells show which classes the model confused.</p>
  </div>
}

function ClassMetrics({ labels, report }: { labels: string[]; report: Record<string, Record<string, number>> }) {
  return <div className="eval-chart-card">
    <div className="eval-chart-heading"><h4>Class-wise performance</h4><span>Precision, recall and F1</span></div>
    <div className="class-metric-list">{labels.map((label, index) => {
      const row = report[label] || {}
      return <div className="class-metric-row" key={label}>
        <div className="class-metric-title"><b>{label.replaceAll('_', ' ')}</b><small>Support: {Number(row.support || 0)}</small></div>
        <div className="class-metric-bars">{(['precision', 'recall', 'f1-score'] as const).map((key, i) => <div className="class-metric-line" key={key}>
          <span>{key === 'f1-score' ? 'F1' : key.charAt(0).toUpperCase() + key.slice(1)}</span><div><i style={{ width: `${Math.max(0, Math.min(1, Number(row[key] || 0))) * 100}%`, backgroundColor: chartColors[(index + i) % chartColors.length] }} /></div><b>{percent(Number(row[key] || 0))}</b>
        </div>)}</div>
      </div>
    })}</div>
  </div>
}

function DatasetDistribution({ labels, distribution }: { labels: string[]; distribution: Record<string, number> }) {
  const total = labels.reduce((sum, label) => sum + Number(distribution[label] || 0), 0)
  let offset = 0
  const segments = labels.map((label, index) => {
    const value = Number(distribution[label] || 0)
    const length = total ? value / total * 263.89 : 0
    const segment = { label, value, color: chartColors[index % chartColors.length], length, offset }
    offset += length
    return segment
  })
  return <div className="eval-chart-card">
    <div className="eval-chart-heading"><h4>Dataset class distribution</h4><span>{total} unique examples</span></div>
    <div className="distribution-layout"><div className="donut-wrap"><svg viewBox="0 0 120 120" role="img" aria-label="Dataset class distribution doughnut chart">
      <circle cx="60" cy="60" r="42" fill="none" stroke="#e8edf3" strokeWidth="14" />
      {segments.map(segment => <circle key={segment.label} cx="60" cy="60" r="42" fill="none" stroke={segment.color} strokeWidth="14" strokeDasharray={`${segment.length} 263.89`} strokeDashoffset={-segment.offset} transform="rotate(-90 60 60)" />)}
      <text x="60" y="56" textAnchor="middle" className="donut-total">{total}</text><text x="60" y="70" textAnchor="middle" className="donut-caption">examples</text>
    </svg></div><div className="distribution-legend">{segments.map(segment => <div key={segment.label}><i style={{ backgroundColor: segment.color }} /><span>{segment.label.replaceAll('_', ' ')}</span><b>{segment.value}</b></div>)}</div></div>
  </div>
}

function ComparisonChart({ runs }: { runs: EvaluationHistoryItem[] }) {
  const selected = [...runs].slice(0, 5).reverse()
  return <div className="eval-chart-card comparison-card">
    <div className="eval-chart-heading"><h4>Evaluation run comparison</h4><span>Saved results · accuracy and weighted F1</span></div>
    {!selected.length ? <p className="eval-chart-note">Run an evaluation to start building a comparison history.</p> : <div className="comparison-list">{selected.map(run => {
      const accuracy = Number(run.metrics?.accuracy || 0)
      const f1 = Number(run.metrics?.weighted_f1 || 0)
      return <div className="comparison-run" key={run.evaluation_id}>
        <div className="comparison-run-title"><b>{run.dataset?.name || 'Dataset'}</b><small>{new Date(run.evaluated_at).toLocaleString()}</small></div>
        <div className="comparison-bars"><span>Accuracy</span><div><i className="accuracy-bar" style={{ width: `${accuracy * 100}%` }} /></div><b>{percent(accuracy)}</b></div>
        <div className="comparison-bars"><span>Weighted F1</span><div><i className="f1-bar" style={{ width: `${f1 * 100}%` }} /></div><b>{percent(f1)}</b></div>
        <small className="comparison-sample">{run.dataset_examples} examples · {run.test_examples} test rows</small>
      </div>
    })}</div>}
  </div>
}

export function EvaluationCharts({ result, history, onOpenRun }: { result: EvaluationResult; history: EvaluationHistoryItem[]; onOpenRun: (id: string) => void }) {
  return <section className="eval-visuals" aria-label="Evaluation visualizations">
    <div className="eval-visuals-header"><div><h3>Visual evaluation dashboard</h3><p>{result.dataset?.name || 'Submitted dataset'} · {result.dataset_examples} examples · {result.train_examples} train / {result.test_examples} test</p></div>
      {result.evaluation_id && <div className="eval-downloads"><a className="btn btn-outline btn-small" href={`${(import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000').replace(/\/$/, '')}/api/evaluations/${encodeURIComponent(result.evaluation_id)}/report.csv`}>Download CSV</a><a className="btn btn-outline btn-small" href={`${(import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000').replace(/\/$/, '')}/api/evaluations/${encodeURIComponent(result.evaluation_id)}/report.pdf`}>Download PDF</a></div>}
    </div>
    <div className="eval-charts-grid"><MetricBars metrics={result.metrics || {}} /><DatasetDistribution labels={result.labels || []} distribution={result.label_distribution || {}} /><ConfusionHeatmap labels={result.labels || []} matrix={result.confusion_matrix || []} /><ClassMetrics labels={result.labels || []} report={result.classification_report || {}} /><ComparisonChart runs={history} /></div>
    {result.duplicate_rows_removed ? <p className="eval-chart-note">Removed {result.duplicate_rows_removed} exact duplicate text row(s) before splitting.</p> : null}
    {history.length > 1 && <div className="eval-history-strip"><b>Saved evaluation runs</b>{history.slice(0, 5).map(item => <button type="button" key={item.evaluation_id} onClick={() => onOpenRun(item.evaluation_id)} className={item.evaluation_id === result.evaluation_id ? 'active' : ''}><span>{item.dataset?.name || 'Dataset'}</span><small>{new Date(item.evaluated_at).toLocaleDateString()} · {percent(Number(item.metrics?.accuracy || 0))} accuracy</small></button>)}</div>}
  </section>
}
