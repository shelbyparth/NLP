# Evidence-Based Fake News Detection Using NLP, Evidence Retrieval, and RAG

**Student 1:** Parth Kitchloo  
**Student 2:** Jaind Sanika Sudhir  
**Course:** Natural Language Processing  
**Project Number:** 33

> Draft note: Replace the evaluation placeholders with results from the actual dataset and experiment you run. Do not present the synthetic demo corpus or the API evaluator's starter examples as real-world evidence.

## Abstract

This project develops an evidence-oriented natural language processing application for investigating factual claims in news-like text. The system accepts a claim or article, normalizes the input, extracts sentence-level claim candidates and entities, retrieves related passages from a locally indexed evidence corpus, and presents a transparent assessment with available source metadata. A default TF-IDF retrieval baseline ranks passages using word and character n-grams. Optional natural language inference models compare a passage with a claim, while an optional language model can summarize the retrieved evidence without changing the assessment label. The application explicitly abstains when evidence is absent or stance cannot be assessed. The project is designed as an educational prototype; its reliability depends on the quality and coverage of the indexed sources, model configuration, and empirical evaluation.

## 1. Introduction

Online information is often shared before the supporting context has been reviewed. Manual verification can require locating relevant reports, checking dates and entities, comparing statements across sources, and communicating uncertainty. NLP methods can assist with text preparation, claim segmentation, information retrieval, and evidence summarization. However, neither text similarity nor fluent generation alone establishes factual correctness. This project therefore centers evidence retrieval and transparent source tracing rather than a binary classifier alone.

## 2. Problem Statement

Given a textual claim or article, build an application that identifies reviewable factual statements, retrieves relevant passages from an available evidence corpus, compares the passage and claim when a suitable stance model is configured, and presents an explanation with source references. When the corpus does not contain adequate evidence, the system must communicate that limitation instead of declaring the claim false.

## 3. Objectives

1. Extract and preprocess text from pasted content and supported public webpages.
2. Generate candidate atomic claims and identify named entities, dates, and quantities.
3. Build a searchable local evidence corpus with source metadata.
4. Implement a reproducible TF-IDF retrieval baseline, with optional dense retrieval.
5. Add optional NLI-based evidence stance classification and grounded LLM explanations.
6. Provide a responsive frontend for input, source management, reporting, and evaluation.
7. Measure baseline performance using a documented labeled dataset and report limitations.

## 4. Related Work

- FEVER introduced a large-scale claim-verification benchmark with evidence annotations, making it relevant to both evidence retrieval and stance assessment [1].
- LIAR provides short statements labeled for veracity, useful for studying supervised classification but not equivalent to a corpus with evidence passages for every claim [2].
- Retrieval-Augmented Generation combines a neural generator with retrieved documents, offering a framework for grounding language-model outputs in external passages [3].
- Sentence-BERT demonstrates sentence embeddings designed for efficient semantic similarity and retrieval [4].
- scikit-learn provides reproducible implementations of TF-IDF vectorization, classical classifiers, and evaluation tools used for baselines [5].

## 5. System Architecture

The architecture has six major layers:

1. **Input and extraction:** accepts text or a public page URL and extracts readable content.
2. **Preprocessing and claims:** normalizes whitespace and Unicode, segments sentences, extracts candidate claims, and identifies entities.
3. **Evidence storage:** stores document text and metadata in a local JSON corpus and splits long documents into passages.
4. **Retrieval:** ranks passages using a hybrid word/character TF-IDF baseline; optional sentence embeddings add a semantic signal.
5. **Evidence comparison and generation:** optional NLI compares passages against claims; optional LLM generation summarizes only supplied evidence. The app does not claim a model is active unless configured.
6. **Reporting and evaluation:** returns a category, source excerpts, links, caveats, pipeline metadata, history, and metrics from explicit experiments.

## 6. Methodology

### 6.1 Text preprocessing

Normalize Unicode and whitespace, preserve negations, and retain meaningful names, dates, percentages, and quantities. Sentence segmentation creates claim candidates; because it is heuristic, users should review the results.

### 6.2 Information extraction

The application first attempts spaCy's English model when installed. A regex fallback extracts dates and quantities so basic information remains available without downloading a separate model. Regex fallback outputs should not be treated as a complete named-entity recognizer.

### 6.3 Evidence indexing and retrieval

Each indexed document stores title, publisher, URL, date when supplied, source type, full text, and import timestamp. Long documents are divided into bounded passages. A word n-gram TF-IDF score is combined with a character n-gram TF-IDF score to rank relevant passages. Optional Sentence Transformers retrieval can combine dense semantic similarity with lexical scores. Retrieval scores indicate ranking relevance only, not truth confidence.

### 6.4 Stance classification and RAG

When a compatible NLI model is configured, each evidence passage is treated as a premise and the claim as a hypothesis. The output may indicate support/entailment, contradiction, or neutral/unknown. The overall report becomes Supported when assessed evidence supports without detected contradictions, Contradicted when evidence contradicts without detected support, Mixed Evidence when both occur, and Insufficient Evidence when no assessed stance is available. This aggregation is a prototype policy and needs validation against labeled examples. A configured LLM can summarize the retrieved source excerpts, but the application fixes the assessment label outside the LLM response.

### 6.5 User interface

The responsive React interface provides a landing page, claim verification workspace, source library, local history, and research page. Results display evidence excerpts and available source links alongside caveats and model/retrieval metadata.

## 7. Dataset and Experimental Design

Use a real public dataset only after verifying the exact release, source, usage terms, labels, available evidence, and downloaded sample count. FEVER is a candidate for evidence-oriented evaluation; LIAR can support labeled statement classification; they must not be treated as interchangeable. Avoid duplicates or syndicated copies across training and test sets. Perform preprocessing and model fitting within the training split.

### Dataset summary (fill after acquisition)

- Dataset and exact release: **[TO BE FILLED]**
- Source URL and access date: **[TO BE FILLED]**
- License / terms checked: **[TO BE FILLED]**
- Total usable records: **[MEASURED VALUE]**
- Label distribution: **[MEASURED VALUES]**
- Split methodology and random seed: **[TO BE FILLED]**
- Evidence annotation availability: **[TO BE FILLED]**

## 8. Evaluation

Report classification accuracy, per-class precision/recall/F1, weighted metrics, and a confusion matrix for the supervised baseline. For evidence retrieval with relevance labels, measure Precision@k, Recall@k, and Mean Reciprocal Rank. For NLI stance classification, evaluate each stance class on held-out claim–evidence pairs. For generated summaries, manually inspect whether cited passages support the explanation, contradiction is represented, unsupported claims are avoided, and uncertainty is appropriately communicated.

### Results (must be populated from actual runs)

| Experiment | Dataset / split | Metric | Measured result |
|---|---|---|---|
| TF-IDF + Logistic Regression | [Dataset] | Accuracy / weighted F1 | [Run experiment] |
| Evidence retrieval | [Dataset with evidence labels] | Precision@5 / Recall@5 / MRR | [Run experiment] |
| NLI stance classification | [Labeled claim-evidence pairs] | Per-class F1 / macro F1 | [Run experiment] |
| RAG groundedness review | [Manually reviewed sample] | Citation support rate | [Review sample] |

No scores should be entered until the experiments are run. If a dataset is too small or no labeled evidence is available, document that limitation rather than extrapolating.

## 9. Limitations

The default corpus is empty and local. The default retrieval method is lexical; sentence embeddings are optional and may require model downloads. Claim segmentation is heuristic. NLI and LLM services are not enabled by default. Live search, OCR, speech recognition/synthesis, cloud topic modeling, and a neural topic model are not part of the verified core build. Source reliability, recency, selection bias, language coverage, and contradictory sources remain difficult. Retrieval similarity does not equal truth, and incorrect or incomplete indexed documents may mislead the user.

## 10. Ethical and Security Considerations

The system should not label a claim false solely because no passage was found. It should preserve uncertainty, make the source trail inspectable, minimize retention of personal claim text, and treat retrieved webpages as untrusted content rather than prompt instructions. Public URL extraction must remain bounded and guarded against private-network access. Users should independently review sources before making high-impact decisions.

## 11. Future Work

- Add a validated live-search connector with documented API terms.
- Index and benchmark a licensed evidence dataset.
- Improve atomic claim mining and entity-aware query expansion.
- Compare BM25, TF-IDF, sentence embeddings, and reranking on the same test set.
- Calibrate NLI abstention thresholds and inspect class imbalance.
- Evaluate claim-wise citation precision and groundedness with human reviewers.
- Add multilingual fact-checking benchmarks and assess translation errors.
- Compare NMF topic modeling to approved cloud topic tools and a true neural topic model if required by course assessment.
- Improve deployment security with authentication, rate limiting, hardened outbound networking, and multi-user data separation.

## 12. Conclusion

VeriFact AI implements a modular workflow that connects text processing with local evidence retrieval and transparent reporting. Its main design principle is that factual assessments should be tied to identifiable evidence, and the system should abstain when the available information is inadequate. The application is a capstone prototype; its real-world reliability must be established through a representative dataset, a configured and validated stance model, and reproducible evaluation.

## References

[1] J. Thorne, A. Vlachos, C. Christodoulopoulos, and A. Mittal, “FEVER: a Large-scale Dataset for Fact Extraction and VERification,” *Proceedings of NAACL-HLT*, 2018. https://aclanthology.org/N18-1074/

[2] W. Y. Wang, “'Liar, Liar Pants on Fire': A New Benchmark Dataset for Fake News Detection,” *Proceedings of the 55th Annual Meeting of the Association for Computational Linguistics*, 2017. https://aclanthology.org/P17-2067/

[3] P. Lewis et al., “Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks,” *Advances in Neural Information Processing Systems*, 2020. https://arxiv.org/abs/2005.11401

[4] N. Reimers and I. Gurevych, “Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks,” *Proceedings of EMNLP-IJCNLP*, 2019. https://arxiv.org/abs/1908.10084

[5] F. Pedregosa et al., “Scikit-learn: Machine Learning in Python,” *Journal of Machine Learning Research*, 12, 2825–2830, 2011. https://jmlr.org/papers/v12/pedregosa11a.html
