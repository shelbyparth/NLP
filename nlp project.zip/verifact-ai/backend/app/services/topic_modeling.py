from __future__ import annotations
from sklearn.decomposition import NMF
from sklearn.feature_extraction.text import TfidfVectorizer
from .corpus import load_documents


def run_topic_modeling(n_topics: int = 4, top_words: int = 8) -> dict:
    docs = load_documents()
    usable = [d for d in docs if len((d.get("content") or "").split()) >= 5]
    if len(usable) < 3:
        raise ValueError("Topic modeling needs at least 3 indexed documents with readable text. Add more documents first.")
    max_topics = min(8, len(usable) - 1)
    n_topics = max(2, min(int(n_topics), max_topics))
    texts = [f"{d.get('title','')} {d.get('content','')}" for d in usable]
    vectorizer = TfidfVectorizer(stop_words="english", max_features=10000, ngram_range=(1, 2), min_df=1)
    matrix = vectorizer.fit_transform(texts)
    if matrix.shape[1] < 2:
        raise ValueError("The indexed corpus contains too little vocabulary diversity for topic modeling.")
    model = NMF(n_components=min(n_topics, matrix.shape[1]), random_state=42, max_iter=400, init="nndsvda")
    weights = model.fit_transform(matrix)
    features = vectorizer.get_feature_names_out()
    topics = []
    for index, component in enumerate(model.components_):
        top_indices = component.argsort()[::-1][:top_words]
        examples = weights[:, index].argsort()[::-1][:3]
        topics.append({
            "topic_id": index + 1,
            "keywords": [{"term": str(features[i]), "weight": round(float(component[i]), 4)} for i in top_indices],
            "representative_documents": [{"id": usable[i]["id"], "title": usable[i]["title"], "url": usable[i].get("url"), "weight": round(float(weights[i, index]), 4)} for i in examples if weights[i, index] > 0],
        })
    return {
        "method": "tfidf_nmf_topic_model", "documents_used": len(usable), "topic_count": len(topics), "topics": topics,
        "note": "This is a local NMF baseline over the currently indexed documents, not a cloud comprehension service or a neural topic model. Topic labels are inferred from keywords and require human interpretation.",
    }
