# VeriFact AI — Implementation Status

This file distinguishes features implemented in the project from integrations that require local software or API credentials. The application remains a React + TypeScript frontend with a Python FastAPI backend. Existing NLP-lab and fake-news verification functionality is retained.

## Existing academic and verification modules retained

- Claim and article-text verification, including public article URL extraction.
- Claim extraction, preprocessing, entity extraction, language identification and sentiment practicals.
- Hybrid word/character TF-IDF evidence retrieval, optional dense retrieval, and optional NLI stance comparison.
- Local evidence library, verification history, JSON reports, topic modelling, and TF-IDF + Logistic Regression evaluation with classification metrics and reports.
- Optional grounded explanation using an OpenAI-compatible chat-completions provider.

## NEWSINTEL AI additions

| Requested capability | Current implementation | Setup / limitation |
|---|---|---|
| Dashboard overview | Total saved-check count; verdict and indicative category breakdowns from the latest 100 checks; 7-day activity from those checks; sentiment summary from the latest 20 checked texts | Category grouping is keyword-based. Sentiment describes tone, not factual truth. |
| News detection and NLP analysis | Existing pasted-text and public-URL verification reused; article analysis shows sentiment, language, keyword hints, extracted claim candidates and entities. Supporting / contradicting evidence remains in the verification report with source links. | Verdict quality depends on indexed evidence and optional NLI configuration. Keywords are a lightweight frequency baseline. |
| Screenshot/image input | OCR upload endpoint and frontend image upload | Requires Python Pillow + pytesseract and the separate Tesseract OCR application. OCR output must be reviewed for transcription errors. |
| Intelligent summarization | Short extractive summary, longer extractive summary, and key points | No facts are generated; quality depends on the supplied text and sentence splitting. |
| Personalized news | User-selected interests and custom topic; live news search results with original links | Requires a Tavily API key. Results are candidate articles, not verified news. Preferences are saved in this browser. |
| Ask AI | Questions retrieve local evidence; optional configured LLM can write a grounded answer; source passages and available URLs are shown | Without an LLM key, the app returns a direct evidence-passage response. It does not search the live web for every question. |
| Multilingual support | Unicode sentence splitting for Devanagari articles; language identification; summary and Ask AI answer translation to English, Hindi or Marathi through the configured LLM provider | Translation requires an OpenAI-compatible provider. Full site-wide UI localization and multilingual model-based fact verification are not yet implemented. The default sentiment lexicon and optional NLI model are primarily English-oriented. |

## Optional backend configuration

Copy `backend/.env.example` to `backend/.env` and configure only the integrations you intend to use.

- Live news: set `TAVILY_API_KEY`.
- Grounded generative answers and translation: set `VERIFACT_LLM_BASE_URL`, `VERIFACT_LLM_API_KEY`, and `VERIFACT_LLM_MODEL`. Groq is supported through its OpenAI-compatible endpoint, for example `https://api.groq.com/openai/v1`, with a currently supported chat model ID.
- OCR: install Python packages from `backend/requirements.txt`, install the Tesseract OCR application separately, and optionally set `TESSERACT_CMD` to its executable path when it is not on PATH.

Never put API keys in frontend environment variables or commit a real `.env` file.

## Verification performed for this package

- Backend test suite: **36 passed**.
- Python source compilation: passed.
- Frontend TypeScript/TSX syntax transpilation: passed.
- Full frontend type-check / production build / Vitest run: **not verified** in this environment because `npm ci` could not complete (the npm registry request timed out and offline cache lacked a package). Run `npm ci`, `npm run build`, and `npm test` on a network-connected machine before final submission.
- Tavily live search and LLM translation/generation were not live-tested because no user API keys were supplied. OCR was smoke-tested end-to-end with a generated screenshot using the Tesseract installation available in this environment; other computers must install Tesseract separately.

This remains an academic prototype. It does not guarantee truth, and it should not replace checking original sources, publication dates, and contradictory evidence.
