from __future__ import annotations
import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from threading import RLock
from typing import Optional
from ..config import EVIDENCE_PATH

_lock = RLock()


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _ensure_file():
    EVIDENCE_PATH.parent.mkdir(parents=True, exist_ok=True)
    if not EVIDENCE_PATH.exists():
        EVIDENCE_PATH.write_text("[]", encoding="utf-8")


def load_documents() -> list[dict]:
    with _lock:
        _ensure_file()
        try:
            data = json.loads(EVIDENCE_PATH.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else []
        except (json.JSONDecodeError, OSError):
            return []


def save_documents(documents: list[dict]) -> None:
    with _lock:
        _ensure_file()
        temp = EVIDENCE_PATH.with_suffix(".tmp")
        temp.write_text(json.dumps(documents, ensure_ascii=False, indent=2), encoding="utf-8")
        temp.replace(EVIDENCE_PATH)


def add_document(title: str, content: str, url: Optional[str] = None, publisher: Optional[str] = None,
                 published_at: Optional[str] = None, source_type: str = "user_uploaded") -> dict:
    doc = {
        "id": f"ev_{uuid.uuid4().hex[:12]}", "title": title.strip(), "content": content.strip(),
        "url": url, "publisher": publisher, "published_at": published_at,
        "source_type": source_type, "added_at": now_iso(),
    }
    documents = load_documents()
    documents.append(doc)
    save_documents(documents)
    return doc


def delete_document(document_id: str) -> bool:
    docs = load_documents()
    filtered = [d for d in docs if d.get("id") != document_id]
    if len(filtered) == len(docs):
        return False
    save_documents(filtered)
    return True


def chunks_from_documents(documents: list[dict], max_chars: int = 1100) -> list[dict]:
    chunks: list[dict] = []
    for doc in documents:
        content = str(doc.get("content", ""))
        paras = [p.strip() for p in content.splitlines() if p.strip()]
        if not paras:
            paras = [content]
        current = ""
        index = 0
        for para in paras:
            while len(para) > max_chars:
                if current:
                    chunks.append(_chunk(doc, current, index)); index += 1; current = ""
                chunks.append(_chunk(doc, para[:max_chars], index)); index += 1
                para = para[max_chars:]
            if current and len(current) + len(para) + 1 > max_chars:
                chunks.append(_chunk(doc, current, index)); index += 1; current = para
            else:
                current = f"{current}\n{para}".strip()
        if current:
            chunks.append(_chunk(doc, current, index))
    return chunks


def _chunk(doc: dict, excerpt: str, index: int) -> dict:
    return {"evidence_id": doc["id"], "chunk_index": index, "title": doc["title"], "publisher": doc.get("publisher"),
            "url": doc.get("url"), "published_at": doc.get("published_at"), "source_type": doc.get("source_type", "unknown"),
            "excerpt": excerpt, "added_at": doc.get("added_at")}
