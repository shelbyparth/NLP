# Dataset Selection & Provenance

The repository does not bundle a real-world fact-checking dataset. This is intentional: dataset availability, licence, access requirements, schema and sample counts must be verified rather than assumed.

Candidate datasets to investigate:

- **FEVER** — evidence-based claim verification with evidence annotation; best aligned with retrieval and stance experiments.
- **LIAR** — short political statements with veracity labels; useful for supervised text-classification baselines, but its label structure does not by itself supply the same evidence corpus as FEVER.
- **FakeNewsNet** — fake-news research collection with potential access, source, license, and completeness constraints that must be checked before use.

For the final report, record the exact source URL, access date, license/terms, downloaded release, number of examples used, fields, label mapping, exclusion rules, train/validation/test split, class distribution and any inaccessible linked content. Keep exact source labels until a documented mapping is applied. Avoid random splits that leak syndicated or near-duplicate articles across train and test sets.

Synthetic demonstration records available through `scripts/load_demo_corpus.py` are fictional software-test fixtures and must not be reported as a real-world dataset or evidence.
