import { useCallback, useEffect, useState, type FormEvent, type ChangeEvent } from 'react'
import {
  Activity, ArrowDownRight, ArrowRight, ArrowUpRight, BookOpenText, BrainCircuit,
  Check, CheckCircle2, ChevronDown, CircleHelp, Clock3, CloudUpload, Copy, Database, FileCheck2,
  FileSearch, FileText, Fingerprint, Globe2, Info, Layers3, Link2, LoaderCircle, LockKeyhole,
  Menu, MessageSquareText, Network, Plus, Search, Shield, ShieldAlert, ShieldCheck,
  Sparkles, Target, Trash2, Upload, X, Zap,
} from 'lucide-react'
import { api } from './services/api'
import type { EvidenceDocument, EvidencePassage, VerificationResult } from './types'

 type Page = 'home' | 'workspace' | 'evidence' | 'history' | 'news-tools' | 'about'
 type InputMode = 'claim' | 'url'

const sampleClaim = 'A claim should be verified against relevant, traceable evidence before it is shared.'
const sampleReport = {
  claim: 'A single viral post is sufficient evidence to prove a public claim.',
  detail: 'This is a visual-only product preview. Live assessments require retrievable source documents and a configured stance model.',
}

function Brand({ onClick }: { onClick: () => void }) {
  return <button className="brand" onClick={onClick} aria-label="VeriFact AI home"><span className="brand-mark"><ShieldCheck size={21} strokeWidth={2.5} /></span><span>VeriFact<span className="brand-ai"> AI</span><small>FOLLOW THE EVIDENCE</small></span></button>
}

function StatusDot({ ok }: { ok: boolean }) {
  return <span className={`status-dot ${ok ? 'online' : 'offline'}`} />
}

function AssessmentPill({ result }: { result: string }) {
  const lower = result.toLowerCase(); const key = lower.includes('mixed') ? 'mixed' : lower.replaceAll(' ', '_')
  const Icon = key.includes('support') ? CheckCircle2 : key.includes('contradict') ? ShieldAlert : key.includes('mixed') ? Activity : CircleHelp
  return <span className={`assessment-pill ${key}`}><Icon size={15} />{result}</span>
}

function EvidenceCard({ item, tone = 'neutral' }: { item: EvidencePassage; tone?: 'support' | 'contradict' | 'neutral' }) {
  return <article className={`evidence-card ${tone}`}>
    <div className="evidence-card-top"><span className="source-icon"><FileText size={17} /></span><div className="source-heading"><strong>{item.title || 'Untitled evidence document'}</strong><span>{item.publisher || 'Publisher not available'}{item.published_at ? ` · ${item.published_at}` : ''}</span></div><span className="relevance">Relevance {item.relevance_score.toFixed(3)}</span></div>
    <p>{item.excerpt}</p>
    {item.related_claim && <div className="evidence-related-claim"><b>Matched to claim:</b> {item.related_claim}</div>}
    <div className="evidence-meta"><span className={`stance-tag ${item.stance}`}>{item.stance === 'unknown' ? 'Stance not assessed' : item.stance === 'neutral' ? 'Neutral · no clear stance' : item.stance}</span><span className="retrieval-label">{item.retrieval_method.replaceAll('_', ' ')}</span>{item.url && <a href={item.url} target="_blank" rel="noreferrer">Open source <ArrowUpRight size={13} /></a>}</div>
  </article>
}

function Header({ page, go, health, mobileMenu, setMobileMenu }: { page: Page; go: (p: Page) => void; health: { status: string; evidence_documents: number } | null; mobileMenu: boolean; setMobileMenu: (v: boolean) => void }) {
  const nav: [string, Page][] = [['Verify', 'workspace'], ['News tools', 'news-tools'], ['Evidence', 'evidence'], ['About', 'about']]
  return <>
    <div className="offer-bar"><span className="offer-dot" /> <strong>Evidence-first AI</strong><span className="offer-divider">|</span><span>Transparent checks. Traceable sources. No invented verdicts.</span><button className="offer-close" aria-label="Dismiss announcement" onClick={e => (e.currentTarget.parentElement as HTMLElement).classList.add('hidden')}><X size={14} /></button></div>
    <header className="site-header"><div className="nav-inner"><Brand onClick={() => go('home')} /><nav className={mobileMenu ? 'nav-links open' : 'nav-links'} aria-label="Main navigation">{nav.map(([name, target]) => <button key={name} className={(page === target && target !== 'home') ? 'active' : ''} onClick={() => { go(target); setMobileMenu(false); if (name === 'How It Works') setTimeout(() => document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' }), 40) }}>{name}</button>)}</nav><div className="nav-actions"><span className="api-status"><StatusDot ok={health?.status === 'ok'} />{health?.status === 'ok' ? 'API connected' : 'API not connected'}</span><button className="btn btn-outline btn-small" onClick={() => go('evidence')}>Evidence library</button><button className="btn btn-primary btn-small" onClick={() => go('workspace')}>Open dashboard <ArrowRight size={15} /></button></div><button className="mobile-menu" aria-label="Toggle navigation" onClick={() => setMobileMenu(!mobileMenu)}>{mobileMenu ? <X /> : <Menu />}</button></div></header>
  </>
}

function PreviewWindow() {
  return <div className="preview-scene" aria-label="Illustrative product preview">
    <div className="preview-orb orb-one" /><div className="preview-orb orb-two" />
    <div className="preview-window"><div className="window-chrome"><span /><span /><span /><div className="window-address"><LockKeyhole size={11} /> verifact.ai / report / demo</div><div className="window-chrome-actions"><i /><i /></div></div>
      <div className="preview-body"><div className="preview-title-row"><div><span className="eyebrow">ILLUSTRATIVE REPORT</span><h3>Evidence overview</h3></div><span className="demo-tag">Demo only</span></div>
        <div className="preview-claim"><span className="claim-label"><FileSearch size={13} /> CLAIM UNDER REVIEW</span><strong>{sampleReport.claim}</strong><small>{sampleReport.detail}</small></div>
        <div className="preview-evidence-row"><span className="mini-source primary"><Check size={15} /></span><div className="skeleton-lines"><b>Source comparison</b><i /><i className="short" /></div><span className="mini-status">Traceable</span></div>
        <div className="preview-evidence-row"><span className="mini-source neutral"><Search size={15} /></span><div className="skeleton-lines"><b>Retrieved passage</b><i /><i className="medium" /></div><span className="mini-status quiet">Review</span></div>
        <div className="preview-bottom"><span><Database size={13} /> Local evidence index</span><span><Shield size={13} /> Source-linked</span></div>
      </div>
    </div>
    <div className="float-chip chip-top"><span className="float-icon green"><CheckCircle2 size={17} /></span><div><b>Evidence linked</b><small>Traceable to a source</small></div></div>
    <div className="float-chip chip-side"><span className="float-icon blue"><BrainCircuit size={17} /></span><div><b>Claim analysis</b><small>Structured NLP pipeline</small></div></div>
    <div className="float-chip chip-bottom"><span className="float-icon amber"><Info size={17} /></span><div><b>Uncertainty matters</b><small>No evidence ≠ false</small></div></div>
  </div>
}

function HomePage({ go, working, claim, setClaim, mode, setMode, url, setUrl, error, onVerify }: { go: (p: Page) => void; working: boolean; claim: string; setClaim: (v: string) => void; mode: InputMode; setMode: (v: InputMode) => void; url: string; setUrl: (v: string) => void; error: string; onVerify: (e: FormEvent) => void }) {
  return <main>
    <section className="hero wrap"><div className="hero-copy"><div className="trust-tag"><span className="blue-dot" /> Evidence-based verification workspace</div><h1>Know What's True.<br /><span>Follow the Evidence.</span></h1><p className="hero-subtitle">Investigate news claims with NLP, evidence retrieval, and transparent AI explanations grounded in traceable sources.</p>
      <form className="hero-input-card" onSubmit={onVerify}><div className="input-mode"><button type="button" className={mode === 'claim' ? 'chosen' : ''} onClick={() => setMode('claim')}><MessageSquareText size={15} /> Claim text</button><button type="button" className={mode === 'url' ? 'chosen' : ''} onClick={() => setMode('url')}><Link2 size={15} /> Article URL</button></div>{mode === 'claim' ? <textarea value={claim} onChange={e => setClaim(e.target.value)} placeholder="Paste a headline or factual claim to investigate…" rows={3} maxLength={30000} aria-label="Claim text" /> : <input className="url-input" type="url" value={url} onChange={e => setUrl(e.target.value)} placeholder="https://example.com/news-article" aria-label="News article URL" />}
        <div className="input-card-bottom"><span><LockKeyhole size={13} /> Local prototype · Input is not publicly posted</span><button className="btn btn-primary verify-btn" type="submit" disabled={working}>{working ? <LoaderCircle size={16} className="spin" /> : <FileSearch size={16} />}{working ? 'Checking…' : 'Verify claim'}<ArrowRight size={15} /></button></div>
        {error && <p className="inline-error" role="alert">{error}</p>}
      </form>
      <div className="hero-links"><button onClick={() => { setMode('claim'); setClaim(sampleClaim) }}><Sparkles size={14} /> Try sample claim</button><span /> <button onClick={() => go('workspace')}>Explore the dashboard <ArrowRight size={14} /></button></div>
      <div className="hero-proof"><div className="proof-icon"><ShieldCheck size={19} /></div><div><strong>Evidence before verdicts</strong><small>Every assessment shows its limits and source trail.</small></div><div className="proof-separator" /><div className="proof-icon pale"><Network size={18} /></div><div><strong>Transparent pipeline</strong><small>Preprocessing → retrieval → comparison</small></div></div>
    </div><PreviewWindow /></section>

    <section className="trust-strip"><div className="wrap trust-strip-inner"><span>BUILT AROUND</span><b><FileText size={16} /> News analysis</b><b><Fingerprint size={16} /> Claim extraction</b><b><Database size={16} /> Evidence retrieval</b><b><BrainCircuit size={16} /> Evidence-based explanations</b><b><Target size={16} /> Clear verdicts</b></div></section>

    <section className="section wrap" id="product"><div className="section-heading"><span className="eyebrow">THE WORKFLOW</span><h2>From a bold claim to <span>traceable evidence.</span></h2><p>A clear fake-news verification workflow that shows its evidence instead of asking users to trust a black box.</p></div><div className="steps-grid" id="how-it-works">{[
      {n:'01', icon:FileText, title:'Extract & prepare', body:'Clean and normalize input text while preserving names, dates, quantities, and negation.'},
      {n:'02', icon:Fingerprint, title:'Break down the claim', body:'Separate long text into reviewable factual statements and identify named entities.'},
      {n:'03', icon:Database, title:'Retrieve evidence', body:'Search indexed source documents with keyword features and semantic retrieval when configured.'},
      {n:'04', icon:BrainCircuit, title:'Compare & explain', body:'Assess evidence stance when a model is configured and show source-linked, uncertainty-aware results.'},
    ].map((item, i) => <article className="step-card" key={item.n}><div className="step-top"><span className="step-icon"><item.icon size={21} /></span><span className="step-num">{item.n}</span></div><h3>{item.title}</h3><p>{item.body}</p>{i !== 3 && <div className="step-connector"><ArrowRight size={15} /></div>}</article>)}</div></section>

    <section className="feature-section"><div className="wrap feature-layout"><div className="feature-copy"><span className="eyebrow">BUILT FOR TRANSPARENCY</span><h2>Good AI answers show <span>where they came from.</span></h2><p>VeriFact AI connects claim processing to a local evidence corpus, keeps citations attached to passages, and makes missing information visible. The model can support a review—but should never replace one.</p><div className="feature-list"><div><span><Check size={15} /></span><p><b>Source traceability</b><small>Every retrieved passage carries document metadata and its available source link.</small></p></div><div><span><Check size={15} /></span><p><b>Honest uncertainty</b><small>Without enough evidence or a configured stance model, the result stays inconclusive.</small></p></div><div><span><Check size={15} /></span><p><b>Transparent assessments</b><small>Every verdict is accompanied by the available evidence and its limitations.</small></p></div></div><button className="btn btn-primary" onClick={() => go('evidence')}>Explore evidence sources <ArrowRight size={16} /></button></div><div className="feature-panel"><div className="feature-panel-head"><span className="panel-dot" /><span>VERIFICATION REPORT</span><span className="report-demo">ILLUSTRATION</span></div><div className="feature-claim"><span>CLAIM</span><p>{sampleReport.claim}</p></div><div className="report-divider"><span /> Evidence trail <span /></div><div className="trail-item"><div className="trail-icon"><FileSearch size={16} /></div><div><b>Passage retrieval</b><small>Matched against an indexed evidence corpus</small></div><ChevronDown size={16} /></div><div className="trail-item"><div className="trail-icon violet"><Layers3 size={16} /></div><div><b>Stance assessment</b><small>Requires an enabled comparison model</small></div><ChevronDown size={16} /></div><div className="inconclusive-note"><Info size={16} /><span>This is an illustrative preview—not a real verification result.</span></div></div></div></section>

    <section className="section wrap faq-section"><div className="section-heading"><span className="eyebrow">COMMON QUESTIONS</span><h2>Clarity about <span>what AI can prove.</span></h2><p>Understand the boundaries of the evidence before drawing a conclusion.</p></div><div className="faq-list">{[
      {q:'Does “insufficient evidence” mean the claim is fake?',a:'No. It means the indexed passages and configured models were not enough to reach a defensible assessment. Missing evidence is not proof of falsity.'},
      {q:'Does VeriFact AI search the entire internet?',a:'Not by default. Verification searches the local Evidence Library. The News tools page can search current headlines through Tavily when its API key is configured; these are candidate articles, not verified facts. A submitted article URL can also be extracted and checked against indexed evidence.'},
      {q:'Does the app use a language model automatically?',a:'No. The core retrieval baseline runs without a paid LLM. NLI, dense embeddings, and LLM explanations are optional and must be configured; the report indicates which stages actually ran.'},
      {q:'Can I trust a source just because it ranks first?',a:'No. Retrieval relevance indicates textual or semantic similarity, not factual reliability. Review the source, publication date, context, and contradictory information before relying on a conclusion.'},
    ].map(item => <details className="faq-item" key={item.q}><summary>{item.q}<ChevronDown size={17} /></summary><p>{item.a}</p></details>)}</div></section>

    <section className="cta-section wrap"><div className="cta-glow" /><div className="cta-content"><div className="cta-icon"><Zap size={22} /></div><span className="eyebrow">READY TO INVESTIGATE?</span><h2>Start with a claim.<br /><span>Follow the evidence.</span></h2><p>Open the workspace, add your evidence sources, and run the end-to-end NLP pipeline.</p><div className="cta-actions"><button className="btn btn-white" onClick={() => go('workspace')}>Open workspace <ArrowRight size={16} /></button><button className="btn btn-ghost-light" onClick={() => go('evidence')}>Manage evidence sources</button></div></div></section>
  </main>
}

function DashboardPage({ result, resultError, working, onVerifyText, onVerifyUrl, libraryCount, onNavigate }: { result: VerificationResult | null; resultError: string; working: boolean; onVerifyText: (text: string, topK: number) => void; onVerifyUrl: (url: string, topK: number) => void; libraryCount: number; onNavigate: (p: Page) => void }) {
  const [mode, setMode] = useState<InputMode>('claim')
  const [text, setText] = useState('')
  const [url, setUrl] = useState('')
  const [topK, setTopK] = useState(5)
  const [activeTab, setActiveTab] = useState<'overview' | 'claims' | 'evidence' | 'technical'>('overview')
  const [search, setSearch] = useState('')
  const run = (e: FormEvent) => { e.preventDefault(); if (mode === 'claim') onVerifyText(text, topK); else onVerifyUrl(url, topK) }
  const evidence = result ? [...result.supporting_evidence, ...result.contradicting_evidence, ...result.other_evidence] : []
  const filtered = evidence.filter(x => `${x.title} ${x.publisher} ${x.excerpt}`.toLowerCase().includes(search.toLowerCase()))
  return <main className="app-main wrap"><div className="page-heading"><div><div className="breadcrumb">Workspace <span>/</span> Claim verification</div><h1>Verification workspace</h1><p>Investigate a claim against your indexed evidence and inspect the source trail.</p></div><div className="heading-actions"><span className="corpus-chip"><Database size={14} /> {libraryCount} indexed documents</span><button className="btn btn-outline" onClick={() => onNavigate('evidence')}>Manage sources <ArrowUpRight size={14} /></button></div></div>
    <div className="workspace-grid"><aside className="workspace-aside"><div className="aside-label">WORKSPACE</div><button className="aside-item active"><FileSearch size={17} /> Claim verification</button><button className="aside-item" onClick={() => onNavigate('evidence')}><Database size={17} /> Evidence library <span>{libraryCount}</span></button><button className="aside-item" onClick={() => onNavigate('history')}><Clock3 size={17} /> Check history</button><div className="aside-info"><span className="aside-info-icon"><Shield size={16} /></span><b>Evidence-first by design</b><p>No relevant evidence is not proof of falsity. Every result exposes the data and methods used.</p></div><div className="aside-api"><StatusDot ok={!resultError} /><span>Local API workflow</span><small>External providers are optional</small></div></aside>
    <section className="workspace-main"><div className="panel input-panel"><div className="panel-title-row"><div><h2><Search size={19} /> Investigate a claim</h2><p>Enter a single factual statement or submit a public article URL.</p></div><span className="local-label"><LockKeyhole size={12} /> Local workspace</span></div><form onSubmit={run}><div className="input-mode dashboard-mode"><button type="button" className={mode === 'claim' ? 'chosen' : ''} onClick={() => setMode('claim')}><MessageSquareText size={15} /> Paste claim or article</button><button type="button" className={mode === 'url' ? 'chosen' : ''} onClick={() => setMode('url')}><Link2 size={15} /> Public URL</button></div>{mode === 'claim' ? <textarea className="dashboard-textarea" value={text} onChange={e => setText(e.target.value)} placeholder="Paste the factual statement you want to investigate…" rows={5} maxLength={30000} /> : <input className="field-input" type="url" value={url} onChange={e => setUrl(e.target.value)} placeholder="https://example.com/article" />}<div className="input-options"><label>Evidence passages <select value={topK} onChange={e => setTopK(Number(e.target.value))}><option value={3}>Top 3</option><option value={5}>Top 5</option><option value={8}>Top 8</option><option value={10}>Top 10</option></select></label><span className="character-count">{mode === 'claim' ? `${text.length.toLocaleString()} / 30,000 characters` : 'Public HTML / text pages'}</span></div><div className="form-footer"><span><Info size={14} /> Uses only the evidence currently indexed unless a provider is configured.</span><button className="btn btn-primary" type="submit" disabled={working || (mode === 'claim' ? !text.trim() : !url.trim())}>{working ? <LoaderCircle className="spin" size={16} /> : <FileSearch size={16} />}{working ? 'Investigating…' : 'Run verification'} <ArrowRight size={15} /></button></div></form>{resultError && <p className="alert error" role="alert"><ShieldAlert size={16} /> {resultError}</p>}</div>
      {!result ? <div className="empty-result panel"><div className="empty-art"><div className="empty-art-ring"><FileSearch size={30} /></div><span className="empty-orbit orbit-a"><Database size={16} /></span><span className="empty-orbit orbit-b"><BrainCircuit size={16} /></span></div><h3>Your evidence report will appear here</h3><p>Submit a claim to extract statements, retrieve matching passages, and see which conclusions can—and cannot—be drawn from the available corpus.</p><div className="empty-steps"><span><b>1</b> Extract</span><ArrowRight size={13} /><span><b>2</b> Retrieve</span><ArrowRight size={13} /><span><b>3</b> Compare</span></div><button className="text-link" onClick={() => onNavigate('evidence')}>Add evidence documents first <ArrowRight size={14} /></button></div> : <div className="result-stack"><div className="result-summary panel"><div className="result-summary-top"><div><span className="eyebrow">ASSESSMENT SUMMARY</span><h2>{result.article_title || 'Claim verification report'}</h2></div><AssessmentPill result={result.assessment_label} /></div><blockquote>{result.input_type === 'url' ? result.article_title || result.original_input : result.original_input}</blockquote><p>{result.explanation}</p><div className="result-stat-row"><div><span>Claims extracted</span><b>{result.claims.length}</b></div><div><span>Evidence matches</span><b>{evidence.length}</b></div><div><span>Processing time</span><b>{String(result.pipeline.processing_ms ?? '—')}<small> ms</small></b></div><div><span>LLM explanation</span><b>{result.llm_used ? 'Used' : 'Fallback'}</b></div></div>{result.caveats.length > 0 && <div className="caveat-box"><Info size={16} /><div><b>Read the limitations</b><ul>{result.caveats.map(c => <li key={c}>{c}</li>)}</ul></div></div>}<div className="report-actions"><button className="btn btn-outline btn-small" onClick={() => navigator.clipboard?.writeText(JSON.stringify(result, null, 2))}><Copy size={14} /> Copy JSON report</button><button className="btn btn-outline btn-small" onClick={() => { const blob = new Blob([JSON.stringify(result, null, 2)], { type: 'application/json' }); const href = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = href; a.download = `verifact-${result.id}.json`; a.click(); URL.revokeObjectURL(href) }}>Export JSON <ArrowDownRight size={14} /></button></div></div>
        <div className="report-tabs">{([['overview', 'Evidence'], ['claims', `Claims (${result.claims.length})`], ['technical', 'Technical details']] as const).map(([id, label]) => <button key={id} className={activeTab === id ? 'active' : ''} onClick={() => setActiveTab(id)}>{label}</button>)}</div>
        {activeTab === 'claims' ? <div className="panel claims-panel"><h3><Fingerprint size={17} /> Extracted claims & entities</h3>{result.claims.map((c, i) => { const check = result.claim_assessments?.find(x => x.claim_id === c.id); return <div className="claim-row" key={c.id}><span className="claim-number">{String(i + 1).padStart(2, '0')}</span><div><p>{c.text}</p>{check && <div className="claim-assessment"><AssessmentPill result={check.assessment_label} /><small>{check.evidence_count} passage(s) · {check.supporting_passages} supporting · {check.contradicting_passages} contradicting · {check.unassessed_passages} unassessed</small></div>}<div className="entity-tags">{c.entities.length ? c.entities.map((e, idx) => <span key={`${e.text}-${idx}`}>{e.text}<small>{e.label}</small></span>) : <small>No entities detected by the active extraction setup.</small>}</div></div></div>})}</div> : activeTab === 'technical' ? <div className="panel technical-panel"><h3><Activity size={17} /> Pipeline details</h3><div className="technical-grid">{Object.entries(result.pipeline).map(([k, v]) => <div key={k}><span>{k.replaceAll('_', ' ')}</span><b>{typeof v === 'object' ? JSON.stringify(v) : String(v)}</b></div>)}</div><p className="muted-note">Retrieval relevance is a ranking signal; it is not a probability that the claim is true.</p></div> : <div className="panel evidence-results"><div className="evidence-results-heading"><div><h3><FileCheck2 size={17} /> Retrieved evidence</h3><p>Inspect the text, source metadata, ranking score, and stance assessment.</p></div><label className="evidence-search"><Search size={14} /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Filter passages" /></label></div>{filtered.length ? <div className="evidence-list">{filtered.map((item, i) => <EvidenceCard key={`${item.evidence_id}-${i}`} item={item} tone={item.stance === 'supports' ? 'support' : item.stance === 'contradicts' ? 'contradict' : 'neutral'} />)}</div> : <div className="inner-empty"><Database size={23} /><b>No evidence passages to show</b><span>Add documents to the local library and run verification again.</span><button className="text-link" onClick={() => onNavigate('evidence')}>Open evidence library <ArrowRight size={13} /></button></div>}</div>}
      </div>}
    </section></div>
  </main>
}

function EvidencePage({ documents, refresh, onError, message }: { documents: EvidenceDocument[]; refresh: () => Promise<void>; onError: (text: string) => void; message: string }) {
  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')
  const [sourceUrl, setSourceUrl] = useState('')
  const [publisher, setPublisher] = useState('')
  const [fileBusy, setFileBusy] = useState(false)
  const [saving, setSaving] = useState(false)
  const [filter, setFilter] = useState('')
  const [showForm, setShowForm] = useState(false)
  const filtered = documents.filter(doc => `${doc.title} ${doc.publisher} ${doc.content}`.toLowerCase().includes(filter.toLowerCase()))
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setSaving(true); onError('')
    try { await api.addEvidence({ title, content, url: sourceUrl || undefined, publisher: publisher || undefined }); setTitle(''); setContent(''); setSourceUrl(''); setPublisher(''); setShowForm(false); await refresh() }
    catch (err) { onError(err instanceof Error ? err.message : 'Could not add evidence document.') }
    finally { setSaving(false) }
  }
  const upload = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return
    setFileBusy(true); onError('')
    try { await api.uploadEvidence(file); await refresh() }
    catch (err) { onError(err instanceof Error ? err.message : 'Could not upload file.') }
    finally { setFileBusy(false); e.target.value = '' }
  }
  const remove = async (id: string) => {
    if (!window.confirm('Remove this document from the local evidence corpus?')) return
    try { await api.deleteEvidence(id); await refresh() } catch (err) { onError(err instanceof Error ? err.message : 'Could not delete document.') }
  }
  return <main className="app-main wrap"><div className="page-heading"><div><div className="breadcrumb">Workspace <span>/</span> Sources</div><h1>Evidence library</h1><p>Manage source documents used by the local retrieval pipeline.</p></div><div className="heading-actions"><label className="btn btn-outline upload-btn"><Upload size={15} />{fileBusy ? 'Importing…' : 'Import document'}<input type="file" accept=".txt,.md,.csv,.json,.html,.htm,.pdf" onChange={upload} disabled={fileBusy} /></label><button className="btn btn-primary" onClick={() => setShowForm(!showForm)}><Plus size={16} /> Add source</button></div></div>
    {message && <p className="alert error page-alert"><ShieldAlert size={15} />{message}</p>}<div className="library-notice"><Info size={17} /><div><b>Local evidence corpus</b><span>Documents added here are stored in this prototype's local JSON index. The retrieval engine searches them; adding a document does not independently prove its claims. Only import sources you are permitted to use.</span></div></div>
    {showForm && <form className="panel add-source-form" onSubmit={submit}><div className="panel-title-row"><div><h2><Plus size={18} /> Add an evidence source</h2><p>Paste a passage with the source metadata. This is helpful when a site does not permit automatic extraction.</p></div><button className="icon-button" type="button" aria-label="Close form" onClick={() => setShowForm(false)}><X size={17} /></button></div><div className="form-grid"><label>Document title<input required value={title} onChange={e => setTitle(e.target.value)} placeholder="e.g. Official report title" /></label><label>Publisher / organization<input value={publisher} onChange={e => setPublisher(e.target.value)} placeholder="e.g. Publisher name" /></label><label className="full-field">Source URL (optional)<input type="url" value={sourceUrl} onChange={e => setSourceUrl(e.target.value)} placeholder="https://official-source.example/report" /></label><label className="full-field">Text / evidence content<textarea required minLength={20} maxLength={100000} value={content} onChange={e => setContent(e.target.value)} placeholder="Paste text or an excerpt from the source…" rows={5} /></label></div><div className="form-footer"><span>{content.length.toLocaleString()} characters</span><button className="btn btn-primary" disabled={saving}>{saving ? <LoaderCircle size={15} className="spin" /> : <Check size={15} />}{saving ? 'Saving…' : 'Save to evidence index'}</button></div></form>}
    <div className="library-stats"><div className="panel library-stat"><span className="stat-symbol"><Database size={17} /></span><div><small>Indexed documents</small><b>{documents.length}</b></div></div><div className="panel library-stat"><span className="stat-symbol teal"><FileText size={17} /></span><div><small>Text searchable</small><b>{documents.length}</b></div></div><div className="panel library-stat"><span className="stat-symbol violet"><ShieldCheck size={17} /></span><div><small>Live search</small><b>Not configured</b></div></div></div>
    <div className="panel library-list-panel"><div className="list-toolbar"><div><h2>Indexed documents <span className="count-badge">{documents.length}</span></h2><p>Source records currently available to evidence retrieval.</p></div><label className="evidence-search"><Search size={15} /><input value={filter} onChange={e => setFilter(e.target.value)} placeholder="Search library" /></label></div>{filtered.length ? <div className="source-list">{filtered.map(doc => <article className="source-row" key={doc.id}><span className="source-doc-icon"><FileText size={20} /></span><div className="source-main"><div className="source-title-line"><h3>{doc.title}</h3><span className={`source-type ${doc.source_type}`}>{doc.source_type.replaceAll('_', ' ')}</span></div><p>{doc.content.slice(0, 240)}{doc.content.length > 240 ? '…' : ''}</p><div className="source-detail-row"><span>{doc.publisher || 'Publisher not set'}</span><span>Added {new Date(doc.added_at).toLocaleDateString()}</span>{doc.url && <a href={doc.url} target="_blank" rel="noreferrer">View source <ArrowUpRight size={12} /></a>}</div></div><button className="icon-button danger-hover" title="Delete source" onClick={() => remove(doc.id)}><Trash2 size={16} /></button></article>)}</div> : <div className="inner-empty"><div className="empty-art-ring small"><CloudUpload size={24} /></div><b>{filter ? 'No matching documents' : 'Your evidence index is empty'}</b><span>{filter ? 'Try a different search.' : 'Import a TXT, Markdown, CSV, JSON, HTML, or PDF file, or add a source passage manually. Then return to the workspace to search it.'}</span>{!filter && <div className="empty-actions"><label className="btn btn-outline upload-btn"><Upload size={14} /> Import a file<input type="file" accept=".txt,.md,.csv,.json,.html,.htm,.pdf" onChange={upload} disabled={fileBusy} /></label><button className="btn btn-primary" onClick={() => setShowForm(true)}><Plus size={14} /> Add text source</button></div>}</div>}</div>
  </main>
}

function HistoryPage({ items, refresh, onOpen, onError, message }: { items: VerificationResult[]; refresh: () => Promise<void>; onOpen: (r: VerificationResult) => void; onError: (s: string) => void; message: string }) {
  const [loading, setLoading] = useState(false)
  const clear = async () => { if (!window.confirm('Clear all locally stored verification history?')) return; setLoading(true); try { await api.clearHistory(); await refresh() } catch (e) { onError(e instanceof Error ? e.message : 'Unable to clear history.') } finally { setLoading(false) } }
  return <main className="app-main wrap"><div className="page-heading"><div><div className="breadcrumb">Workspace <span>/</span> History</div><h1>Verification history</h1><p>Review prior checks saved on this device/server instance.</p></div><button className="btn btn-outline" onClick={clear} disabled={loading || !items.length}><Trash2 size={15} /> Clear history</button></div>{message && <p className="alert error page-alert"><ShieldAlert size={15} />{message}</p>}<div className="library-notice"><Info size={17} /><div><b>Local history only</b><span>History is stored in a local SQLite database. This prototype does not provide user accounts or multi-user isolation.</span></div></div><div className="panel history-panel">{items.length ? items.map(item => <button className="history-row" key={item.id} onClick={() => onOpen(item)}><span className="history-file"><FileCheck2 size={18} /></span><span className="history-main"><b>{item.article_title || item.original_input.slice(0, 115)}</b><small>{new Date(item.created_at).toLocaleString()} · {item.pipeline.evidence_count as string | number} retrieved passage(s)</small></span><AssessmentPill result={item.assessment_label} /><ArrowRight className="history-arrow" size={16} /></button>) : <div className="inner-empty"><div className="empty-art-ring small"><Clock3 size={23} /></div><b>No saved checks yet</b><span>Run a verification in the workspace. Results are saved locally when history is enabled.</span></div>}</div></main>
}

function extractArticleKeywords(text: string) {
  const stop = new Set(['the','and','for','that','with','this','from','have','has','was','were','are','its','their','they','them','will','would','could','should','about','into','than','then','when','where','which','while','after','before','over','under','also','said','has','had','but','not','you','your','our','who','what','how','why','all','any','can','may','more','most','some','such','than','there','these','those','been','being','its','onto','per'])
  const counts = new Map<string, number>()
  for (const word of (text.toLowerCase().match(/[\p{L}][\p{L}'-]{2,}/gu) || [])) {
    if (!stop.has(word)) counts.set(word, (counts.get(word) || 0) + 1)
  }
  return [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8).map(([word]) => word)
}

function categoryForHistory(text: string) {
  const value = text.toLowerCase()
  const matches: Array<[string, RegExp]> = [
    ['Technology', /\b(ai|technology|software|cyber|computer|internet|robot|phone)\b/],
    ['Sports', /\b(sport|cricket|football|tennis|match|player|team|league)\b/],
    ['Politics', /\b(government|election|minister|parliament|policy|politic|president)\b/],
    ['Science', /\b(science|research|study|climate|space|health|scientist|discovery)\b/],
    ['Business', /\b(company|market|business|stock|economy|price|revenue|trade)\b/],
  ]
  return matches.find(([, pattern]) => pattern.test(value))?.[0] || 'Other'
}

function NewsToolsPage({ history, historyTotal, onVerifyText, onVerifyUrl, providers }: { history: VerificationResult[]; historyTotal: number; onVerifyText: (text: string, topK: number) => void; onVerifyUrl: (url: string, topK: number) => void; providers: { tavily: boolean; llm: boolean } }) {
  const [article, setArticle] = useState('')
  const [question, setQuestion] = useState('')
  const [summary, setSummary] = useState<{summary:string;detailed_summary:string;key_points:string[];note:string}|null>(null)
  const [articleAnalysis, setArticleAnalysis] = useState<{sentiment:string;sentimentMethod:string;language:string;claims:Array<{id:string;text:string;entities:Array<{text:string;label:string}>}>;keywords:string[]}|null>(null)
  const [answer, setAnswer] = useState<{answer:string;sources:Array<{title:string;publisher?:string;url?:string;excerpt:string}>;grounded:boolean;generated?:boolean;note?:string}|null>(null)
  const [busy, setBusy] = useState<'summary'|'ask'|'news'|'ocr'|'translate'|''>('')
  const [error, setError] = useState('')
  const [selectedInterests, setSelectedInterests] = useState<string[]>(() => {
    try { const stored = localStorage.getItem('verifact-news-interests'); const parsed = stored ? JSON.parse(stored) : null; return Array.isArray(parsed) ? parsed.filter((item): item is string => typeof item === 'string' && (NEWS_INTERESTS as readonly string[]).includes(item)) : ['Technology', 'Science'] } catch { return ['Technology', 'Science'] }
  })
  const [customTopic, setCustomTopic] = useState('')
  const [newsItems, setNewsItems] = useState<NewsItem[]>([])
  const [newsNote, setNewsNote] = useState('')
  const [ocrText, setOcrText] = useState('')
  const [outputLanguage, setOutputLanguage] = useState('English')
  const [translatedText, setTranslatedText] = useState('')
  const [detectedLanguage, setDetectedLanguage] = useState('')
  const [sentimentCounts, setSentimentCounts] = useState({ positive: 0, neutral: 0, negative: 0 })

  useEffect(() => { localStorage.setItem('verifact-news-interests', JSON.stringify(selectedInterests)) }, [selectedInterests])
  useEffect(() => {
    let active = true
    const recent = history.slice(0, 20)
    if (!recent.length) { setSentimentCounts({ positive: 0, neutral: 0, negative: 0 }); return }
    Promise.allSettled(recent.map(item => api.sentiment(item.original_input.slice(0, 4000))))
      .then(results => {
        if (!active) return
        const next = { positive: 0, neutral: 0, negative: 0 }
        results.forEach(item => { if (item.status === 'fulfilled') { const label = item.value.label.toLowerCase(); if (label.includes('positive')) next.positive++; else if (label.includes('negative')) next.negative++; else next.neutral++ } })
        setSentimentCounts(next)
      })
    return () => { active = false }
  }, [history])

  const makeSummary = async (e: FormEvent) => {
    e.preventDefault(); setBusy('summary'); setError(''); setSummary(null); setArticleAnalysis(null); setTranslatedText('')
    try {
      const result = await api.summarize(article)
      setSummary(result)
      const [language, sentiment, extracted] = await Promise.all([
        api.detectLanguage(article).catch(() => null),
        api.sentiment(article).catch(() => null),
        api.extractClaims(article).catch(() => null),
      ])
      const languageCode = language?.language_code || 'unknown'
      setDetectedLanguage(languageCode)
      setArticleAnalysis({
        sentiment: sentiment?.label || 'unavailable',
        sentimentMethod: sentiment?.method || 'not available',
        language: languageCode,
        claims: extracted?.claims || [],
        keywords: extractArticleKeywords(article),
      })
    }
    catch (err) { setError(err instanceof Error ? err.message : 'Could not summarize this text.') }
    finally { setBusy('') }
  }
  const ask = async (e: FormEvent) => {
    e.preventDefault(); setBusy('ask'); setError(''); setAnswer(null); setTranslatedText('')
    try { setAnswer(await api.ask(question)) }
    catch (err) { setError(err instanceof Error ? err.message : 'Could not search the Evidence Library.') }
    finally { setBusy('') }
  }
  const findNews = async () => {
    const query = [...selectedInterests, customTopic.trim()].filter(Boolean).join(' OR ')
    if (!query) { setError('Choose at least one interest or enter a custom topic.'); return }
    setBusy('news'); setError(''); setNewsItems([]); setNewsNote('')
    try { const result = await api.newsSearch(query); setNewsItems(result.results); setNewsNote(result.note) }
    catch (err) { setError(err instanceof Error ? err.message : 'Live news search is unavailable.') }
    finally { setBusy('') }
  }
  const uploadScreenshot = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return
    setBusy('ocr'); setError(''); setOcrText('')
    try { const result = await api.ocr(file); setOcrText(result.text); setArticle(result.text); setDetectedLanguage((await api.detectLanguage(result.text)).language_code) }
    catch (err) { setError(err instanceof Error ? err.message : 'Could not extract text from this screenshot.') }
    finally { setBusy(''); e.target.value = '' }
  }
  const translateOutput = async (text: string, sourceLanguage?: string) => {
    if (outputLanguage === 'English' && (!sourceLanguage || sourceLanguage === 'en' || sourceLanguage === 'en-or-other-latin')) { setTranslatedText(text); return }
    setBusy('translate'); setError(''); setTranslatedText('')
    try { const result = await api.translate(text, outputLanguage); setTranslatedText(result.translated_text) }
    catch (err) { setError(err instanceof Error ? err.message : 'Translation is unavailable. Configure the optional language model.') }
    finally { setBusy('') }
  }
  const sentimentTotal = sentimentCounts.positive + sentimentCounts.neutral + sentimentCounts.negative
  const statusCounts = {
    supported: history.filter(x => x.assessment === 'supported').length,
    contradicted: history.filter(x => x.assessment === 'contradicted').length,
    mixed: history.filter(x => x.assessment === 'mixed').length,
    insufficient: history.filter(x => x.assessment === 'insufficient_evidence').length,
  }
  const categoryCounts = history.reduce<Record<string, number>>((counts, item) => { const category = categoryForHistory(item.original_input); counts[category] = (counts[category] || 0) + 1; return counts }, {})
  const lastSevenDays = Array.from({ length: 7 }, (_, index) => {
    const date = new Date(); date.setHours(0,0,0,0); date.setDate(date.getDate() - (6 - index))
    const count = history.filter(item => { const when = new Date(item.created_at); return when.toDateString() === date.toDateString() }).length
    return { label: date.toLocaleDateString(undefined, { weekday: 'short' }), count }
  })
  const activityMax = Math.max(1, ...lastSevenDays.map(day => day.count))

  return <main className="app-main wrap">
    <div className="page-heading"><div><div className="breadcrumb">Workspace <span>/</span> News tools</div><h1>News & analysis</h1><p>Review recent checks, find relevant news, extract screenshot text, summarize articles and ask evidence-grounded questions.</p></div></div>

    <section className="panel news-overview"><div className="panel-title-row"><div><h2><Activity size={18}/> Analysis overview</h2><p>Total analyzed is counted across saved checks; verdict and topic breakdowns summarize the latest 100, and sentiment summarizes the latest 20. Sentiment is not a truth indicator.</p></div><span className="source-type">Latest {history.length} checks shown</span></div>
      <div className="news-stat-grid"><article><small>Total analyzed</small><b>{historyTotal}</b></article><article><small>Supported</small><b>{statusCounts.supported}</b></article><article><small>Contradicted</small><b>{statusCounts.contradicted}</b></article><article><small>Mixed</small><b>{statusCounts.mixed}</b></article><article><small>Insufficient evidence</small><b>{statusCounts.insufficient}</b></article></div>
      <div className="news-charts-grid"><div><h3>Daily activity · last 7 days</h3><div className="activity-bars">{lastSevenDays.map(day => <div key={day.label}><span style={{height:`${Math.max(4, day.count / activityMax * 76)}px`}} title={`${day.count} checks`}/><small>{day.label}</small></div>)}</div></div>
        <div><h3>Sentiment of recent checked text</h3><div className="sentiment-bars">{(['positive','neutral','negative'] as const).map(key => <div className="sentiment-line" key={key}><span>{key}</span><div><i style={{width:`${sentimentTotal ? sentimentCounts[key] / sentimentTotal * 100 : 0}%`}}/></div><b>{sentimentCounts[key]}</b></div>)}</div></div>
        <div><h3>Popular topic categories</h3><div className="category-chips">{Object.entries(categoryCounts).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([name,count])=><span key={name}>{name} <b>{count}</b></span>)}{!history.length && <small>No analyzed news yet.</small>}</div></div>
      </div>
    </section>

    <section className="panel personalized-news"><div className="panel-title-row"><div><h2><Globe2 size={18}/> Personalized news</h2><p>Choose interests and fetch recent articles from Tavily. Results are not fact-checked.</p></div><span className={`source-type ${providers.tavily ? 'public_document' : 'synthetic_demo'}`}>{providers.tavily ? 'Live search ready' : 'API key required'}</span></div>
      <div className="interest-choices">{NEWS_INTERESTS.map(interest=><label key={interest}><input type="checkbox" checked={selectedInterests.includes(interest)} onChange={e=>setSelectedInterests(prev=>e.target.checked?[...prev,interest]:prev.filter(x=>x!==interest))}/>{interest}</label>)}</div>
      <div className="news-search-controls"><input className="field-input" value={customTopic} onChange={e=>setCustomTopic(e.target.value)} placeholder="Add a custom topic (optional)"/><button className="btn btn-primary" onClick={findNews} disabled={busy!=='' || (!selectedInterests.length && !customTopic.trim())}>{busy==='news'?'Searching…':'Find latest news'}</button></div>
      {newsItems.length>0 && <div className="live-news-list">{newsItems.map((item,index)=><article key={`${item.url}-${index}`}><div><b>{item.title}</b><p>{item.content}</p><small>{item.published_date || 'Publication date not supplied by provider'}</small></div><div className="live-news-actions"><a href={item.url} target="_blank" rel="noreferrer">Open source <ArrowUpRight size={13}/></a><button className="btn btn-outline btn-small" onClick={()=>onVerifyUrl(item.url,5)}>Analyze article <ArrowRight size={13}/></button></div></article>)}</div>}
      {newsNote && <small className="muted-note">{newsNote}</small>}
    </section>

    <div className="news-tools-grid">
      <section className="panel"><h2><FileText size={18}/> Article summary</h2><p>Paste article text or extract it from a screenshot. Summaries select sentences from the text and do not add facts.</p>
        <label className="btn btn-outline upload-btn news-ocr-upload"><Upload size={15}/>{busy==='ocr'?'Reading screenshot…':'Upload screenshot for OCR'}<input type="file" accept="image/png,image/jpeg,image/webp,image/bmp" onChange={uploadScreenshot} disabled={busy!==''}/></label>
        <form onSubmit={makeSummary}><textarea className="dashboard-textarea" value={article} onChange={e=>setArticle(e.target.value)} minLength={40} maxLength={30000} rows={7} placeholder="Paste article text here (minimum 40 characters)…"/><div className="form-footer"><span>{article.length.toLocaleString()} / 30,000 {detectedLanguage && `· Detected: ${detectedLanguage}`}</span><button className="btn btn-primary" disabled={busy!=='' || article.trim().length<40}>{busy==='summary'?'Summarizing…':'Summarize article'}</button></div></form>
        {ocrText && <div className="ocr-result-actions"><small className="muted-note">OCR text was copied into the article box. Review names, dates and numbers before use.</small><button className="btn btn-outline btn-small" onClick={()=>onVerifyText(ocrText,5)}>Verify extracted text <ArrowRight size={14}/></button></div>}
        {summary && <div className="news-tool-result"><h3>Short summary</h3><p>{summary.summary}</p><h3>Detailed summary</h3><p>{summary.detailed_summary}</p><h3>Key points</h3><ul>{summary.key_points.map((point,i)=><li key={i}>{point}</li>)}</ul>
          {articleAnalysis && <div className="article-analysis"><h3>Article NLP analysis</h3><div className="article-analysis-meta"><span>Sentiment: <b>{articleAnalysis.sentiment}</b> <small>({articleAnalysis.sentimentMethod})</small></span><span>Language: <b>{articleAnalysis.language}</b></span></div><h4>Keywords</h4><div className="keyword-chips">{articleAnalysis.keywords.map(word=><span key={word}>{word}</span>)}</div><h4>Extracted claims and entities</h4>{articleAnalysis.claims.length ? articleAnalysis.claims.slice(0,8).map(claim=><article className="extracted-claim" key={claim.id}><p>{claim.text}</p><div className="keyword-chips">{claim.entities.map((entity,index)=><span key={`${entity.text}-${index}`}>{entity.text} · {entity.label}</span>)}</div></article>) : <small>No clear claim candidates were extracted from this text.</small>}<button className="btn btn-primary btn-small" onClick={()=>onVerifyText(article,5)}>Verify article against evidence <ArrowRight size={13}/></button></div>}
          <div className="translate-row"><select value={outputLanguage} onChange={e=>setOutputLanguage(e.target.value)}><option>English</option><option>Hindi</option><option>Marathi</option></select><button className="btn btn-outline btn-small" onClick={()=>translateOutput(summary.detailed_summary, articleAnalysis?.language || detectedLanguage)} disabled={busy!==''}>{busy==='translate'?'Translating…':'Translate summary'}</button></div>{translatedText && <p className="translated-output">{translatedText}</p>}<small>{summary.note}</small></div>}
      </section>
      <section className="panel"><h2><MessageSquareText size={18}/> Ask AI about evidence</h2><p>Answers use passages from your local Evidence Library. A configured Groq/OpenAI-compatible model can write a concise grounded answer.</p><small className="muted-note">{providers.llm ? 'Grounded answer generation and translation are configured.' : 'Using evidence excerpts until an LLM provider is configured.'}</small><form onSubmit={ask}><label className="practical-input-label">Your question<input className="field-input" value={question} onChange={e=>setQuestion(e.target.value)} maxLength={2000} placeholder="What do the indexed sources say about…?"/></label><div className="form-footer"><span>Evidence Library only</span><button className="btn btn-primary" disabled={busy!=='' || question.trim().length<3}>{busy==='ask'?'Searching…':'Ask question'}</button></div></form>
        {answer && <div className="news-tool-result">
          <h3>Answer</h3>
          <p className="preline">{answer.answer}</p>
          {answer.sources.length > 0 && (
            <section><h3>Sources</h3>{answer.sources.map((source, i) => (
              <article className="ask-source" key={`${source.title}-${i}`}><b>{source.title}</b><p>{source.excerpt}</p>{source.url && <a href={source.url} target="_blank" rel="noreferrer">Open original source <ArrowUpRight size={13}/></a>}</article>
            ))}</section>
          )}
          {answer.note && <small>{answer.note}</small>}
          <div className="translate-row"><select value={outputLanguage} onChange={e=>setOutputLanguage(e.target.value)}><option>English</option><option>Hindi</option><option>Marathi</option></select><button className="btn btn-outline btn-small" onClick={()=>translateOutput(answer.answer)} disabled={busy!==''}>{busy==='translate'?'Translating…':'Translate answer'}</button></div>
          {translatedText && <p className="translated-output">{translatedText}</p>}
        </div>}
      </section>
    </div>
    {error && <p className="alert error" role="alert">{error}</p>}
    <p className="muted-note">Language selection translates generated content, not every navigation label or page control. Full site-wide UI localization is not included yet. News search and OCR require their optional provider/system setup. Sentiment describes tone only; it does not establish truth.</p>
  </main>
}

function AboutPage() {
  return <main className="app-main wrap about-page">
    <div className="page-heading"><div><div className="breadcrumb">VeriFact AI <span>/</span> About</div><h1>About VeriFact AI</h1><p>An AI-assisted fake news detection and verification platform that helps users examine claims against traceable evidence.</p></div></div>
    <div className="about-grid">
      <div className="panel about-card"><span className="tech-icon"><ShieldCheck size={22} /></span><h2>What the platform does</h2>
        <div className="about-detail"><span>Purpose</span><b>Fake news detection and claim verification</b></div>
        <div className="about-detail"><span>News analysis</span><b>Article analysis, summaries and claim extraction</b></div>
        <div className="about-detail"><span>Evidence</span><b>Retrieves relevant passages from available sources</b></div>
        <div className="about-detail"><span>Results</span><b>Supported · Contradicted · Insufficient Evidence</b></div>
      </div>
      <div className="panel about-card"><span className="tech-icon violet"><BookOpenText size={22} /></span><h2>Important limitations</h2>
        <ul className="limitation-list">
          <li>Results depend on the quality, coverage and relevance of available evidence.</li>
          <li>News search requires an optional Tavily API key; search results are candidate articles, not verified facts.</li>
          <li>AI-generated answers and translations require an optional configured language-model provider.</li>
          <li>Some advanced stance analysis requires an optional NLI model.</li>
          <li>VeriFact AI supports independent review; it does not replace professional fact-checking.</li>
        </ul>
      </div>
    </div>
  </main>
}

function Footer({ go }: { go: (p: Page) => void }) {
  return <footer className="site-footer"><div className="wrap footer-main"><div className="footer-brand"><Brand onClick={() => go('home')} /><p>Check the claim. Follow the evidence.</p><small>AI-assisted fake news detection and evidence-based verification.</small></div><div className="footer-links"><div><b>Product</b><button onClick={() => go('workspace')}>Verification workspace</button><button onClick={() => go('evidence')}>Evidence library</button><button onClick={() => go('news-tools')}>News tools</button><button onClick={() => go('history')}>Check history</button></div><div><b>Learn</b><button onClick={() => go('about')}>About the project</button><a href="http://localhost:8000/docs" target="_blank" rel="noreferrer">API documentation <ArrowUpRight size={12} /></a></div></div></div><div className="wrap footer-bottom"><span>© {new Date().getFullYear()} VeriFact AI · Fake News Detection Platform</span><span><Shield size={13} /> Results depend on evidence quality and model configuration.</span></div></footer>
}

export default function App() {
  const [page, setPage] = useState<Page>('home')
  const [mobileMenu, setMobileMenu] = useState(false)
  const [health, setHealth] = useState<{ status: string; evidence_documents: number; nli_configured: boolean; llm_configured: boolean; tavily_configured: boolean } | null>(null)
  const [documents, setDocuments] = useState<EvidenceDocument[]>([])
  const [history, setHistory] = useState<VerificationResult[]>([])
  const [historyTotal, setHistoryTotal] = useState(0)
  const [result, setResult] = useState<VerificationResult | null>(null)
  const [working, setWorking] = useState(false)
  const [error, setError] = useState('')
  const [landingClaim, setLandingClaim] = useState('')
  const [landingUrl, setLandingUrl] = useState('')
  const [landingMode, setLandingMode] = useState<InputMode>('claim')
  const refreshDocuments = useCallback(async () => { try { const data = await api.evidence(); setDocuments(data.documents) } catch { /* the UI displays API state separately */ } }, [])
  const refreshHistory = useCallback(async () => { try { const data = await api.history(); setHistory(data.checks); setHistoryTotal(data.total_count ?? data.count) } catch { /* local history can be unavailable */ } }, [])
  const refreshHealth = useCallback(async () => { try { setHealth(await api.health()) } catch { setHealth(null) } }, [])
  useEffect(() => { void refreshHealth(); void refreshDocuments(); void refreshHistory() }, [refreshHealth, refreshDocuments, refreshHistory])
  const go = (p: Page) => { setPage(p); setError(''); setMobileMenu(false); window.scrollTo({ top: 0, behavior: 'smooth' }) }
  const verifyText = async (text: string, mode: InputMode = 'claim', topK = 5) => {
    setError('')
    const value = text.trim()
    if (!value) { setError(mode === 'url' ? 'Enter a public article URL.' : 'Paste a claim or article before verifying.'); return }
    setWorking(true); setResult(null); setPage('workspace')
    try { const data = mode === 'url' ? await api.verifyUrl(value, topK) : await api.verify(value, topK); setResult(data); void refreshHistory(); void refreshDocuments() }
    catch (e) { setError(e instanceof Error ? e.message : 'Verification failed. Check the backend connection and try again.') }
    finally { setWorking(false); window.scrollTo({ top: 0, behavior: 'smooth' }) }
  }
  const onHomeSubmit = (e: FormEvent) => { e.preventDefault(); void verifyText(landingMode === 'url' ? landingUrl : landingClaim, landingMode) }
  const verifyTextBound = (text: string, topK: number) => { void verifyText(text, 'claim', topK) }
  const verifyUrlBound = (url: string, topK: number) => { void verifyText(url, 'url', topK) }
  return <div className="app-shell"><Header page={page} go={go} health={health} mobileMenu={mobileMenu} setMobileMenu={setMobileMenu} />
    {page === 'home' && <HomePage go={go} working={working} claim={landingClaim} setClaim={setLandingClaim} mode={landingMode} setMode={setLandingMode} url={landingUrl} setUrl={setLandingUrl} error={error} onVerify={onHomeSubmit} />}
    {page === 'workspace' && <DashboardPage result={result} resultError={error} working={working} onVerifyText={verifyTextBound} onVerifyUrl={verifyUrlBound} libraryCount={documents.length} onNavigate={go} />}
    {page === 'evidence' && <EvidencePage documents={documents} refresh={async () => { await refreshDocuments(); await refreshHealth() }} onError={setError} message={error} />}
    {page === 'history' && <HistoryPage items={history} refresh={async () => { await refreshHistory() }} onOpen={r => { setResult(r); go('workspace') }} onError={setError} message={error} />}
    {page === 'news-tools' && <NewsToolsPage history={history} historyTotal={historyTotal} onVerifyText={verifyTextBound} onVerifyUrl={verifyUrlBound} providers={{ tavily: Boolean(health?.tavily_configured), llm: Boolean(health?.llm_configured) }} />}
    {page === 'about' && <AboutPage />}
    <Footer go={go} />
  </div>
}
