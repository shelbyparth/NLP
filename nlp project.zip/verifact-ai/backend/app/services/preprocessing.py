from __future__ import annotations
import re
import unicodedata
from bs4 import BeautifulSoup


def normalize_text(text: str) -> str:
    """Normalize Unicode and whitespace while preserving factual tokens and negation."""
    text = unicodedata.normalize("NFKC", text or "")
    text = text.replace("\u00a0", " ")
    text = re.sub(r"[\t\r\f\v]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = re.sub(r" {2,}", " ", text)
    return text.strip()


def html_to_text(html: str) -> str:
    soup = BeautifulSoup(html, "html.parser")
    for node in soup(["script", "style", "nav", "footer", "header", "aside", "form", "noscript"]):
        node.decompose()
    for node in soup.select(".advertisement, .ads, .cookie, .cookie-banner, .menu, .navigation"):
        node.decompose()
    article = soup.find("article") or soup.find("main") or soup.body or soup
    title = ""
    if soup.title and soup.title.string:
        title = soup.title.string.strip()
    text = article.get_text("\n", strip=True)
    text = normalize_text(text)
    return f"{title}\n\n{text}".strip() if title and not text.startswith(title) else text


def tokenize(text: str) -> list[str]:
    # Keep negations and alphanumeric tokens such as percentages and years.
    return re.findall(r"[\w]+(?:['’-][\w]+)*|\d+(?:[.,]\d+)?%?", normalize_text(text).lower(), flags=re.UNICODE)


def split_sentences(text: str) -> list[str]:
    text = normalize_text(text)
    if not text:
        return []
    # Lightweight fallback sentence splitter; preserves common decimal and abbreviation limitations in docs.
    parts = re.split(r"(?<=[.!?।])\s+(?=[A-Z0-9\u0900-\u097F\"'])|\n+", text)
    return [p.strip(" \t\r\n") for p in parts if p.strip()]
