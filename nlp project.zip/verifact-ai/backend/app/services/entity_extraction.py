from __future__ import annotations
import re
from functools import lru_cache

DATE_RE = re.compile(r"\b(?:\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+\d{1,2}(?:,?\s+\d{4})?|\b(?:19|20)\d{2}\b)", re.I)
NUMBER_RE = re.compile(r"(?<!\w)(?:₹|\$|€|£)?\s*\d+(?:[,.]\d+)*(?:\.\d+)?\s*(?:%|percent|million|billion|thousand|crore|lakh|km|kg|years?|people|users)?\b", re.I)
ORG_HINTS = {"government", "university", "company", "department", "ministry", "organization", "organisation", "court", "bank", "agency", "institute"}

@lru_cache(maxsize=1)
def _spacy_model():
    try:
        import spacy
        return spacy.load("en_core_web_sm")
    except Exception:
        return None


def extract_entities(text: str) -> list[dict]:
    found: list[dict] = []
    seen: set[tuple[str, str]] = set()
    nlp = _spacy_model()
    if nlp:
        try:
            doc = nlp(text[:10000])
            for ent in doc.ents:
                label = ent.label_
                if label in {"PERSON", "ORG", "GPE", "LOC", "DATE", "MONEY", "PERCENT", "PRODUCT", "EVENT", "CARDINAL", "QUANTITY", "ORDINAL"}:
                    key = (ent.text.strip(), label)
                    if key not in seen:
                        seen.add(key); found.append({"text": ent.text.strip(), "label": label, "method": "spaCy"})
        except Exception:
            pass
    # Regex fallback supplements missing date/quantity entities. Keep spans so a
    # year/date is not also emitted as a quantity (for example, "2024").
    date_matches = list(DATE_RE.finditer(text))
    for match in date_matches:
        value = match.group(0).strip()
        key = (value, "DATE")
        if value and key not in seen:
            seen.add(key); found.append({"text": value, "label": "DATE", "method": "regex_fallback"})

    for match in NUMBER_RE.finditer(text):
        if any(match.start() < date.end() and date.start() < match.end() for date in date_matches):
            continue
        value = match.group(0).strip()
        key = (value, "QUANTITY")
        if value and key not in seen:
            seen.add(key); found.append({"text": value, "label": "QUANTITY", "method": "regex_fallback"})
    return found[:100]
