@echo off
setlocal
cd /d "%~dp0backend"
if not exist ".venv\Scripts\python.exe" (
  echo Creating backend virtual environment...
  python -m venv .venv
  if errorlevel 1 goto :failed
)
if not exist ".venv\Scripts\uvicorn.exe" (
  echo Installing backend requirements...
  .venv\Scripts\python.exe -m pip install -r requirements.txt
  if errorlevel 1 goto :failed
)
.venv\Scripts\python.exe -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
exit /b %errorlevel%
:failed
echo Backend setup failed. Confirm Python is installed and the package index is reachable.
pause
exit /b 1
