import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from fastapi.testclient import TestClient

from app.main import app
from app.services import corpus
from app.services.preprocessing import normalize_text, tokenize, split_sentences
from app.services.claim_extraction import extract_claims
from app.services.entity_extraction import extract_entities
from app.services.retrieval import search_evidence
from app.services.verification import verify_request
from app.services.evaluation import evaluate_classifier
from app.services.web_extraction import _validate_public_url


def test_normalization_preserves_negation_and_numbers():
    text = normalize_text("  The report   does NOT confirm  72%\u00a0  ")
    assert text == "The report does NOT confirm 72%"
    assert "not" in tokenize(text)
    assert "72" in tokenize(text)


def test_sentence_split_and_claim_extraction():
    sentences = split_sentences("This is a factual statement about a report. Here is another factual statement.")
    assert len(sentences) == 2
    claims = extract_claims("This is a factual statement about a report. Here is another factual statement.")
    assert len(claims) == 2
    assert claims[0]["text"].endswith("report.")


def test_entity_fallback_finds_year_and_quantity_without_duplicate_year():
    entities = extract_entities("The group reported 42 users in 2025.")
    labels = {e["label"] for e in entities}
    assert "DATE" in labels
    assert "QUANTITY" in labels
    pairs = {(e["text"], e["label"]) for e in entities}
    assert ("2025", "DATE") in pairs
    assert ("42 users", "QUANTITY") in pairs
    assert ("2025", "QUANTITY") not in pairs


def test_retrieval_returns_relevant_indexed_evidence(monkeypatch, tmp_path):
    path = tmp_path / "evidence.json"
    path.write_text("[]", encoding="utf-8")
    monkeypatch.setattr(corpus, "EVIDENCE_PATH", path)
    corpus.add_document(
        "Northbridge transport report",
        "The fictional city of Northbridge opened a new electric bus route in 2024. This entry is synthetic evidence for local software testing only.",
        "https://example.invalid/northbridge-report", "Synthetic demo publisher", "2024-01-01", "synthetic_demo"
    )
    result = search_evidence("Northbridge electric bus route opened in 2024", top_k=3)
    assert result
    assert result[0]["evidence_id"].startswith("ev_")
    assert result[0]["source_type"] == "synthetic_demo"
    assert 0 <= result[0]["relevance_score"] <= 1


def test_no_corpus_means_insufficient_evidence(monkeypatch, tmp_path):
    path = tmp_path / "empty.json"
    path.write_text("[]", encoding="utf-8")
    monkeypatch.setattr(corpus, "EVIDENCE_PATH", path)
    result = verify_request("A sufficiently long factual claim for testing the empty evidence corpus.", None, 5, False)
    assert result["assessment"] == "insufficient_evidence"
    assert result["supporting_evidence"] == []
    assert any("No relevant passages" in item for item in result["caveats"])


def test_url_guard_rejects_loopback():
    try:
        _validate_public_url("http://127.0.0.1:8000/private")
    except ValueError as exc:
        assert "Private" in str(exc) or "local" in str(exc).lower()
    else:
        raise AssertionError("Loopback URL should be blocked")


def test_classifier_evaluation_returns_real_metrics():
    examples = [
        {"text": "official records confirm a count of 450", "label": "supported"},
        {"text": "official report confirms the figure reached 450", "label": "supported"},
        {"text": "documents verify the amount is 450", "label": "supported"},
        {"text": "published records confirm 450 was the total", "label": "supported"},
        {"text": "official records explicitly deny a count of 450", "label": "contradicted"},
        {"text": "the report states the figure was not 450", "label": "contradicted"},
        {"text": "evidence disputes the reported 450 total", "label": "contradicted"},
        {"text": "records show that the 450 claim is incorrect", "label": "contradicted"},
        {"text": "sources mention the topic but give no exact number", "label": "insufficient_evidence"},
        {"text": "available documents do not establish the figure", "label": "insufficient_evidence"},
        {"text": "the sources available cannot confirm the reported count", "label": "insufficient_evidence"},
        {"text": "there is not enough information to confirm the total", "label": "insufficient_evidence"},
    ]
    result = evaluate_classifier(examples)
    assert result["test_examples"] == 3
    assert "accuracy" in result["metrics"]
    assert len(result["confusion_matrix"]) == 3


def test_health_endpoint():
    client = TestClient(app)
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_verify_requires_input():
    client = TestClient(app)
    response = client.post("/api/verify", json={})
    assert response.status_code == 422


def test_topic_modeling_requires_indexed_documents(monkeypatch, tmp_path):
    from app.services.topic_modeling import run_topic_modeling
    path = tmp_path / "empty_topics.json"
    path.write_text("[]", encoding="utf-8")
    monkeypatch.setattr(corpus, "EVIDENCE_PATH", path)
    try:
        run_topic_modeling(3)
    except ValueError as exc:
        assert "at least 3 indexed documents" in str(exc)
    else:
        raise AssertionError("Topic modeling should require an indexed corpus")


def test_evaluation_endpoint_persists_measured_metrics(monkeypatch, tmp_path):
    from app.api import routes
    monkeypatch.setattr(routes, "METRICS_PATH", tmp_path / "latest_evaluation.json")
    examples = [
        {"text": "records confirm the total reached 450", "label": "supported"},
        {"text": "the report confirms a total of 450", "label": "supported"},
        {"text": "official sources verify the count of 450", "label": "supported"},
        {"text": "the published document confirms 450 people", "label": "supported"},
        {"text": "records deny the total reached 450", "label": "contradicted"},
        {"text": "the report says the figure was not 450", "label": "contradicted"},
        {"text": "the official source disputes the 450 number", "label": "contradicted"},
        {"text": "documents show the 450 claim was incorrect", "label": "contradicted"},
    ]
    client = TestClient(app)
    response = client.post("/api/evaluate", json={"examples": examples})
    assert response.status_code == 200
    assert response.json()["test_examples"] == 2
    saved = client.get("/api/metrics")
    assert saved.status_code == 200
    assert saved.json()["status"] == "completed"
    assert saved.json()["result"]["experiment"] == "tfidf_logistic_regression_baseline"


def test_small_evaluation_reports_metric_stability_warning():
    examples = [
        {"text": "Solar panels convert sunlight into energy.", "label": "real"},
        {"text": "Plants use light during photosynthesis.", "label": "real"},
        {"text": "Earth orbits the Sun.", "label": "real"},
        {"text": "The Moon is a star that produces its own light.", "label": "fake"},
        {"text": "Plants photosynthesize without any light.", "label": "fake"},
        {"text": "The Sun revolves around Earth.", "label": "fake"},
        {"text": "Earth has liquid oceans.", "label": "real"},
        {"text": "People can breathe unaided in space.", "label": "fake"},
        {"text": "The Moon is a natural satellite of Earth.", "label": "real"},
        {"text": "Solar panels generate power by burning coal.", "label": "fake"},
        {"text": "Water evaporates from oceans and lakes.", "label": "real"},
        {"text": "Water freezes at 100 degrees Celsius in normal conditions.", "label": "fake"},
    ]
    result = evaluate_classifier(examples)
    assert result["test_examples"] == 3
    assert any("each test prediction changes accuracy" in warning for warning in result["evaluation_warnings"])


def test_nli_unconfigured_abstains(monkeypatch):
    from app.services import stance_classification
    stance_classification._nli_components.cache_clear()
    monkeypatch.delenv("VERIFACT_NLI_MODEL", raising=False)
    result = stance_classification.classify_stance("Claim A", "Evidence B")
    assert result["stance"] == "unknown"
    assert result["method"] == "not_configured"


def test_nli_classifies_with_named_labels(monkeypatch):
    from types import SimpleNamespace
    from app.services import stance_classification

    class FakeContext:
        def __enter__(self): return None
        def __exit__(self, exc_type, exc, tb): return False

    class FakeProbabilities(list):
        def tolist(self): return list(self)

    class FakeTorch:
        @staticmethod
        def no_grad(): return FakeContext()
        @staticmethod
        def softmax(logits, dim=-1): return FakeProbabilities([0.01, 0.98, 0.01])

    class FakeTokenizer:
        def __call__(self, premise, hypothesis, **kwargs):
            assert premise == "Evidence supports claim."
            assert hypothesis == "Claim A"
            return {"input_ids": [1, 2, 3]}

    class FakeModel:
        config = SimpleNamespace(id2label={0: "contradiction", 1: "entailment", 2: "neutral"})
        def eval(self): return None
        def __call__(self, **kwargs):
            return SimpleNamespace(logits=[[0.05, 0.90, 0.05]])

    monkeypatch.setenv("VERIFACT_NLI_MODEL", "test/model")
    monkeypatch.setattr(stance_classification, "_nli_components", lambda model_name: ((FakeTorch, FakeTokenizer(), FakeModel()), None))
    result = stance_classification.classify_stance("Claim A", "Evidence supports claim.")
    assert result["stance"] == "supports"
    assert result["score"] == 0.98
    assert result["method"] == "nli"


def test_nli_model_load_failure_is_diagnostic_and_abstains(monkeypatch):
    from app.services import stance_classification
    monkeypatch.setenv("VERIFACT_NLI_MODEL", "bad/model")
    monkeypatch.setattr(stance_classification, "_nli_components", lambda model_name: (None, "ImportError"))
    result = stance_classification.classify_stance("Claim A", "Evidence B")
    assert result["stance"] == "unknown"
    assert result["method"] == "nli_load_error"
    assert result["error_type"] == "ImportError"


def test_multi_claim_overall_verdict_abstains_if_a_claim_is_unassessed(monkeypatch):
    from app.services import verification

    def fake_search(query, top_k=5):
        if query.startswith("Plants use sunlight"):
            return [{
                "evidence_id": "ev_test", "title": "Synthetic Test Evidence", "publisher": "test",
                "url": None, "published_at": None, "excerpt": "Plants use sunlight for photosynthesis.",
                "relevance_score": 0.9, "retrieval_method": "test", "source_type": "synthetic_demo",
            }]
        return []

    monkeypatch.setattr(verification, "search_evidence", fake_search)
    monkeypatch.setattr(verification, "classify_stance", lambda claim, evidence: {"stance": "supports", "score": 0.9, "method": "nli"})
    monkeypatch.setattr(verification, "generate_explanation", lambda *args: ("test explanation", False))
    result = verification.verify_request(
        "Plants use sunlight during photosynthesis. The Moon is made of cheese.", None, 5, False
    )
    assert len(result["claim_assessments"]) == 2
    assert result["claim_assessments"][0]["assessment"] == "supported"
    assert result["claim_assessments"][1]["assessment"] == "insufficient_evidence"
    assert result["assessment"] == "insufficient_evidence"


def test_nli_status_endpoint_does_not_load_model():
    client = TestClient(app)
    response = client.get("/api/nli/status")
    assert response.status_code == 200
    body = response.json()
    assert "configured" in body
    assert body["status"] in {"not_configured", "configured_lazy_load"}


def test_nli_neutral_is_not_mislabeled_as_unassessed(monkeypatch):
    from types import SimpleNamespace
    from app.services import stance_classification

    class FakeContext:
        def __enter__(self): return None
        def __exit__(self, exc_type, exc, tb): return False

    class FakeProbabilities(list):
        def tolist(self): return list(self)

    class FakeTorch:
        @staticmethod
        def no_grad(): return FakeContext()
        @staticmethod
        def softmax(logits, dim=-1): return FakeProbabilities([0.01, 0.01, 0.98])

    class FakeTokenizer:
        def __call__(self, premise, hypothesis, **kwargs): return {"input_ids": [1, 2, 3]}

    class FakeModel:
        config = SimpleNamespace(id2label={0: "contradiction", 1: "entailment", 2: "neutral"})
        def __call__(self, **kwargs): return SimpleNamespace(logits=[[0.01, 0.01, 0.98]])

    monkeypatch.setenv("VERIFACT_NLI_MODEL", "test/model-neutral")
    monkeypatch.setattr(stance_classification, "_nli_components", lambda model_name: ((FakeTorch, FakeTokenizer(), FakeModel()), None))
    result = stance_classification.classify_stance("Claim", "Evidence")
    assert result["stance"] == "neutral"
    assert result["method"] == "nli"


def test_nli_abstains_when_model_labels_are_generic(monkeypatch):
    from types import SimpleNamespace
    from app.services import stance_classification

    class FakeContext:
        def __enter__(self): return None
        def __exit__(self, exc_type, exc, tb): return False

    class FakeProbabilities(list):
        def tolist(self): return list(self)

    class FakeTorch:
        @staticmethod
        def no_grad(): return FakeContext()
        @staticmethod
        def softmax(logits, dim=-1): return FakeProbabilities([0.01, 0.98, 0.01])

    class FakeTokenizer:
        def __call__(self, premise, hypothesis, **kwargs): return {"input_ids": [1, 2, 3]}

    class FakeModel:
        config = SimpleNamespace(id2label={0: "LABEL_0", 1: "LABEL_1", 2: "LABEL_2"})
        def __call__(self, **kwargs): return SimpleNamespace(logits=[[0.01, 0.98, 0.01]])

    monkeypatch.setenv("VERIFACT_NLI_MODEL", "test/model-generic-labels")
    monkeypatch.setattr(stance_classification, "_nli_components", lambda model_name: ((FakeTorch, FakeTokenizer(), FakeModel()), None))
    result = stance_classification.classify_stance("Claim", "Evidence")
    assert result["stance"] == "unknown"
    assert result["method"] == "nli_label_mapping_unknown"


def test_evaluation_removes_exact_duplicates_before_split():
    examples = [
        {"text": f"supported statement number {i} from verified records", "label": "supported"}
        for i in range(4)
    ] + [
        {"text": f"contradicted statement number {i} from official records", "label": "contradicted"}
        for i in range(4)
    ]
    examples.extend([examples[0].copy(), {"text": examples[1]["text"].upper(), "label": "supported"}])
    result = evaluate_classifier(examples)
    assert result["dataset_examples"] == 8
    assert result["duplicate_rows_removed"] == 2
    assert result["train_examples"] + result["test_examples"] == 8
    assert any("exact duplicate" in warning for warning in result["evaluation_warnings"])


def test_evaluation_rejects_conflicting_duplicate_labels():
    examples = [
        {"text": "same claim wording", "label": "supported"},
        {"text": "same claim wording", "label": "contradicted"},
    ] + [
        {"text": f"unique item {i}", "label": "supported" if i % 2 == 0 else "contradicted"}
        for i in range(8)
    ]
    try:
        evaluate_classifier(examples)
    except ValueError as exc:
        assert "Conflicting labels" in str(exc)
    else:
        raise AssertionError("Conflicting labels for duplicate texts must be rejected")


def test_csv_evaluation_upload_history_and_download_reports(monkeypatch, tmp_path):
    from app.api import routes
    from app.db import history
    monkeypatch.setattr(routes, "METRICS_PATH", tmp_path / "latest_evaluation.json")
    monkeypatch.setattr(history, "HISTORY_PATH", tmp_path / "history.sqlite3")
    rows = [
        ("official record confirms fact alpha", "supported"),
        ("published audit verifies fact beta", "supported"),
        ("approved document confirms fact gamma", "supported"),
        ("official report verifies fact delta", "supported"),
        ("official record denies fact epsilon", "contradicted"),
        ("published audit disputes fact zeta", "contradicted"),
        ("approved document rejects fact eta", "contradicted"),
        ("official report denies fact theta", "contradicted"),
    ]
    csv_text = "claim_text,ground_truth\n" + "\n".join(f'"{text}",{label}' for text, label in rows)
    client = TestClient(app)
    response = client.post(
        "/api/evaluate/upload",
        files={"file": ("capstone-test.csv", csv_text.encode("utf-8"), "text/csv")},
        data={"text_field": "claim_text", "label_field": "ground_truth", "dataset_name": "CSV test dataset"},
    )
    assert response.status_code == 200, response.text
    result = response.json()
    assert result["dataset"]["name"] == "CSV test dataset"
    assert result["dataset"]["source_type"] == "uploaded_csv"
    assert result["test_examples"] == 2
    evaluation_id = result["evaluation_id"]

    history_response = client.get("/api/evaluations")
    assert history_response.status_code == 200
    assert history_response.json()["count"] == 1
    assert history_response.json()["evaluations"][0]["evaluation_id"] == evaluation_id
    assert client.get(f"/api/evaluations/{evaluation_id}").status_code == 200

    csv_report = client.get(f"/api/evaluations/{evaluation_id}/report.csv")
    assert csv_report.status_code == 200
    assert "weighted_f1" in csv_report.text
    assert "Confusion matrix" in csv_report.text

    pdf_report = client.get(f"/api/evaluations/{evaluation_id}/report.pdf")
    assert pdf_report.status_code == 200
    assert pdf_report.content.startswith(b"%PDF")


def test_csv_evaluation_upload_rejects_missing_columns():
    client = TestClient(app)
    response = client.post(
        "/api/evaluate/upload",
        files={"file": ("wrong.csv", b"headline,category\nA,supported", "text/csv")},
    )
    assert response.status_code == 400
    assert "selected columns" in response.json()["detail"]


def test_json_and_jsonl_evaluation_uploads(monkeypatch, tmp_path):
    from app.api import routes
    from app.db import history
    monkeypatch.setattr(routes, "METRICS_PATH", tmp_path / "latest_evaluation.json")
    monkeypatch.setattr(history, "HISTORY_PATH", tmp_path / "history.sqlite3")
    examples = [
        {"text": f"verified example {i} with published source", "label": "supported"}
        for i in range(4)
    ] + [
        {"text": f"disputed example {i} in source review", "label": "contradicted"}
        for i in range(4)
    ]
    client = TestClient(app)
    json_payload = json.dumps({"examples": examples})
    response = client.post(
        "/api/evaluate/upload",
        files={"file": ("claims.json", json_payload.encode("utf-8"), "application/json")},
    )
    assert response.status_code == 200, response.text
    assert response.json()["dataset"]["source_type"] == "uploaded_json"

    jsonl_payload = "\n".join(json.dumps(row) for row in examples)
    response = client.post(
        "/api/evaluate/upload",
        files={"file": ("claims.jsonl", jsonl_payload.encode("utf-8"), "application/x-ndjson")},
    )
    assert response.status_code == 200, response.text
    assert response.json()["dataset"]["source_type"] == "uploaded_jsonl"



def test_sentiment_and_language_practical_endpoints():
    client = TestClient(app)
    sentiment = client.post("/api/analyze-sentiment", json={"text": "This is a good and successful result."})
    language = client.post("/api/detect-language", json={"text": "This is an English language sample."})
    assert sentiment.status_code == 200
    assert sentiment.json()["label"] in {"positive", "negative", "neutral"}
    assert sentiment.json()["method"] == "transparent_lexicon_baseline"
    assert language.status_code == 200
    assert "language_code" in language.json()
    assert "method" in language.json()


def test_sentiment_uses_optional_transformers_model(monkeypatch):
    from app.services import auxiliary

    class FakePipeline:
        def __call__(self, text, truncation=True):
            return [{"label": "positive", "score": 0.91}]

    auxiliary._sentiment_pipeline.cache_clear()
    monkeypatch.setenv("VERIFACT_SENTIMENT_MODEL", "test/sentiment")
    monkeypatch.setattr(auxiliary, "_sentiment_pipeline", lambda model: FakePipeline())
    result = auxiliary.analyze_sentiment("This is a wonderful result.")
    assert result["label"] == "positive"
    assert result["method"] == "transformers_sentiment_model"
    assert result["score"] == 0.91


def test_sentiment_falls_back_safely_when_optional_model_fails(monkeypatch):
    from app.services import auxiliary

    auxiliary._sentiment_pipeline.cache_clear()
    monkeypatch.setenv("VERIFACT_SENTIMENT_MODEL", "missing/model")
    def fail(model):
        raise OSError("model unavailable")
    monkeypatch.setattr(auxiliary, "_sentiment_pipeline", fail)
    result = auxiliary.analyze_sentiment("This is a good result.")
    assert result["method"] == "transparent_lexicon_baseline"
    assert result["model_fallback"] is True
    assert result["model_error_type"] == "OSError"


def test_extractive_news_summary_returns_sentences():
    from app.services.news_tools import summarize_text
    text = ("Researchers published a report about solar energy adoption. "
            "The report says solar installations increased during the year. "
            "Officials expect additional projects to begin next year.")
    result = summarize_text(text)
    assert result["summary"]
    assert result["key_points"]
    assert result["method"] == "extractive_tfidf_style_baseline"


def test_ask_evidence_abstains_without_passages():
    from app.services.news_tools import answer_from_evidence
    result = answer_from_evidence("What happened?", [])
    assert result["grounded"] is False
    assert result["sources"] == []


def test_news_summary_returns_short_and_detailed_versions():
    from app.services.news_tools import summarize_text
    text = (
        "The city council approved a new public transport plan after a long review. "
        "The plan includes electric buses and expanded routes across the city. "
        "Officials said the first phase will begin next year with additional funding. "
        "Residents can submit feedback through the council website before the final rollout. "
        "The transport department will publish monthly progress updates and service data. "
        "The announcement does not provide a final completion date for every route."
    )
    result = summarize_text(text)
    assert result["summary"]
    assert result["detailed_summary"]
    assert len(result["detailed_summary"]) >= len(result["summary"])
    assert len(result["key_points"]) >= 3


def test_live_news_endpoint_is_disabled_without_tavily_key(monkeypatch):
    from app.services import news_search
    monkeypatch.setattr(news_search, "TAVILY_API_KEY", "")
    response = TestClient(app).post("/api/news/search", json={"query": "science"})
    assert response.status_code == 503
    assert "TAVILY_API_KEY" in response.json()["detail"]


def test_live_news_search_normalizes_provider_results(monkeypatch):
    from app.services import news_search

    class FakeResponse:
        def raise_for_status(self):
            return None
        def json(self):
            return {"results": [
                {"title": "Science update", "url": "https://news.example/story", "content": "A brief article excerpt", "published_date": "2026-11-20", "score": 0.9},
                {"title": "Bad URL", "url": "javascript:alert(1)", "content": "Ignore"},
            ]}

    monkeypatch.setattr(news_search, "TAVILY_API_KEY", "test-key")
    monkeypatch.setattr(news_search.requests, "post", lambda *args, **kwargs: FakeResponse())
    result = news_search.search_latest_news("  science   update ", 6)
    assert result["query"] == "science update"
    assert result["count"] == 1
    assert result["results"][0]["url"] == "https://news.example/story"


def test_ocr_rejects_unsupported_file_type():
    response = TestClient(app).post(
        "/api/ocr",
        files={"file": ("notes.txt", b"not an image", "text/plain")},
    )
    assert response.status_code == 415


def test_history_endpoint_reports_total_count(monkeypatch, tmp_path):
    from app.db import history as history_db
    monkeypatch.setattr(history_db, "HISTORY_PATH", tmp_path / "history.sqlite3")
    history_db.save_result({
        "id": "check-test-1",
        "created_at": "2026-11-20T10:00:00+00:00",
        "assessment": "insufficient_evidence",
        "original_input": "A test claim for history count.",
    })
    response = TestClient(app).get("/api/history?limit=10")
    assert response.status_code == 200
    assert response.json()["total_count"] == 1
    assert response.json()["count"] == 1


def test_hindi_sentence_boundary_and_summary_support_devanagari():
    from app.services.preprocessing import split_sentences
    from app.services.news_tools import summarize_text
    text = (
        "भारत एक विविधताओं वाला देश है। यहाँ कई भाषाएँ और संस्कृतियाँ पाई जाती हैं। "
        "लोग अलग-अलग क्षेत्रों में रहते हैं और अनेक त्योहार मनाते हैं। यह एक उदाहरण समाचार लेख है।"
    )
    sentences = split_sentences(text)
    assert len(sentences) == 4
    result = summarize_text(text)
    assert "भारत" in result["detailed_summary"]


def test_ask_evidence_returns_source_linked_grounded_answer(monkeypatch):
    from app.services import news_tools
    from app import config
    monkeypatch.setattr(config, "LLM_API_KEY", "")
    monkeypatch.setattr(config, "LLM_BASE_URL", "")
    monkeypatch.setattr(config, "LLM_MODEL", "")
    result = news_tools.answer_from_evidence("What happened?", [{
        "title": "Official report", "publisher": "Public Office", "url": "https://public.example/report", "excerpt": "The report confirms the stated result."
    }])
    assert result["grounded"] is True
    assert result["generated"] is False
    assert result["sources"][0]["url"] == "https://public.example/report"
    assert "The report confirms" in result["answer"]
