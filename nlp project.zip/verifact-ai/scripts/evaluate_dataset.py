"""Evaluate the documented TF-IDF + Logistic Regression baseline on JSONL data.
Expected one JSON object per line with `text` and `label` fields.
"""
from __future__ import annotations
import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))
from app.services.evaluation import evaluate_classifier


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dataset", help="Path to JSONL file with text and label fields")
    parser.add_argument("--text-field", default="text")
    parser.add_argument("--label-field", default="label")
    parser.add_argument("--test-size", type=float, default=0.25)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output", default="evaluation-results.json")
    args = parser.parse_args()
    dataset_path = Path(args.dataset)
    if not dataset_path.exists():
        parser.error(f"Dataset file not found: {dataset_path}")
    examples = []
    with dataset_path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            try:
                item = json.loads(line)
            except json.JSONDecodeError as exc:
                parser.error(f"Invalid JSON on line {line_number}: {exc}")
            if not isinstance(item, dict):
                parser.error(f"Line {line_number} must contain a JSON object.")
            examples.append({"text": item.get(args.text_field, ""), "label": item.get(args.label_field, "")})
    try:
        result = evaluate_classifier(examples, test_size=args.test_size, random_state=args.seed)
    except ValueError as exc:
        parser.error(str(exc))
    result["evaluated_at"] = datetime.now(timezone.utc).isoformat()
    result["dataset_path"] = str(dataset_path.resolve())
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"output": str(output.resolve()), "experiment": result["experiment"], "metrics": result["metrics"], "test_examples": result["test_examples"]}, ensure_ascii=False, indent=2))
    print("Note: results depend on dataset quality and split; a text classifier is not a substitute for evidence retrieval.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
