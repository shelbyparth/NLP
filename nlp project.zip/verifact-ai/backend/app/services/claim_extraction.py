from __future__ import annotations
import re
import uuid
from .preprocessing import split_sentences

QUESTION_STARTERS = ("who ", "what ", "when ", "where ", "why ", "how ", "is ", "are ", "was ", "were ", "can ", "could ", "should ", "would ")


def extract_claims(text: str) -> list[dict]:
    sentences = split_sentences(text)
    candidates: list[str] = []
    for sentence in sentences:
        compact = re.sub(r"\s+", " ", sentence).strip()
        if len(compact) < 18:
            continue
        if compact.endswith("?") and compact.lower().startswith(QUESTION_STARTERS):
            continue
        # Keep sentences with a predicate-like verb signal or numerals/named-entity-like tokens;
        # avoid aggressive filtering that could silently discard valid factual claims.
        if len(compact.split()) >= 4:
            candidates.append(compact)
    if not candidates and text.strip():
        candidates = [text.strip()[:1000]]
    return [{"id": f"claim_{uuid.uuid4().hex[:10]}", "text": sentence, "entities": []} for sentence in candidates[:20]]
