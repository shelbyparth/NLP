# NLP Lab Exam Demonstration Guide

## Project
**VeriFact AI — Evidence-Based Fake News Detection / Claim Verification**

Do not change the problem statement assigned by the faculty. This guide maps the current implementation to the supplied 30-mark practical rubric.

## CO1 — Text extraction, preprocessing and vectorization (7 marks)
1. Open the verification workspace and submit pasted claim text or a public article URL.
2. Explain HTML/text extraction, Unicode normalization, whitespace cleanup and sentence splitting.
3. Show tokenization and the TF-IDF word/character n-gram retrieval baseline in the evidence search workflow.
4. Explain why negation, numbers, names and dates are preserved.

## CO2 — Sentiment analysis and information extraction (8 marks)
1. Open Research & evaluation → NLP lab practicals.
2. Enter a paragraph and select **Run NLP practicals**.
3. Explain sentiment label/score as a lexicon baseline only; it measures tone, not factual truth.
4. Explain sentence-level claim extraction and entity extraction (spaCy if installed, otherwise regex fallback for dates and quantities).

## CO3 — Topic modeling or multilingual NLP (7 marks)
1. Add at least three meaningful source documents in Evidence Library.
2. Open Research & evaluation → Local topic modeling → **Discover topics**.
3. Explain TF-IDF document vectors and NMF topic components; interpret the returned keywords and representative documents.
4. The practical panel also shows language identification. If only a script fallback is installed, state its limitations accurately.

## CO4 — Generative AI / LLM integration and prompt engineering (8 marks)
1. In the verification workspace, run a claim against indexed evidence.
2. Configure `VERIFACT_LLM_BASE_URL`, `VERIFACT_LLM_API_KEY`, and `VERIFACT_LLM_MODEL` in `backend/.env` to enable the optional OpenAI-compatible provider.
3. Explain the prompt constraints: use only supplied evidence, treat source passages as untrusted input, do not invent facts/citations, preserve the application's assessment label, and state uncertainty.
4. Without a configured provider, the application deliberately uses a deterministic fallback. Do not claim that an LLM ran unless the report says it did.

## Suggested demonstration order
1. Health/API status.
2. Add or upload evidence documents and show source metadata.
3. Run claim extraction and entity extraction.
4. Run sentiment and language identification in NLP lab practicals.
5. Run topic modeling with at least three documents.
6. Verify a claim and inspect the evidence passages, stance method, caveats and explanation.
7. Run the labeled-dataset evaluator and explain the holdout size, accuracy, precision, recall, F1 and confusion matrix.

## Submission checklist from the examination guideline
- Final project title and assigned problem statement.
- GitHub repository with complete source code and organized folders.
- Root `README.md` with overview, objectives, technologies, methodology, architecture, installation and execution.
- Deployed project link, if available and accessible to faculty.
- One-page poster with problem, objectives, methodology, architecture and results.
- Output screenshots: UI, sample input and output.
- Dataset source, description and preprocessing details.
- AWS NLP Lab certificate PDF submitted separately.
- Do not commit API keys, passwords or confidential credentials.
