from __future__ import annotations
import json
import sqlite3
from ..config import HISTORY_PATH


def _connect():
    HISTORY_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(HISTORY_PATH)
    conn.execute("CREATE TABLE IF NOT EXISTS checks (id TEXT PRIMARY KEY, created_at TEXT NOT NULL, assessment TEXT NOT NULL, original_input TEXT NOT NULL, result_json TEXT NOT NULL)")
    conn.execute("CREATE TABLE IF NOT EXISTS evaluation_runs (id TEXT PRIMARY KEY, evaluated_at TEXT NOT NULL, dataset_name TEXT NOT NULL, result_json TEXT NOT NULL)")
    return conn


def save_result(result: dict) -> None:
    with _connect() as conn:
        conn.execute("INSERT OR REPLACE INTO checks(id, created_at, assessment, original_input, result_json) VALUES(?,?,?,?,?)",
                     (result["id"], result["created_at"], result["assessment"], result["original_input"], json.dumps(result, ensure_ascii=False)))


def count_results() -> int:
    with _connect() as conn:
        row = conn.execute("SELECT COUNT(*) FROM checks").fetchone()
    return int(row[0] if row else 0)


def list_results(limit: int = 50) -> list[dict]:
    with _connect() as conn:
        rows = conn.execute("SELECT result_json FROM checks ORDER BY created_at DESC LIMIT ?", (max(1, min(limit, 100)),)).fetchall()
    results = []
    for row in rows:
        try:
            results.append(json.loads(row[0]))
        except (TypeError, json.JSONDecodeError):
            continue
    return results


def clear_history() -> int:
    with _connect() as conn:
        cur = conn.execute("DELETE FROM checks")
        return cur.rowcount


def save_evaluation(result: dict) -> None:
    """Persist a complete evaluation result for later review and report downloads."""
    with _connect() as conn:
        conn.execute(
            "INSERT OR REPLACE INTO evaluation_runs(id, evaluated_at, dataset_name, result_json) VALUES(?,?,?,?)",
            (result["evaluation_id"], result["evaluated_at"], result.get("dataset", {}).get("name", "Uploaded dataset"), json.dumps(result, ensure_ascii=False)),
        )


def list_evaluations(limit: int = 20) -> list[dict]:
    with _connect() as conn:
        rows = conn.execute(
            "SELECT result_json FROM evaluation_runs ORDER BY evaluated_at DESC LIMIT ?",
            (max(1, min(limit, 100)),),
        ).fetchall()
    results: list[dict] = []
    for (raw,) in rows:
        try:
            results.append(json.loads(raw))
        except (TypeError, json.JSONDecodeError):
            continue
    return results


def get_evaluation(evaluation_id: str) -> dict | None:
    with _connect() as conn:
        row = conn.execute("SELECT result_json FROM evaluation_runs WHERE id = ?", (evaluation_id,)).fetchone()
    if not row:
        return None
    try:
        return json.loads(row[0])
    except (TypeError, json.JSONDecodeError):
        return None
