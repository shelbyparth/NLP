#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BACKEND="$ROOT/backend"
cd "$BACKEND"

if [[ -x ".venv/Scripts/python.exe" ]]; then
  PYTHON=".venv/Scripts/python.exe"
elif [[ -x ".venv/bin/python" ]]; then
  PYTHON=".venv/bin/python"
else
  echo "Backend virtual environment not found."
  echo "Create it first with: python -m venv .venv"
  exit 1
fi

echo "Installing optional NLI, spaCy, and language-detection packages..."
"$PYTHON" -m pip install --upgrade pip
"$PYTHON" -m pip install -r requirements-nli.txt -r requirements-ml.txt

echo "Installing the English spaCy model..."
"$PYTHON" -m spacy download en_core_web_sm

if [[ ! -f ".env" ]]; then
  cp .env.example .env
fi

if ! grep -q '^VERIFACT_NLI_MODEL=' .env; then
  printf '\nVERIFACT_NLI_MODEL=cross-encoder/nli-distilroberta-base\n' >> .env
fi

echo
echo "Optional NLP setup is complete."
echo "Restart the backend, then open http://127.0.0.1:8000/api/nli/status"
echo "The first NLI use downloads model weights and may take several minutes."
echo "To enable trained sentiment, add this to backend/.env:"
echo "VERIFACT_SENTIMENT_MODEL=cardiffnlp/twitter-roberta-base-sentiment-latest"
