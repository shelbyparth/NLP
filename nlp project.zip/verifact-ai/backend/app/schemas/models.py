from __future__ import annotations
from typing import Literal, Optional
from urllib.parse import urlparse
from pydantic import BaseModel, Field, HttpUrl, field_validator

Assessment = Literal["supported", "contradicted", "mixed", "insufficient_evidence"]

class VerifyRequest(BaseModel):
    text: Optional[str] = Field(default=None, max_length=30000)
    url: Optional[str] = Field(default=None, max_length=2048)
    top_k: int = Field(default=5, ge=1, le=15)
    include_history: bool = True

    @field_validator("text")
    @classmethod
    def strip_text(cls, value):
        return value.strip() if value is not None else value

    @field_validator("url")
    @classmethod
    def strip_url(cls, value):
        return value.strip() if value is not None else value

class ExtractTextRequest(BaseModel):
    text: Optional[str] = Field(default=None, max_length=30000)
    url: Optional[str] = Field(default=None, max_length=2048)

class ExtractClaimsRequest(BaseModel):
    text: str = Field(min_length=1, max_length=30000)

class SearchEvidenceRequest(BaseModel):
    query: str = Field(min_length=1, max_length=5000)
    top_k: int = Field(default=5, ge=1, le=15)

class EvidenceCreate(BaseModel):
    title: str = Field(min_length=2, max_length=300)
    content: str = Field(min_length=20, max_length=100000)
    url: Optional[str] = Field(default=None, max_length=2048)
    publisher: Optional[str] = Field(default=None, max_length=200)
    published_at: Optional[str] = Field(default=None, max_length=80)
    source_type: Literal["user_uploaded", "public_document", "dataset", "synthetic_demo"] = "user_uploaded"

    @field_validator("url")
    @classmethod
    def safe_source_url(cls, value):
        if value is None or not value.strip():
            return None
        parsed = urlparse(value.strip())
        if parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.username or parsed.password:
            raise ValueError("Source URLs must be valid http/https links without embedded credentials.")
        return value.strip()

class EvidenceBatchCreate(BaseModel):
    documents: list[EvidenceCreate] = Field(min_length=1, max_length=100)

class EvidenceOut(BaseModel):
    id: str
    title: str
    content: str
    url: Optional[str] = None
    publisher: Optional[str] = None
    published_at: Optional[str] = None
    source_type: str
    added_at: str

class EvidencePassage(BaseModel):
    evidence_id: str
    title: str
    publisher: Optional[str] = None
    url: Optional[str] = None
    published_at: Optional[str] = None
    excerpt: str
    relevance_score: float
    retrieval_method: str
    stance: Literal["supports", "contradicts", "mixed", "neutral", "unknown"] = "unknown"
    stance_score: Optional[float] = None

class ClaimItem(BaseModel):
    id: str
    text: str
    entities: list[dict] = Field(default_factory=list)

class VerificationResult(BaseModel):
    id: str
    created_at: str
    input_type: Literal["text", "url"]
    original_input: str
    article_title: Optional[str] = None
    claims: list[ClaimItem]
    assessment: Assessment
    assessment_label: str
    explanation: str
    supporting_evidence: list[EvidencePassage]
    contradicting_evidence: list[EvidencePassage]
    other_evidence: list[EvidencePassage]
    caveats: list[str]
    pipeline: dict
    llm_used: bool = False
    history_saved: bool = False

class ApiError(BaseModel):
    detail: str
