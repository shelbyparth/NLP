# VeriFact AI — Fake News Detection and Verification

**Check the news. Understand the evidence.**

VeriFact AI is an AI-assisted fake-news detection and claim-verification platform. Users can submit a factual claim, paste article text, or provide a public article URL; the system extracts claims, searches the available Evidence Library, and presents an evidence-based assessment.

## Main features

- **Verify news:** submit a claim or public article URL and review the assessment.
- **News tools:** summarize article text, extract text from screenshots when Tesseract OCR is installed, analyse article tone and language, and ask questions about the local Evidence Library.
- **Evidence Library:** add and manage source documents used during verification.
- **Dashboard:** review saved-check totals, verdict distribution and recent activity.
- **Check history:** revisit previous checks and their evidence.

## Verdicts

- **Supported:** retrieved evidence was assessed as supporting the claim.
- **Contradicted:** retrieved evidence was assessed as contradicting the claim.
- **Insufficient Evidence:** the available evidence or configured models were not sufficient to reach a defensible assessment.

A retrieval match is not proof of truth. Sentiment describes tone and is not a truth indicator. Always inspect the original sources and context.

## Technology

- Frontend: React, TypeScript and Vite.
- Backend: Python and FastAPI.
- Evidence retrieval: local word- and character-level TF-IDF with cosine similarity.
- Optional stance model: Hugging Face Transformers NLI model.
- Optional grounded explanations and translation: OpenAI-compatible chat-completions provider.
- Optional current-news search: Tavily.
- Optional screenshot OCR: Tesseract.

## Run locally

### Backend

```bash
cd backend
python -m venv .venv
# Windows Git Bash:
source .venv/Scripts/activate
# macOS/Linux:
# source .venv/bin/activate
pip install -r requirements.txt
python -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

### Frontend

Open a second terminal:

```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:5173/.

## Optional configuration

Copy `backend/.env.example` to `backend/.env` and set only the providers you intend to use. Keep API keys private; do not commit `.env`.

- Tavily news search requires `TAVILY_API_KEY`.
- LLM-generated answers and translation require `VERIFACT_LLM_BASE_URL`, `VERIFACT_LLM_API_KEY`, and `VERIFACT_LLM_MODEL`.
- NLI stance classification requires the configured local Transformers model described in `.env.example`.
- Screenshot OCR requires the Tesseract application installed and available on PATH.

Without optional providers, the app uses local evidence retrieval and clearly labelled fallback behaviour.

## Important limitations

This project assists with reviewing claims; it does not replace independent or professional fact-checking. Results depend on the coverage and quality of the indexed sources. Live news search results are candidate articles and are not automatically verified. Never treat a model prediction, sentiment label, or retrieval score as a calibrated probability that a news story is true.
