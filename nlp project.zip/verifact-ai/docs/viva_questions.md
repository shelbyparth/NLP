# Sample Viva Questions

1. **What problem does VeriFact AI solve?** It provides a workflow for extracting claims, retrieving related passages from an indexed corpus, comparing claim-evidence stance when an NLI model is configured, and producing a source-linked report.
2. **What is claim extraction?** Turning article text into smaller factual statements that can be checked independently.
3. **What is NER?** Named Entity Recognition identifies items such as people, organizations, places, dates, and quantities.
4. **Why preserve negation during preprocessing?** Removing terms like “not” can reverse a claim's meaning.
5. **How does TF-IDF work?** It represents documents using weighted terms that are informative within a corpus; similarity ranks candidate passages but does not prove truth.
6. **Why use character n-grams?** They can help retrieve passages despite morphology, spelling variants, or partial word overlap.
7. **What is RAG?** Retrieval-Augmented Generation supplies retrieved passages as context to a language model so its response can be grounded in those sources.
8. **Why are citations important?** They let a reader inspect the original source and verify the connection between evidence and conclusion.
9. **What does “insufficient evidence” mean?** The system does not have enough assessed, relevant evidence to make a defensible conclusion; it is not equivalent to “false.”
10. **What is an NLI model?** A Natural Language Inference model estimates whether a premise supports/entails, contradicts, or is neutral toward a hypothesis. Here the passage is the premise and the claim is the hypothesis.
11. **Why is sentiment not the verdict?** Emotional tone and factual correctness are different dimensions; a strongly worded claim can still be true or false.
12. **How is the classifier evaluated?** A labeled dataset is split into train and holdout sets; accuracy, weighted precision/recall/F1, a class report and confusion matrix are computed.
13. **What are Precision@k and Recall@k?** Precision@k measures the fraction of the top-k retrieved items that are relevant; Recall@k measures how much of the known relevant evidence appears among the top k.
14. **What are the current limitations?** The corpus is local and initially empty; default retrieval is lexical; claim extraction is heuristic; NLI, dense semantic embeddings and LLM generation require optional configuration.
15. **What are the next improvements?** Add a licensed evidence dataset, evaluate retrieval and stance, integrate a live search provider, improve entity-aware query expansion, add calibrated abstention, and perform human-reviewed RAG groundedness evaluation.
