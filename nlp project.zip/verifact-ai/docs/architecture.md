# VeriFact AI Architecture

## Main data flow

1. Input: plain claim text or a public article URL.
2. Extraction: URL text retrieval uses a bounded, guarded HTTP request. Pasted text bypasses network fetching.
3. Preparation: Unicode normalization and whitespace cleanup preserve negations, figures, dates, and names.
4. Claim segmentation: sentence-based candidates are extracted; long inputs are capped to five claims per verification run.
5. Entities: spaCy NER is used if `en_core_web_sm` is installed; regex fallbacks collect dates and quantities.
6. Index: document text is chunked and kept with stable document identifiers, URLs, titles, publishers, dates, source type, and timestamps.
7. Retrieval: word n-gram TF-IDF plus character n-gram TF-IDF forms a local lexical baseline. Dense sentence embeddings can be activated as an optional additional signal.
8. Stance: an optional NLI model compares evidence as premise and claim as hypothesis. If no model is configured, stance is unknown.
9. Aggregation: support only => Supported; contradiction only => Contradicted; both => Mixed Evidence; no assessed stance => Insufficient Evidence.
10. Explanation: deterministic text is available without an LLM. Optional OpenAI-compatible generation summarizes only the provided passages and cannot alter the assessment label.
11. Report: sources, passages, score, method, timing, caveats, and pipeline metadata are returned in a typed JSON response.

## Data integrity

The backend stores the local evidence corpus in `backend/data/evidence.json` and verification history in SQLite. The initial corpus is empty. Synthetic demo documents have a distinct `source_type` and are not real evidence. Source URLs are kept with excerpts; citations must link to imported source metadata, not generated URLs.

## Security notes

URL fetching blocks non-HTTP(S) schemes, credentialed URLs, local/private/reserved IPs, non-global DNS answers, too many redirects, unsupported content types, and oversized pages. URLs are revalidated on each redirect. This is an academic safeguard, not a substitute for hardened egress controls in a deployed environment. Do not expose the service publicly without authentication, rate limiting, robust DNS rebinding protection, and deployment review.
