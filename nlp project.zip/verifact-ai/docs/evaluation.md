# Evaluation Plan

## Classification baseline

The classification baseline uses a TF-IDF vectorizer and Logistic Regression. The vectorizer is fitted inside a scikit-learn pipeline on the training partition only; the test partition is held out for scoring. The split is stratified and reproducible using the configured random state. Exact duplicate claim texts are removed before splitting. Rows with conflicting labels for the same normalized text are rejected.

Run an evaluation from the Research & Evaluation page by pasting a JSON array or uploading a CSV, JSON, or JSONL file. CSV files must have a header row. The default columns are `text` and `label`; the UI permits custom column names. JSON can be an array of objects, an object with an `examples` or `data` array, or JSON Lines. Dataset name and source notes are stored with each run; these are user-provided metadata and are not independently source-verified.

The API accepts at least 8 unique labeled examples and 2 or more classes. A larger, representative, independently labeled dataset is needed for meaningful estimates. Every run reports the dataset class distribution, train/test counts, accuracy, weighted precision/recall/F1, per-class precision/recall/F1/support, confusion matrix, warnings, and the random seed. Small-data warnings remain visible. The interface renders metric bars, a class-distribution doughnut, per-class comparisons, a confusion-matrix heatmap, and a comparison of saved runs.

Evaluation runs are saved in local SQLite history and the latest result is written to `backend/data/latest_evaluation.json`. Individual runs can be downloaded as CSV or PDF reports. These files include metrics, class-wise results, the confusion matrix, dataset metadata, and caveats.

Example API paths:

- `POST /api/evaluate` — run from a JSON request body.
- `POST /api/evaluate/upload` — upload CSV, JSON, or JSONL as multipart form data.
- `GET /api/evaluations` — list saved evaluation runs.
- `GET /api/evaluations/{evaluation_id}` — retrieve a saved run.
- `GET /api/evaluations/{evaluation_id}/report.csv` and `/report.pdf` — download a report.

## Evidence retrieval

For FEVER or another corpus with evidence relevance labels, report Precision@k, Recall@k and Mean Reciprocal Rank. Avoid computing retrieval performance without known relevant evidence labels. Relevance similarity alone is not proof of correctness.

## Stance / evidence comparison

Use labeled claim-evidence pairs to measure per-class precision, recall, F1 and confusion matrix for Supported/Contradicted/Neutral. The inference API preserves Neutral as a distinct stance; it is not counted as support or contradiction. Review threshold effects and model label mapping; confirm the NLI model's actual `id2label` before reporting results.

## RAG groundedness

Manually review a held-out sample for citation correctness, statement-to-evidence support, contradictory evidence coverage, source freshness, unsupported details and appropriate abstention. Generated fluency is not an accuracy metric. Record the reviewer rubric and disagreements.

## Error analysis and limitations

Group errors by missing evidence, retrieval miss, duplicate/outdated document, entity mismatch, date mismatch, negation, ambiguous claim, contradictory sources, low-quality source and translation error. Exact duplicate-text filtering does not detect semantic paraphrases or group records by publisher/source. Use a documented source-level split where the dataset contains related articles or claim families. Document the limitations and avoid claims of guaranteed factual verification.

The baseline classifier evaluates only the user-supplied labels; it is separate from the live evidence retrieval/NLI pipeline. A score from a small or synthetic sample must not be presented as real-world fake-news detection accuracy. Check dataset license, provenance, label definition, class balance, preprocessing, and official train/dev/test split before academic reporting.
