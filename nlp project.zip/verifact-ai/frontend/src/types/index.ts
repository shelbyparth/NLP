export type Assessment = 'supported' | 'contradicted' | 'mixed' | 'insufficient_evidence'

export interface EvidencePassage {
  evidence_id: string
  title: string
  publisher?: string | null
  url?: string | null
  published_at?: string | null
  excerpt: string
  relevance_score: number
  retrieval_method: string
  stance: 'supports' | 'contradicts' | 'mixed' | 'neutral' | 'unknown'
  stance_score?: number | null
  related_claim?: string
}

export interface ClaimItem {
  id: string
  text: string
  entities: Array<{ text: string; label: string; method?: string }>
}

export interface ClaimAssessment {
  claim_id: string
  claim: string
  assessment: Assessment
  assessment_label: string
  evidence_count: number
  supporting_passages: number
  contradicting_passages: number
  unassessed_passages: number
}

export interface VerificationResult {
  id: string
  created_at: string
  input_type: 'text' | 'url'
  original_input: string
  article_title?: string | null
  claims: ClaimItem[]
  claim_assessments?: ClaimAssessment[]
  assessment: Assessment
  assessment_label: string
  explanation: string
  supporting_evidence: EvidencePassage[]
  contradicting_evidence: EvidencePassage[]
  other_evidence: EvidencePassage[]
  caveats: string[]
  pipeline: Record<string, unknown>
  llm_used: boolean
  history_saved: boolean
}

export interface EvidenceDocument {
  id: string
  title: string
  content: string
  url?: string | null
  publisher?: string | null
  published_at?: string | null
  source_type: string
  added_at: string
}

export interface EvaluationResult {
  evaluation_id?: string
  evaluated_at?: string
  experiment: string
  evaluation_method: string
  random_state: number
  requested_test_size: number
  dataset_examples: number
  duplicate_rows_removed?: number
  train_examples: number
  test_examples: number
  label_distribution: Record<string, number>
  metrics: Record<string, number>
  labels: string[]
  confusion_matrix: number[][]
  classification_report: Record<string, Record<string, number>>
  evaluation_warnings: string[]
  dataset?: { name: string; source_description?: string; source_type: string; examples_after_deduplication?: number; classes?: number }
  note: string
}
