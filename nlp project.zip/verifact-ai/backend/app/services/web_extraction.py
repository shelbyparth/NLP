from __future__ import annotations
import ipaddress
import socket
from urllib.parse import urlparse, urljoin
import requests
from ..config import MAX_URL_BYTES
from .preprocessing import html_to_text, normalize_text

USER_AGENT = "VeriFactAI-AcademicPrototype/1.0 (public-page text extraction)"


def _validate_public_url(url: str) -> None:
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"}:
        raise ValueError("Only http and https URLs are supported.")
    if not parsed.hostname or parsed.username or parsed.password:
        raise ValueError("The URL is invalid or contains credentials.")
    host = parsed.hostname.lower().rstrip(".")
    if host in {"localhost", "localhost.localdomain"} or host.endswith((".local", ".internal", ".localhost")):
        raise ValueError("Private and local network hosts are not allowed.")
    try:
        answers = socket.getaddrinfo(host, parsed.port or (443 if parsed.scheme == "https" else 80), type=socket.SOCK_STREAM)
    except socket.gaierror as exc:
        raise ValueError("The hostname could not be resolved.") from exc
    for answer in answers:
        ip = ipaddress.ip_address(answer[4][0])
        if not ip.is_global:
            raise ValueError("Private, loopback, or reserved network addresses are not allowed.")


def fetch_article(url: str) -> dict:
    current = url
    response = None
    for _ in range(4):
        _validate_public_url(current)
        try:
            response = requests.get(current, headers={"User-Agent": USER_AGENT, "Accept": "text/html,text/plain,application/xhtml+xml"}, timeout=(5, 12), allow_redirects=False, stream=True)
        except requests.RequestException as exc:
            raise ValueError("The page could not be fetched. Check the URL, connection, or site availability.") from exc
        if response.is_redirect or response.is_permanent_redirect:
            location = response.headers.get("Location")
            response.close()
            if not location:
                raise ValueError("The website returned an invalid redirect.")
            current = urljoin(current, location)
            continue
        break
    else:
        raise ValueError("Too many redirects while fetching the article.")
    assert response is not None
    try:
        try:
            response.raise_for_status()
        except requests.HTTPError as exc:
            raise ValueError(f"The webpage returned HTTP status {response.status_code}.") from exc
        content_type = response.headers.get("Content-Type", "").lower()
        if not any(x in content_type for x in ("text/html", "text/plain", "application/xhtml+xml")):
            raise ValueError("This URL does not return a supported text or HTML page.")
        body = bytearray()
        for chunk in response.iter_content(65536):
            if chunk:
                body.extend(chunk)
                if len(body) > MAX_URL_BYTES:
                    raise ValueError("The webpage is larger than the configured extraction limit.")
        encoding = response.encoding or "utf-8"
        raw = bytes(body).decode(encoding, errors="replace")
        if "html" in content_type or "xhtml" in content_type or "<html" in raw[:2000].lower():
            text = html_to_text(raw)
            title = text.split("\n", 1)[0][:300] if text else urlparse(current).netloc
        else:
            text = normalize_text(raw)
            title = urlparse(current).path.rsplit("/", 1)[-1] or urlparse(current).netloc
        if len(text.strip()) < 40:
            raise ValueError("The page did not contain enough readable text. Paste the article text instead.")
        return {"url": current, "title": title, "publisher": urlparse(current).hostname, "text": text[:30000]}
    finally:
        response.close()
