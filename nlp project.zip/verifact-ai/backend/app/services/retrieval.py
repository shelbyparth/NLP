from __future__ import annotations
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from .corpus import load_documents, chunks_from_documents
from ..config import USE_SEMANTIC_RETRIEVAL
from functools import lru_cache
import os


@lru_cache(maxsize=2)
def _embedding_model(model_name: str):
    from sentence_transformers import SentenceTransformer
    return SentenceTransformer(model_name)


def search_evidence(query: str, top_k: int = 5) -> list[dict]:
    docs = load_documents()
    chunks = chunks_from_documents(docs)
    if not chunks or not query.strip():
        return []
    texts = [f"{c['title']} {c.get('publisher') or ''}\n{c['excerpt']}" for c in chunks]
    # Word and character features jointly provide a local hybrid lexical baseline.
    word = TfidfVectorizer(ngram_range=(1, 2), strip_accents="unicode", sublinear_tf=True, max_features=80000)
    char = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), strip_accents="unicode", sublinear_tf=True, max_features=80000)
    try:
        word_matrix = word.fit_transform(texts + [query])
        word_scores = cosine_similarity(word_matrix[-1], word_matrix[:-1]).ravel()
    except ValueError:
        word_scores = np.zeros(len(texts))
    try:
        char_matrix = char.fit_transform(texts + [query])
        char_scores = cosine_similarity(char_matrix[-1], char_matrix[:-1]).ravel()
    except ValueError:
        char_scores = np.zeros(len(texts))
    method = "tfidf_hybrid_word_char"
    threshold = 0.04
    scores = 0.75 * word_scores + 0.25 * char_scores
    if USE_SEMANTIC_RETRIEVAL:
        model_name = os.getenv("VERIFACT_EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
        try:
            model = _embedding_model(model_name)
            embeddings = model.encode(texts, normalize_embeddings=True, convert_to_numpy=True, show_progress_bar=False)
            query_embedding = model.encode([query], normalize_embeddings=True, convert_to_numpy=True, show_progress_bar=False)[0]
            semantic_scores = np.asarray(embeddings @ query_embedding, dtype=float)
            # Similarity assists ranking only; it is never used as truth confidence.
            scores = 0.60 * semantic_scores + 0.30 * word_scores + 0.10 * char_scores
            method = "hybrid_semantic_tfidf"
            threshold = 0.24
        except Exception:
            # Optional dense models may be unavailable offline; keep the explicit lexical baseline working.
            method = "tfidf_hybrid_word_char_fallback"
    order = np.argsort(scores)[::-1]
    result = []
    seen: set[str] = set()
    for ix in order:
        score = float(scores[ix])
        chunk = chunks[int(ix)]
        # Drop zero/low-similarity entries instead of returning irrelevant documents as evidence.
        if score <= threshold:
            continue
        dedupe_key = f"{chunk['evidence_id']}::{chunk['excerpt'][:120].lower()}"
        if dedupe_key in seen:
            continue
        seen.add(dedupe_key)
        result.append({**chunk, "relevance_score": round(score, 4), "retrieval_method": method, "stance": "unknown", "stance_score": None})
        if len(result) >= top_k:
            break
    return result
