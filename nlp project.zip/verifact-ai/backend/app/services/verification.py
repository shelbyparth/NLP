from __future__ import annotations

import time
import uuid
from datetime import datetime, timezone

from ..config import MAX_INPUT_CHARS, NLI_MODEL, LLM_API_KEY, LLM_BASE_URL, LLM_MODEL
from ..db.history import save_result
from .claim_extraction import extract_claims
from .entity_extraction import extract_entities
from .preprocessing import normalize_text
from .rag_engine import generate_explanation
from .retrieval import search_evidence
from .stance_classification import classify_stance
from .web_extraction import fetch_article

LABELS = {
    "supported": "Supported",
    "contradicted": "Contradicted",
    "mixed": "Mixed Evidence",
    "insufficient_evidence": "Insufficient Evidence",
}


def _assessment_for_passages(passages: list[dict]) -> str:
    supports = any(item.get("stance") == "supports" for item in passages)
    contradicts = any(item.get("stance") == "contradicts" for item in passages)
    if supports and contradicts:
        return "mixed"
    if supports:
        return "supported"
    if contradicts:
        return "contradicted"
    return "insufficient_evidence"


def _aggregate_claim_assessments(assessments: list[str]) -> str:
    """Be conservative when an article contains multiple extracted claims."""
    if not assessments:
        return "insufficient_evidence"
    if all(value == "supported" for value in assessments):
        return "supported"
    if all(value == "contradicted" for value in assessments):
        return "contradicted"
    if "mixed" in assessments or ("supported" in assessments and "contradicted" in assessments):
        return "mixed"
    # Do not present the whole article as supported/contradicted if only a subset
    # of its claims could be checked and other claims remain unassessed.
    return "insufficient_evidence"


def verify_request(text: str | None, url: str | None, top_k: int = 5, include_history: bool = True) -> dict:
    started = time.perf_counter()
    input_type = "url" if url else "text"
    original_input = url or (text or "")
    article_title = None

    if url:
        fetched = fetch_article(url)
        text = fetched["text"]
        article_title = fetched["title"]

    text = normalize_text(text or "")
    if not text:
        raise ValueError("Enter a claim or article text, or provide a public article URL.")
    if len(text) > MAX_INPUT_CHARS:
        raise ValueError(f"Input is too long. Maximum supported length is {MAX_INPUT_CHARS} characters.")

    claims = extract_claims(text)
    # A short direct claim remains verifiable even if the sentence heuristic skips it.
    if not claims:
        claims = [{"id": f"claim_{uuid.uuid4().hex[:10]}", "text": text[:1000], "entities": []}]
    for claim in claims:
        claim["entities"] = extract_entities(claim["text"])

    # Keep the project's bounded article-analysis behavior explicit.
    active_claims = claims[:5]
    all_evidence: list[dict] = []
    claim_assessments: list[dict] = []
    retrieval_time = 0.0

    for claim in active_claims:
        claim_passages: list[dict] = []
        t0 = time.perf_counter()
        retrieved = search_evidence(claim["text"], top_k=top_k)
        retrieval_time += time.perf_counter() - t0

        seen_for_claim: set[tuple[str, str]] = set()
        for passage in retrieved:
            passage_key = (str(passage.get("evidence_id", "")), str(passage.get("excerpt", "")))
            if passage_key in seen_for_claim:
                continue
            seen_for_claim.add(passage_key)
            stance = classify_stance(claim["text"], passage["excerpt"])
            enriched = {
                **passage,
                "stance": stance["stance"],
                "stance_score": stance["score"],
                "stance_method": stance["method"],
                "related_claim": claim["text"],
            }
            if stance.get("error_type"):
                enriched["stance_error_type"] = stance["error_type"]
            claim_passages.append(enriched)
            all_evidence.append(enriched)

        claim_assessment = _assessment_for_passages(claim_passages)
        supports = sum(item.get("stance") == "supports" for item in claim_passages)
        contradicts = sum(item.get("stance") == "contradicts" for item in claim_passages)
        claim_assessments.append({
            "claim_id": claim["id"],
            "claim": claim["text"],
            "assessment": claim_assessment,
            "assessment_label": LABELS[claim_assessment],
            "evidence_count": len(claim_passages),
            "supporting_passages": supports,
            "contradicting_passages": contradicts,
            "unassessed_passages": len(claim_passages) - supports - contradicts,
        })

    assessment = _aggregate_claim_assessments([row["assessment"] for row in claim_assessments])
    supports = [item for item in all_evidence if item.get("stance") == "supports"]
    contradicts = [item for item in all_evidence if item.get("stance") == "contradicts"]
    unknown = [item for item in all_evidence if item.get("stance") in {"unknown", "mixed", "neutral"}]

    explanation, llm_used = generate_explanation(text[:2000], LABELS[assessment], all_evidence)
    caveats = []
    if not all_evidence:
        caveats.append("No relevant passages were found in the currently indexed corpus.")

    stance_methods = {item.get("stance_method") for item in all_evidence}
    nli_active = "nli" in stance_methods
    if not NLI_MODEL:
        caveats.append("No NLI model is configured; retrieved passages are not automatically classified for support or contradiction.")
    elif "nli_load_error" in stance_methods:
        caveats.append("The configured NLI model could not be loaded. Install the optional ML dependencies, check the model name and model download/cache, then restart the backend.")
    elif "nli_label_mapping_unknown" in stance_methods:
        caveats.append("The configured NLI model's output labels could not be mapped safely to entailment, contradiction, and neutral. Choose a model with descriptive NLI labels or add an explicit label mapping.")
    elif "nli_inference_error" in stance_methods:
        caveats.append("The configured NLI model loaded but inference failed for at least one passage. Review the backend console and model compatibility.")
    elif any(item.get("stance") == "unknown" and item.get("stance_method") == "nli" for item in all_evidence):
        caveats.append("At least one NLI comparison fell below the confidence threshold, so that passage was left unclassified.")
    elif all_evidence and not nli_active:
        caveats.append("The configured NLI model did not produce a confident support/contradiction assessment; the result remains inconclusive.")

    if any(item.get("stance") == "neutral" for item in all_evidence):
        caveats.append("The NLI model classified at least one passage as neutral; neutral evidence neither supports nor contradicts the claim.")
    if len(claims) > len(active_claims):
        caveats.append("Only the first 5 extracted claims were processed in this report to keep analysis bounded.")
    if any(item.get("source_type") == "synthetic_demo" for item in all_evidence):
        caveats.append("At least one retrieved passage is from the synthetic demo corpus and is not real-world evidence.")
    if input_type == "url":
        caveats.append("Only the extracted article text and the currently indexed evidence corpus were considered; this is not a guarantee of exhaustive web research.")

    duration_ms = round((time.perf_counter() - started) * 1000, 2)
    result = {
        "id": f"check_{uuid.uuid4().hex[:12]}",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "input_type": input_type,
        "original_input": original_input[:MAX_INPUT_CHARS],
        "article_title": article_title,
        "claims": active_claims,
        "claim_assessments": claim_assessments,
        "assessment": assessment,
        "assessment_label": LABELS[assessment],
        "explanation": explanation,
        "supporting_evidence": supports,
        "contradicting_evidence": contradicts,
        "other_evidence": unknown,
        "caveats": caveats,
        "pipeline": {
            "extraction": "html_extraction" if input_type == "url" else "user_text",
            "preprocessing": "unicode_whitespace_normalization",
            "claim_extraction": "sentence_heuristic",
            "entity_extraction": "spacy_optional_regex_fallback",
            "retrieval": "word_char_tfidf_hybrid",
            "retrieval_seconds": round(retrieval_time, 4),
            "nli_model_requested": bool(NLI_MODEL),
            "nli_comparison_active": nli_active,
            "nli_methods_observed": sorted(method for method in stance_methods if method),
            "llm_configured": bool(LLM_BASE_URL and LLM_API_KEY and LLM_MODEL),
            "processing_ms": duration_ms,
            "evidence_count": len(all_evidence),
            "corpus_mode": "local_indexed_corpus",
        },
        "llm_used": llm_used,
        "history_saved": False,
    }
    if include_history:
        try:
            save_result(result)
            result["history_saved"] = True
        except Exception:
            result["caveats"].append("History could not be saved in the local database.")
    return result
