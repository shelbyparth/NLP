# API Notes

Interactive OpenAPI documentation is served at `/docs` while the backend runs. JSON bodies are validated by Pydantic. Most error responses include a `detail` field. Large extraction and model calls are bounded; model training is intentionally exposed as an explicit evaluation action for this academic prototype.

## Verify a claim

```json
{
  "text": "Paste a factual claim here with enough context.",
  "top_k": 5,
  "include_history": true
}
```

Send either `text` or `url`, not both. A successful response always includes an assessment, explanation, claims, evidence buckets, caveats and pipeline metadata. The assessment can be `supported`, `contradicted`, `mixed`, or `insufficient_evidence`.

## Add evidence

```json
{
  "title": "Report title",
  "publisher": "Publisher name",
  "url": "https://publisher.example/report",
  "published_at": "2025-04-12",
  "content": "A permitted source passage or document text, at least 20 characters long."
}
```

`source_type` can be `user_uploaded`, `public_document`, `dataset`, or `synthetic_demo`. Only use `synthetic_demo` for visibly fictional test fixtures.

## Run classifier evaluation

`POST /api/evaluate` accepts a JSON body containing an `examples` array. Each row uses `text` and `label` fields. Optional fields are `dataset_name`, `source_description`, `test_size` (default `0.25`), and `random_state` (default `42`). At least 8 unique examples and 2 classes are required.

```json
{
  "dataset_name": "My labeled validation subset",
  "source_description": "Dataset version, URL, license and documented split details",
  "test_size": 0.25,
  "random_state": 42,
  "examples": [
    {"text": "Claim text one", "label": "supported"},
    {"text": "Claim text two", "label": "contradicted"}
  ]
}
```

For file uploads, send multipart form data to `POST /api/evaluate/upload`. Supported formats are `.csv`, `.json`, and `.jsonl`; the maximum file size is 10 MB. CSV needs a header row. Default field names are `text` and `label`; `text_field` and `label_field` form fields can override them. JSON accepts an array or an object with an `examples` or `data` array. JSONL accepts one JSON object per line. Optional form fields are `dataset_name`, `source_description`, `test_size`, and `random_state`.

Each result includes dataset metadata, class distribution, train/test sizes, accuracy, weighted precision/recall/F1, per-class scores, confusion matrix, and warnings. Exact duplicate texts are removed before splitting; conflicting labels for duplicate normalized texts are rejected. Vectorization is fitted on the training partition only.

Saved evaluation run endpoints:

- `GET /api/evaluations` — list saved runs (`limit` defaults to 20).
- `GET /api/evaluations/{evaluation_id}` — retrieve one saved run.
- `GET /api/evaluations/{evaluation_id}/report.csv` — download metrics, per-class results, confusion matrix and warnings as CSV.
- `GET /api/evaluations/{evaluation_id}/report.pdf` — download the same report as PDF.

The latest evaluation is also available from `GET /api/metrics`. Dataset source notes are user-provided, not independently verified. The classifier baseline is not the same as the evidence retrieval/NLI verification pipeline and does not establish real-world fact-checking accuracy.


## News tools

- `POST /api/summarize` — accepts article `text` (40–30,000 characters) and returns a short extractive summary, detailed extractive summary, key points and method note.
- `POST /api/ask` — accepts a `question` and retrieves matching passages from the local Evidence Library. With an OpenAI-compatible LLM configured, it can compose a grounded answer from those excerpts; source records are returned separately.
- `POST /api/news/search` — accepts `query` and optional `max_results` (1–10). Requires `TAVILY_API_KEY`. Returns current news search results and publisher URLs; results are not fact-checked.
- `POST /api/ocr` — multipart image upload (`file`) for PNG, JPG, JPEG, WEBP or BMP screenshots up to 5 MB. Requires Pillow, pytesseract and a working Tesseract OCR executable. Review the extracted text because OCR can misread characters.
- `POST /api/translate` — translates supplied text to a requested language using the configured OpenAI-compatible provider.

The browser stores selected news interests locally. The application does not store Tavily or LLM API keys in the frontend.
